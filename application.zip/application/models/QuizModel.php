<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class QuizModel extends CI_Model {

	public function getQuiz($id_category_quiz = null) {
		if ($id_category_quiz) {
			$this->db->where('ms_quiz.id_category_quiz', $id_category_quiz);
		}
		$this->db->join('ms_category_quiz', 'ms_category_quiz.id_category_quiz = ms_quiz.id_category_quiz', 'left');
		$this->db->order_by('ms_category_quiz.category_quiz_name', 'asc');
		$this->db->where('ms_quiz.quiz_hide', 0);
		return $this->db->get('ms_quiz')->result_object();
	}
	public function getQuiz_simple() {
		return $this->db->query("SELECT id_quiz,quiz_start,quiz_end FROM ms_quiz WHERE quiz_hide = 0")->result_object();
	}
	public function getQuizByTeacher_simple($id_teacher) {
		return $this->db->query("SELECT id_quiz,quiz_start,quiz_end FROM ms_quiz WHERE quiz_hide = 0 AND quiz_author = 'guru' AND quiz_author_id = '$id_teacher'")->result_object();
	}
	public function getClassXII() {
		$this->db->order_by('class_name', 'asc');
		$this->db->where('class_level', 'XII');
		$this->db->where('class_hide', 0);
		return $this->db->get('ms_class')->result_object();
	}
	public function insertQuiz($data) {
		$this->db->insert('ms_quiz', $data);
		return $this->db->insert_id();
	}
	public function updateQuiz($data) {
		$this->db->where('id_quiz', $data['id_quiz']);
		return $this->db->update('ms_quiz', $data);
	}
	public function getCountQuestionByQuiz($id_quiz) {
		return $this->db->query("SELECT SUM(lQuiz_total_question) AS total FROM quiz_lesson WHERE id_quiz = '$id_quiz' AND lQuiz_hide = 0")->row_object();
	}
	public function getClassByQuiz($id_quiz) {
		$this->db->where('id_quiz', $id_quiz);
		return $this->db->get('quiz_class')->result_object();
	}
	public function insertQuizClass($data) {
		return $this->db->insert('quiz_class', $data);
	}
	public function deleteClassByQuiz($id_quiz) {
		$this->db->where('id_quiz', $id_quiz);
		return $this->db->delete('quiz_class');
	}
	public function getQuizById($id_quiz,$joinCategory = false) {
		$this->db->where('ms_quiz.id_quiz', $id_quiz);
		$this->db->where('ms_quiz.quiz_hide', 0);
		if ($joinCategory) {
			$this->db->join('ms_category_quiz', 'ms_quiz.id_category_quiz = ms_category_quiz.id_category_quiz', 'left');
		}
		return $this->db->get('ms_quiz')->row_object();
	}
	public function getLessonByQuiz($id_quiz) {
		return $this->db->query("SELECT quiz_lesson.*,ms_lesson.lesson_name FROM quiz_lesson LEFT JOIN ms_lesson ON quiz_lesson.id_lesson = ms_lesson.id_lesson WHERE quiz_lesson.id_quiz = '$id_quiz' AND quiz_lesson.lQuiz_hide = 0")->result_object();
	}
	public function getLessonByQuizAndLesson($id_quiz, $id_lesson,$id_lQuiz = null) {
		if ($id_lQuiz) {
			$this->db->where('id_lQuiz', $id_lQuiz);
		}
		$this->db->where('id_quiz', $id_quiz);
		$this->db->where('id_lesson', $id_lesson);
		$this->db->where('lQuiz_hide', 0);
		return $this->db->get('quiz_lesson')->row_object();
	}
	public function insertQuizLesson($data) {
		return $this->db->insert('quiz_lesson', $data);
	}
	public function updateQuizLesson($data) {
		$this->db->where('id_lQuiz', $data['id_lQuiz']);
		return $this->db->update('quiz_lesson', $data);
	}
	public function getQuizLessonById($id_lQuiz) {
		return $this->db->query("SELECT quiz_lesson.*,ms_lesson.lesson_name FROM quiz_lesson LEFT JOIN ms_lesson ON ms_lesson.id_lesson = quiz_lesson.id_lesson WHERE quiz_lesson.id_lQuiz = '$id_lQuiz' AND quiz_lesson.lQuiz_hide = 0")->row_object();
	}
	public function getQuestionByQuizLesson($id_quiz, $id_lQuiz,$quiz_order = null) {
		// return $this->db->query("
		// 	SELECT quiz_question.*,ms_question.question_,ms_question.question_image,ms_question.question_sound FROM quiz_question 
		// 	LEFT JOIN ms_question ON ms_question.id_question = quiz_question.id_question 
		// 	WHERE quiz_question.id_quiz = '$id_quiz' 
		// 	AND quiz_question.id_lQuiz = '$id_lQuiz' 
		// 	AND quiz_question.qQuiz_hide = 0
		// ")->result_object();
		if ($quiz_order) {
			$this->db->order_by('quiz_question.id_qQuiz', $quiz_order);
		}
		$this->db->where('quiz_question.id_quiz', $id_quiz);
		$this->db->where('quiz_question.id_lQuiz', $id_lQuiz);
		$this->db->where('quiz_question.qQuiz_hide', 0);
		$this->db->join('ms_question', 'quiz_question.id_question = ms_question.id_question', 'left');
		return $this->db->get('quiz_question')->result_object();
	}
	public function getQuestionByQuizLessonQuestion($id_quiz,$id_lQuiz,$id_question) {
		$this->db->where('id_quiz', $id_quiz);
		$this->db->where('id_lQuiz', $id_lQuiz);
		$this->db->where('id_question', $id_question);
		$this->db->where('qQuiz_hide', 0);
		return $this->db->get('quiz_question')->row_object();
	}
	public function getQuestionByQuizQuestion($id_qQuiz) {
		$this->db->where('quiz_question.id_qQuiz', $id_qQuiz);
		$this->db->join('ms_question', 'quiz_question.id_question = ms_question.id_question', 'left');
		return $this->db->get('quiz_question')->row_object();
	}
	public function insertQuestion($data) {
		$this->db->insert('ms_question', $data);
		return $this->db->insert_id();
	}
	public function updateQuestion($data) {
		$this->db->where('id_question', $data['id_question']);
		return $this->db->update('ms_question', $data);
	}
	public function insertOption($data) {
		return $this->db->insert('question_option', $data);
	}
	public function insertQuizQuestion($data) {
		return $this->db->insert('quiz_question', $data);
	}
	public function updateQuizQuestion($data) {
		$this->db->where('id_qQuiz', $data['id_qQuiz']);
		return $this->db->update('quiz_question', $data);
	}
	public function getQuizQuestionById($id_qQuiz = null) {
		$this->db->where('quiz_question.id_qQuiz', $id_qQuiz);
		$this->db->where('quiz_question.qQuiz_hide', 0);
		$this->db->join('ms_question', 'quiz_question.id_question = ms_question.id_question', 'left');
		return $this->db->get('quiz_question')->row_object();
	}
	public function updateOption($data) {
		$this->db->where('id_option', $data['id_option']);
		return $this->db->update('question_option', $data);
	}
	public function getQuizCategory() {
		$this->db->order_by('category_quiz_name', 'asc');
		$this->db->where('category_quiz_hide', 0);
		return $this->db->get('ms_category_quiz')->result_object();
	}
	public function insertQuizCategory($data) {
		return $this->db->insert('ms_category_quiz', $data);
	}
	public function updateQuizCategory($data) {
		$this->db->where('id_category_quiz', $data['id_category_quiz']);
		return $this->db->update('ms_category_quiz', $data);
	}
	public function getQuestionByLesson($id_lesson) {
		$this->db->where('ms_question.id_lesson', $id_lesson);
		$this->db->where('ms_question.question_hide', 0);
		$this->db->join('ms_lesson', 'ms_question.id_lesson = ms_lesson.id_lesson', 'left');
		return $this->db->get('ms_question')->result_object();
	}
	public function getIdAssignmentByQuestion($id_question) {
		return $this->db->query("SELECT assignment_question.id_aquestion,ms_assignment.assignment_path FROM assignment_question LEFT JOIN ms_assignment ON ms_assignment.id_assignment = assignment_question.id_assignment WHERE assignment_question.id_question = '$id_question' AND assignment_question.val_hide = 0 ORDER BY assignment_question.id_aquestion ASC")->row_object();
	}
	public function getQuizByClass($id_class) {
		return $this->db->query("SELECT DISTINCT(id_quiz) FROM quiz_class WHERE id_class = '$id_class' ORDER BY id_quiz DESC")->result_object();
	}
	public function getResultByQuizStudent($id_quiz,$id_student) {
		$this->db->where('id_quiz', $id_quiz);
		$this->db->where('id_student', $id_student);
		return $this->db->get('quiz_result')->row_object();
	}
	public function getResultByQuizStudent_all($id_quiz,$id_student) {
		$this->db->where('id_quiz', $id_quiz);
		$this->db->where('id_student', $id_student);
		return $this->db->get('quiz_result')->result_object();
	}
	public function getQuizLessonByQuiz($id_quiz,$quiz_order = null) {
		if ($quiz_order) {
			$this->db->order_by('quiz_lesson.id_lQuiz', $quiz_order);
			$this->db->where('quiz_lesson.id_quiz', $id_quiz);
			$this->db->where('quiz_lesson.lQuiz_hide', 0);
			$this->db->join('ms_lesson', 'quiz_lesson.id_lesson = ms_lesson.id_lesson', 'left');
			return $this->db->get('quiz_lesson')->result_object();
		} else {
			return $this->db->query("
				SELECT quiz_lesson.*,ms_lesson.lesson_name FROM quiz_lesson 
				LEFT JOIN ms_lesson ON quiz_lesson.id_lesson = ms_lesson.id_lesson 
				WHERE quiz_lesson.id_quiz = '$id_quiz' 
				AND quiz_lesson.lQuiz_hide = 0 
				ORDER BY quiz_lesson.id_lQuiz ASC
			")->result_object();
		}
	}
	public function getQuizBegin($id_quiz,$id_student) {
		$this->db->where('id_quiz', $id_quiz);
		$this->db->where('id_student', $id_student);
		return $this->db->get('quiz_begin')->row_object();
	}
	public function insertQuizBegin($data) {
		return $this->db->insert('quiz_begin', $data);
	}
	public function insertQuizResult($data) {
		$this->db->insert('quiz_result', $data);
		return $this->db->insert_id();
	}
	public function insertQuizAnalytic($data) {
		return $this->db->insert('quiz_analytic', $data);
	}
	public function deleteQuizBegin($id_quiz, $id_student) {
		$this->db->where('id_quiz', $id_quiz);
		$this->db->where('id_student', $id_student);
		return $this->db->delete('quiz_begin');
	}
	public function getQuizResultByStudent($id_quiz,$id_student) {
		$this->db->where('id_quiz', $id_quiz);
		$this->db->where('id_student', $id_student);
		return $this->db->get('quiz_result')->result_object();
	}
	public function getQuizResultByQuizLessonStudent($id_quiz,$id_lQuiz,$id_student) {
		$this->db->where('id_quiz', $id_quiz);
		$this->db->where('id_lQuiz', $id_lQuiz);
		$this->db->where('id_student', $id_student);
		return $this->db->get('quiz_result')->row_object();
	}
	public function getQuizResultByStudent_FULLJOIN($id_quiz, $id_student) {
		return $this->db->query("
				SELECT quiz_result.*,quiz_lesson.id_lesson,ms_lesson.lesson_name FROM quiz_result 
				LEFT JOIN quiz_lesson ON quiz_result.id_lQuiz = quiz_lesson.id_lQuiz 
				LEFT JOIN ms_lesson ON quiz_lesson.id_lesson = ms_lesson.id_lesson 
				WHERE quiz_result.id_quiz = '$id_quiz' AND quiz_result.id_student = '$id_student' 
				ORDER BY quiz_result.id_rQuiz ASC
			")->result_object();
	}
	public function getQuizAnalyticByResult($id_rQuiz) {
		return $this->db->query("
				SELECT quiz_analytic.*,quiz_question.id_question,ms_question.question_,ms_question.question_image FROM quiz_analytic 
				LEFT JOIN quiz_question ON quiz_analytic.id_qQuiz = quiz_question.id_qQuiz 
				LEFT JOIN ms_question ON quiz_question.id_question = ms_question.id_question 
				WHERE quiz_analytic.id_rQuiz = '$id_rQuiz' ORDER BY quiz_analytic.id_aQuiz ASC
			")->result_object();
	}
	public function getOptionById($id_option) {
		$this->db->where('id_option', $id_option);
		return $this->db->get('question_option')->row_object();
	}
	public function getTrueOptionByQuestion($id_question) {
		$this->db->where('id_question', $id_question);
		$this->db->where('option_true', 1);
		return $this->db->get('question_option')->row_object();
	}
	public function getQuizByCategory($id_category_quiz) {
		$this->db->where('id_category_quiz', $id_category_quiz);
		$this->db->where('quiz_hide', 0);
		return $this->db->get('ms_quiz')->result_object();
	}
	public function getQuizClassByQuizClass($id_quiz,$id_class) {
		$this->db->where('id_quiz', $id_quiz);
		$this->db->where('id_class', $id_class);
		return $this->db->get('quiz_class')->row_object();
	}
	public function getQuizCategoryById($id_category_quiz) {
		$this->db->where('id_category_quiz', $id_category_quiz);
		$this->db->where('category_quiz_hide', 0);
		return $this->db->get('ms_category_quiz')->row_object();
	}
	public function getQuizQuestionByLesson($id_lQuiz) {
		return $this->db->query("SELECT quiz_question.*,ms_question.question_,ms_question.question_image FROM quiz_question LEFT JOIN ms_question ON quiz_question.id_question = ms_question.id_question WHERE quiz_question.qQuiz_hide = 0 AND ms_question.question_hide = 0 AND quiz_question.id_lQuiz = '$id_lQuiz' ORDER BY quiz_question.id_qQuiz ASC")->result_object();
	}
	public function getQuizAnalyticByCondition($id_quiz,$id_lQuiz,$id_qQuiz) {
		$this->db->where('id_quiz', $id_quiz);
		$this->db->where('id_lQuiz', $id_lQuiz);
		$this->db->where('id_qQuiz', $id_qQuiz);
		return $this->db->get('quiz_analytic')->result_object();
	}
	public function getQuizAnalyticByCondition_4($id_quiz,$id_lQuiz,$id_qQuiz) {
		return $this->db->query("
				SELECT quiz_analytic.*,question_option.option_,question_option.option_image FROM quiz_analytic 
				LEFT JOIN question_option ON quiz_analytic.aQuiz_option_id = question_option.id_option 
				WHERE quiz_analytic.id_quiz = '$id_quiz' AND quiz_analytic.id_lQuiz = '$id_lQuiz' AND quiz_analytic.id_qQuiz = '$id_qQuiz' 
				ORDER BY quiz_analytic.id_aQuiz ASC
			")->result_object();
	}
	public function getOptionTrueByQuestion($id_question) {
		$this->db->where('id_question', $id_question);
		$this->db->where('option_true', 1);
		$this->db->where('option_hide', 0);
		return $this->db->get('question_option')->row_object();
	}
	public function getQuizAnalyticByQuiz($id_quiz) {
		return $this->db->query("
				SELECT quiz_analytic.*,question_option.option_,question_option.option_image FROM quiz_analytic 
				LEFT JOIN question_option ON quiz_analytic.aQuiz_option_id = question_option.id_option 
				WHERE quiz_analytic.id_quiz = '$id_quiz' 
				ORDER BY quiz_analytic.id_aQuiz ASC
			")->result_object();
	}
	public function getQuizTitle() {
		$this->db->order_by('qTitle_name', 'asc');
		return $this->db->get('ms_quiz_title')->result_object();
	}
	public function insertQuizTitle($data) {
		return $this->db->insert('ms_quiz_title', $data);
	}
	public function updateQuizTitle($data) {
		$this->db->where('id_qTitle', $data['id_qTitle']);
		return $this->db->update('ms_quiz_title', $data);
	}
	public function deleteQuizTitle($id_qTitle) {
		$this->db->where('id_qTitle', $id_qTitle);
		return $this->db->delete('ms_quiz_title');
	}
}

/* End of file QuizModel.php */
/* Location: .//Users/admin/Webapp/ujian-online/models/QuizModel.php */