<style type="text/css">
	table.table tbody tr td {
		background-color: transparent !important;
	}
</style>
<div class="panel panel-info">
    <div class="panel-heading">
        <h3 class="panel-title">List Ujian</h3>
    </div>
    <div class="panel-body">
        <div class="table-responsive">
            <table class="table datatable table-condensed">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Pelajaran - Tipe</th>
                        <th>KKM</th>
                        <th>Lama Ujian</th>
                        <th>Soal</th>
                        <th>Penulis</th>
                        <th style="width:5%"></th>
                    </tr>
                </thead>
                <tbody>
                	<?php foreach ($dataAssignments as $row => $value): ?>
	                    <tr>
	                        <td><?= $row + 1 ?></td>
	                        <td><?= $value->lesson_name.' - '.$value->assignment_type ?></td>
	                        <td>
	                        	<?php if ($studentClass['class'] == 'XII'): ?>
	                        		<?php foreach ($studentClass['university'] as $r => $v): ?>
	                        			<b><?= $r + 1 ?>.</b> <?= $v->university_name ?> - <?= $v->department_name ?> ( <?= $v->department_pg ?>% )<br />
	                        		<?php endforeach ?>
	                        	<?php else: ?>
	                        		<?= $value->assignment_kkm ?>%
	                        	<?php endif ?>
	                        </td>
	                        <td><?= $value->assignment_duration ?> Menit</td>
	                        <td><?= $value->totalQuestion ?> Soal</td>
	                        <td><?= $value->assignment_author ?></td>
	                        <td>
	                        	<a href="#question<?= $row ?>" data-toggle="modal" class="btn btn-primary"><i class="fa fa-pencil"></i> Ujian</a>
	                        </td>
	                    </tr>
	                    <!-- MODAL -->
	                    <div class="modal fade" id="question<?= $row ?>">
	                    	<div class="modal-dialog" style="width:30%">
	                    		<div class="modal-content">
	                    			<div class="modal-header">
	                    				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
	                    				<h4 class="modal-title">Anda sudah siap ingin melaksanakan ujian ?</h4>
	                    			</div>
	                    			<div class="modal-body">
	                    				<form action="<?= site_url('exam/begin') ?>" method="POST">
	                    					<input type="hidden" name="id_assignment" value="<?= $value->id_assignment ?>">
	                    					<div class="form-group">
	                    						<label>Kata Sandi Ujian</label>
	                    						<input type="text" class="form-control" name="assignment_password" required placeholder="Masukan kata sandi..">
	                    					</div>
	                    			</div>
	                    			<div class="modal-footer">
	                    				<button type="submit" class="btn btn-primary btn-block">Ya, Saya siap!</button>
	                    			</div>
	                    			</form>
	                    		</div>
	                    	</div>
	                    </div>
                	<?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>
</div>