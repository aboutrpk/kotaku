<style type="text/css">
	table.table tbody tr td {
		background-color: transparent !important;
	}
</style>
<div class="panel panel-info">
    <div class="panel-heading">
        <h3 class="panel-title">List Ujian</h3>
    </div>
    <div class="panel-body">
        <div class="table-responsive">
            <table class="table datatable table-condensed">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Judul Ujian (Kategori)</th>
                        <th style="width:30%">Pelajaran (Total Soal - Bobot)</th>
                        <th>Jam Mulai</th>
                        <th>Jam Selesai</th>
                        <th>Lama Ujian</th>
                        <th style="width:5%"></th>
                    </tr>
                </thead>
                <tbody>
                	<?php foreach ($dataQuiz as $row => $value): ?>
	                    <tr>
	                        <td><?= $row + 1 ?></td>
	                        <td><?= $value->quiz_title ?><br /> <b>(<?= $value->category_quiz_name ?>)</b></td>
	                        <td>
	                        	<?php foreach ($value->lessons as $r => $v): ?>
	                        		<?= $v->lesson_name ?> <b>(<?= $v->lQuiz_total_question ?> Soal - <?= $v->lQuiz_weight ?>%)</b><br />
	                        	<?php endforeach ?>
	                        </td>
	                        <td><?= substr($value->quiz_start, 0,16) ?></td>
	                        <td><?= substr($value->quiz_end, 0,16) ?></td>
	                        <td><?= $value->quiz_duration ?> Menit</td>
	                        <td>
	                        	<?php if ($value->done): ?>
	                        		<a href="<?= site_url('exam/report_sbmptn/'.$value->id_quiz) ?>" class="btn btn-info"><i class="fa fa-file"></i> Lihat Laporan</a>
	                        	<?php else: ?>
	                        		<?php if ($value->lessons): ?>
		                        		<a href="#question<?= $row ?>" data-toggle="modal" class="btn btn-primary"><i class="fa fa-pencil"></i> Ujian</a>
		                        	<?php else: ?>
		                        		<center><i>Ujian tidak tersedia</i></center>
		                        	<?php endif ?>
	                        	<?php endif ?>
	                        </td>
	                    </tr>
	                    <!-- MODAL -->
	                    <div class="modal fade" id="question<?= $row ?>">
	                    	<div class="modal-dialog" style="width:30%">
	                    		<div class="modal-content">
	                    			<div class="modal-header">
	                    				<button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
	                    				<h4 class="modal-title">Anda sudah siap ingin melaksanakan ujian ?</h4>
	                    			</div>
	                    			<div class="modal-body">
	                    				<form action="<?= site_url('exam/begin_sbmptn') ?>" method="POST">
	                    					<input type="hidden" name="id_quiz" value="<?= $value->id_quiz ?>">
	                    					<div class="form-group">
	                    						<label>Kata Sandi Ujian</label>
	                    						<input type="text" class="form-control" name="quiz_password" required placeholder="Masukan kata sandi..">
	                    					</div>
	                    			</div>
	                    			<div class="modal-footer">
	                    				<button type="submit" class="btn btn-primary btn-block">Ya, Saya siap!</button>
	                    			</div>
	                    			</form>
	                    		</div>
	                    	</div>
	                    </div>
                	<?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>
</div>