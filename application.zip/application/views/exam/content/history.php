<style type="text/css">
	table.table tbody tr td {
		background-color: transparent !important;
	}
</style>
<div class="panel panel-info">
    <div class="panel-heading">
        <h3 class="panel-title">Riwayat Ujian Non-SBMPTN</h3>
    </div>
    <div class="panel-body">
        <div class="table-responsive">
            <table class="table datatable table-condensed">
                <thead>
                    <tr>
                        <th>#</th>
                        <th>Pelajaran - Tipe</th>
                        <th>KKM</th>
                        <th>Lama Ujian</th>
                        <th>Soal</th>
                        <th>Penulis</th>
                        <th>Dikumpulkan</th>
                        <th style="width:5%">Hasil Ujian</th>
                    </tr>
                </thead>
                <tbody>
                	<?php foreach ($dataAssignments as $row => $value): ?>
	                    <tr>
	                        <td><?= $row + 1 ?></td>
	                        <td><?= $value->lesson_name.' - '.$value->assignment_type ?></td>
	                        <td>
                                <?php if ($studentUniversity['class'] == 'XII'): ?>
                                    <?php foreach ($studentUniversity['university'] as $r => $v): ?>
                                        <b><?= $r + 1 ?>.</b> <?= $v->university_name ?> - <?= $v->department_name ?> ( <?= $v->department_pg ?>% )<br />
                                    <?php endforeach ?>
                                <?php else: ?>
                                    <?= $value->assignment_kkm ?>%
                                <?php endif ?>
                            </td>
	                        <td><?= $value->assignment_duration ?> Menit</td>
	                        <td><?= $value->totalQuestion ?> Soal</td>
	                        <td><?= $value->assignment_author ?></td>
	                        <td><?= $value->resultCreated ?></td>
	                        <td>
	                        	<?php if ($value->show_report == 1): ?>
	                        		<a href="<?= site_url('exam/report/'.$value->id_assignment) ?>" class="btn btn-primary"><i class="fa fa-file"></i> Lihat</a>
	                        	<?php else: ?>
	                        		<center>
	                        			<i>Tidak diperbolehkan</i>
	                        		</center>
	                        	<?php endif ?>
	                        </td>
	                    </tr>
                	<?php endforeach ?>
                </tbody>
            </table>
        </div>
    </div>
</div>
<?php if ($this->session->userdata('class') == 'XII'): ?>
    <br />
    <div class="panel panel-info">
        <div class="panel-heading">
            <h3 class="panel-title">Riwayat Ujian SBMPTN</h3>
        </div>
        <div class="panel-body">
            <div class="table-responsive">
                <table class="table datatable table-condensed">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Judul Ujian (Kategori)</th>
                            <th style="width:30%">Pelajaran (Total Soal - Bobot)</th>
                            <th>Jam Mulai</th>
                            <th>Jam Selesai</th>
                            <th>Lama Ujian</th>
                            <th style="width:5%"></th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dataQuiz as $row => $value): ?>
                            <tr>
                                <td><?= $row + 1 ?></td>
                                <td><?= $value->quiz_title ?><br /> <b>(<?= $value->category_quiz_name ?>)</b></td>
                                <td>
                                    <?php foreach ($value->lessons as $r => $v): ?>
                                        <?= $v->lesson_name ?> <b>(<?= $v->lQuiz_total_question ?> Soal - <?= $v->lQuiz_weight ?>%)</b><br />
                                    <?php endforeach ?>
                                </td>
                                <td><?= substr($value->quiz_start, 0,16) ?></td>
                                <td><?= substr($value->quiz_end, 0,16) ?></td>
                                <td><?= $value->quiz_duration ?> Menit</td>
                                <td>
                                    <?php if ($value->done): ?>
                                        <a href="<?= site_url('exam/report_sbmptn/'.$value->id_quiz) ?>" class="btn btn-info"><i class="fa fa-file"></i> Lihat Laporan</a>
                                    <?php else: ?>
                                        <?php if ($value->lessons): ?>
                                            <a href="#question<?= $row ?>" data-toggle="modal" class="btn btn-primary"><i class="fa fa-pencil"></i> Ujian</a>
                                        <?php else: ?>
                                            <center><i>Ujian tidak tersedia</i></center>
                                        <?php endif ?>
                                    <?php endif ?>
                                </td>
                            </tr>
                        <?php endforeach ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
<?php endif ?>