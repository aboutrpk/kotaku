<div class="panel panel-info">
    <div class="panel-heading">
        <h3 class="panel-title">Dashboard</h3>
    </div>
    <div class="panel-body">
        <legend>Panduan menggunakan aplikasi</legend>
    </div>
</div>