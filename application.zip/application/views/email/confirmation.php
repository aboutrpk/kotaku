<!DOCTYPE html>
<html>

<head>
    <style>
        .button {
            background-color: #2ac91c;
            border: none;
            color: white;
            padding: 16px 30px;
            text-align: center;
            text-decoration: none;
            display: inline-block;
            font-size: 20px;
            margin: 4px 2px;
            cursor: pointer;
        }
    </style>
</head>

<body>
    Selamat telah mendaftar pada Rumah Konsul M-BRIO, <?= $data['student_name'] ?><br />
    Anda bergabung menjadi Sahabat M-BRIO, dengan :<br /><br />
    Username : <?= $data['student_username'] ?><br /><br />

    Silahkan lakukan konfirmasi email dengan membuka link di bawah ini :
    <br /><br />

    <a href="<?= site_url('Auth/link_confirmation/' . $data['student_link']) ?>" class="button">Konfirmasi Email Pendaftaran</a>
    <br />
    Note : Link akan berakhir dalam waktu 2 hari!

    <br /><br />
    Terimakasih<br />
    ---------------------------------------------------------------------------------------------------------------------<br />
    Email ini dibuat secara otomatis. Mohon tidak mengirimkan balasan ke email ini.<br /><br />
    Jika butuh bantuan, gunakan halaman <a href="<?= ('https://rumahmbrio.com/#contact-us') ?>">Kontak Kami</a>
</body>

</html>