<style type="text/css">
    .label { width: 100%; background-color: grey; color: white; padding: 10px; border-radius: 3px; }
    .label.label-success { background-color: green; }
    .label.label-danger { background-color: maroon; }
</style>
<!-- Page Title Area -->
<div class="row page-title clearfix" style="margin-top:-10px">
    <div class="page-title-left">
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
        <h6 class="page-title-heading mr-0 mr-r-5">
            List Pertanyaan Pada Ujian : <?= $dataQuiz->quiz_title ?> (<?= $dataLessonQuiz->lesson_name ?>)
        </h6>
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
    </div>
    <!-- /.page-title-left -->
    <div class="page-title-right d-inline-flex">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('page/quiz_sbmptn') ?>">List Ujian</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('page/quiz_lesson/'.$dataQuiz->id_quiz) ?>">List Pelajaran</a></li>
            <li class="breadcrumb-item active">List Pertanyaan</li>
        </ol>
    </div>
</div><!-- /.page-title -->

<div class="widget-list row" style="margin-top:10px;margin-bottom:80px">
    <div class="widget-holder widget-full-height col-md-12">
        <div class="widget-bg">
            <div class="widget-body">
                <a href="<?= site_url('page/quiz_lesson/'.$dataQuiz->id_quiz) ?>" class="btn btn-primary btn-sm"><i class="feather feather-arrow-left"></i>&nbsp; Kembali</a>
                <a href="<?= site_url('page/quiz_question_add/'.$dataQuiz->id_quiz.'/'.$dataLessonQuiz->id_lQuiz) ?>" class="btn btn-info btn-sm">Tambah Pertanyaan</a>
                <a href="<?= site_url('page/use_question_quiz/'.$dataQuiz->id_quiz.'/'.$dataLessonQuiz->id_lQuiz) ?>" class="btn btn-success btn-sm">Gunakan Soal Lain</a><br />
                <table class="table table-striped table-responsive" data-toggle="datatables">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Pertanyaan</th>
                            <th>Total Jawaban</th>
                            <th style="width:15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dataQuestion as $row => $value): ?>
                            <tr>
                                <td><?= $row + 1 ?></td>
                                <td><?= strip_tags($value->question_) ?></td>
                                <td><?= $value->totalOption ?> Jawaban</td>
                                <td>
                                    <a title="Ubah Pertanyaan" href="<?= site_url('page/quiz_question_edit/'.$dataQuiz->id_quiz.'/'.$dataLessonQuiz->id_lQuiz.'/'.$value->id_qQuiz) ?>" class="btn btn-primary btn-sm"><i class="feather feather-edit"></i></a>
                                    <a title="Hapus Pertanyaan" href="#delete<?= $row ?>" data-toggle="modal" class="btn btn-danger btn-sm"><i class="feather feather-trash"></i></a>
                                </td>
                            </tr>
                            <!-- MODAL DELETE -->
                            <div class="modal modal-danger fade" id="delete<?= $row ?>">
                                <div class="modal-dialog modal-md">
                                    <div class="modal-content">
                                        <div class="modal-header text-inverse">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title">Anda yakin ingin menghapus data ini?</h4>
                                        </div>
                                        <div class="modal-footer" style="padding:10px">
                                            <a href="<?= site_url('QuizCtrl/delete_question/'.$value->id_qQuiz) ?>" class="btn btn-outline-danger btn-block"><i class="feather feather-check-square"></i> Ya, Hapus data ini!</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            
                        <?php endforeach ?>                   
                    </tbody>
                </table>
            </div><!-- /.widget-body -->
        </div><!-- /.widget-bg -->
    </div>
</div>