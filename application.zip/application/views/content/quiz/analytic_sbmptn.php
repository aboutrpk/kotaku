<div class="row page-title clearfix" style="margin-top:-10px">
    <div class="page-title-left">
        <h6 class="page-title-heading mr-0 mr-r-5">Analisa Ujian</h6>
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
    </div>
    <!-- /.page-title-left -->
    <div class="page-title-right d-inline-flex">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Analisa Ujian</li>
        </ol>
    </div>
</div><!-- /.page-title -->

<div class="widget-list row" style="margin-top:10px;margin-bottom:0px">
    <div class="widget-holder widget-full-height col-md-12">
        <div class="widget-bg">
            <div class="widget-body">
                <form action="<?= site_url('page/analytics_sbmptn') ?>" method="POST">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Kategori SBMPTN</label>
                            <select class="form-control" name="id_category_quiz" id="id_category_quiz">
                                <?php foreach ($dataCategory as $row => $value): ?>
                                    <option <?= ($category_selected == $value->id_category_quiz ? 'selected' : '') ?> value="<?= $value->id_category_quiz ?>"><?= $value->category_quiz_name ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Kelas</label>
                            <select class="form-control" name="id_class" id="id_class">
                                <?php foreach ($dataClass as $row => $value): ?>
                                    <?php if ($value->class_level == 'XII'): ?>
                                        <option <?= ($class_selected == $value->id_class ? 'selected' : '') ?> value="<?= $value->id_class ?>"><?= $value->class_name ?></option>
                                    <?php endif ?>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-1">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button id="buttonSubmit" type="submit" class="btn btn-outline-primary btn-block"><i class="feather feather-search"></i> Cari</button>
                        </div>
                    </div>
                </div><!-- / Row -->
                </form>
            </div><!-- / BODY -->
        </div><!-- / BG -->
    </div>
</div>

<?php if (isset($dataQuiz)): ?>
    <div class="widget-list row" style="margin-top:10px;margin-bottom:0px">
        <div class="widget-holder widget-full-height col-md-12">
            <div class="widget-bg">
                <div class="widget-body">
                    <legend>Rincian Laporan</legend>
                    <div class="table-responsive">
                        <table class="table table-bordered" data-toggle="datatables">
                            <thead>
                                <th style="width:5%">#</th>
                                <th>Tipe Ujian</th>
                                <th>Penulis</th>
                                <th style="width:30%">Tanggal Mulai - Tanggal Selesai</th>
                                <th>Pelajaran</th>
                                <th style="width: 10%">Export</th>
                            </thead>
                            <tbody>
                                <?php foreach ($dataQuiz as $row => $value): ?>
                                    <tr>
                                        <td><?= $row + 1 ?></td>
                                        <td><?= $value->quiz_title ?></td>
                                        <td><?= $value->quiz_author_name ?></td>
                                        <td><?= $value->quiz_start ?> - <?= $value->quiz_end ?></td>
                                        <td>
                                            <i class="feather feather-arrow-right"></i> <a style="color:blue;border-bottom: 1px solid blue;" href="<?= site_url('page/analytics_sbmptn_lesson/'.$value->id_quiz.'/all/'.$class_selected) ?>" target="_blank">
                                                    Semua Pelajaran
                                                </a><br />
                                            <?php foreach ($value->quiz_lesson as $r => $v): ?>
                                                <i class="feather feather-arrow-right"></i> <a style="color:blue;border-bottom: 1px solid blue;" href="<?= site_url('page/analytics_sbmptn_lesson/'.$value->id_quiz.'/'.$v->id_lQuiz.'/'.$class_selected) ?>" target="_blank">
                                                    <?= $v->lesson_name ?>
                                                </a><br />
                                            <?php endforeach ?>
                                        </td>
                                        <td>
                                            <a href="<?= site_url('page/analytics_sbmptn_export/'.$value->id_quiz) ?>" target="_blank" class="btn btn-success">Export Excel</a>
                                        </td>
                                    </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                    <br /><br />
                </div><!-- / BODY -->
            </div><!-- / BG -->
        </div>
    </div>
<?php endif ?>