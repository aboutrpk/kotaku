<div class="row page-title clearfix" style="margin-top:-10px">
    <div class="page-title-left">
        <h6 class="page-title-heading mr-0 mr-r-5">Hasil Ujian</h6>
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
    </div>
    <!-- /.page-title-left -->
    <div class="page-title-right d-inline-flex">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Hasil Ujian</li>
        </ol>
    </div>
</div><!-- /.page-title -->

<div class="widget-list row" style="margin-top:10px;margin-bottom:0px">
    <div class="widget-holder widget-full-height col-md-12">
        <div class="widget-bg">
            <div class="widget-body">
                <form action="<?= site_url('page/results_sbmptn') ?>" method="POST">
                <div class="row">
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Kategori SBMPTN</label>
                            <select class="form-control" name="id_category_quiz" id="id_category_quiz">
                                <?php foreach ($dataCategory as $row => $value): ?>
                                    <option <?= ($category_selected == $value->id_category_quiz ? 'selected' : '') ?> value="<?= $value->id_category_quiz ?>"><?= $value->category_quiz_name ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-3">
                        <div class="form-group">
                            <label>Kelas</label>
                            <select class="form-control" name="id_class" id="id_class">
                                <?php foreach ($dataClass as $row => $value): ?>
                                    <?php if ($value->class_level == 'XII'): ?>
                                        <option <?= ($class_selected == $value->id_class ? 'selected' : '') ?> value="<?= $value->id_class ?>"><?= $value->class_name ?></option>
                                    <?php endif ?>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-1">
                        <div class="form-group">
                            <label>&nbsp;</label>
                            <button id="buttonSubmit" type="submit" class="btn btn-outline-primary btn-block"><i class="feather feather-search"></i> Cari</button>
                        </div>
                    </div>
                </div><!-- / Row -->
                </form>
            </div><!-- / BODY -->
        </div><!-- / BG -->
    </div>
</div>

<!-- SHOW REPORT -->
<?php if (isset($dataQuiz)): ?>
    <style type="text/css">
        table.table tr th { text-align: center; font-size: 12px; }
    </style>
    <div class="widget-list row" style="margin-top:10px;margin-bottom:0px">
        <div class="widget-holder widget-full-height col-md-12">
            <div class="widget-bg">
                <div class="widget-body">
                    <a href="<?= site_url('page/sbmptn_export_excel') ?>" target="_blank" class="btn btn-success btn-sm" style="float: right;">Export Excel</a>
                    <legend>Rincian Laporan</legend>
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover">
                            <thead>
                                <tr>
                                    <th style="vertical-align : middle;" rowspan="4">NO</th>
                                    <th style="vertical-align : middle;" rowspan="4">NIS</th>
                                    <th style="vertical-align : middle;" rowspan="4">NAMA <br /> PESERTA</th>
                                    <?php foreach ($dataQuiz as $row => $value): ?>
                                        <th rowspan="1" colspan="<?= count($value->quiz_lesson) * 4 ?>"><?= $value->quiz_title ?></th>
                                    <?php endforeach ?>
                                    <th style="vertical-align : middle;" rowspan="4">TOTAL PG</th>
                                    <th style="vertical-align : middle;" rowspan="4">UNIVERSITAS</th>
                                    <th style="vertical-align : middle;" rowspan="4">NILAI<br />UNIV.</th>
                                    <th style="vertical-align : middle;" rowspan="4">KETERANGAN</th>
                                    <th style="vertical-align : middle;" rowspan="4">TARGET <br /> MINIMAL</th>
                                    <th style="vertical-align : middle;" rowspan="4">KETERANGAN</th>
                                </tr>
                                <tr>
                                    <?php foreach ($dataQuiz as $row => $value): ?>
                                        <?php foreach ($value->quiz_lesson as $r => $v): ?>
                                            <th rowspan="1" colspan="4"><?= $v->lesson_name ?></th>
                                        <?php endforeach ?>
                                    <?php endforeach ?>
                                </tr>
                                <tr>
                                    <?php foreach ($dataQuiz as $row => $value): ?>
                                        <?php foreach ($value->quiz_lesson as $r => $v): ?>
                                            <th>B</th>
                                            <th>S</th>
                                            <th>K</th>
                                            <th>Score</th>
                                        <?php endforeach ?>
                                    <?php endforeach ?>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($dataStudent as $row => $value): ?>
                                    <?php
                                        // INIT TEMP DATA //
                                        $totalQuestion = 0;
                                        $totalAnswered = 0;
                                        $totalScore = 0;
                                    ?>
                                    <tr>
                                        <td><?= $row + 1 ?></td>
                                        <td><?= $value->student_nis ?></td>
                                        <td><?= $value->student_name ?></td>
                                        <?php foreach ($dataQuiz as $r => $v): ?>
                                            <?php $totalQuestion += $v->totalQuestion; ?>
                                            <?php foreach ($v->quiz_lesson as $rLesson => $vLesson): ?>
                                                <!-- IF STUDENT IS EXIST -->
                                                <?php if ($vLesson->students): ?>
                                                    <?php
                                                        $rQuiz_total_true = 0;
                                                        $rQuiz_total_false = 0;
                                                        $rQuiz_total_empty = 0;
                                                        $rQuiz_last_score = 0;
                                                        $valStudentShow = false;
                                                        foreach ($vLesson->students as $rStudent => $vStudent):
                                                            if ($value->id_student == $vStudent->id_student):
                                                                $rQuiz_total_true = $vStudent->rQuiz_total_true;
                                                                $rQuiz_total_false = $vStudent->rQuiz_total_false;
                                                                $rQuiz_total_empty = $vStudent->rQuiz_total_empty;
                                                                $rQuiz_last_score = $vStudent->rQuiz_last_score;
                                                                $valStudentShow = true;
                                                                $totalAnswered += $vStudent->totalAnswered;
                                                                $totalScore += $vStudent->rQuiz_last_score;
                                                            endif;
                                                        endforeach;
                                                    ?>
                                                    <!-- ANOTHER POPS -->
                                                    <?php if ($valStudentShow): ?>
                                                        <td><?= $rQuiz_total_true ?></td>
                                                        <td><?= $rQuiz_total_false ?></td>
                                                        <td><?= $rQuiz_total_empty ?></td>
                                                        <td><?= $rQuiz_last_score ?></td>
                                                    <?php else: ?>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                        <td>-</td>
                                                    <?php endif ?>
                                                <?php else: ?>
                                                    <td>-</td>
                                                    <td>-</td>
                                                    <td>-</td>
                                                    <td>-</td>
                                                <?php endif ?>
                                                <!-- END STUDENT EXIST VALIDATIOn -->
                                            <?php endforeach ?>
                                        <?php endforeach ?>
                                        <td><?= $totalScore ?></td>
                                        <td>
                                            <?php foreach ($value->university as $r => $v): ?>
                                                <?= $v->university_name ?> (<b><?= $v->department_name ?></b>)
                                                <br />
                                            <?php endforeach ?>
                                        </td>
                                        <td>
                                            <?php foreach ($value->university as $r => $v): ?>
                                                <?= $v->department_pg ?>
                                                <br />
                                            <?php endforeach ?>
                                        </td>
                                        <td>
                                            <?php foreach ($value->university as $r => $v): ?>
                                                <b><?= ($totalScore >= $v->department_pg ? 'LULUS' : 'GAGAL'); ?></b>
                                                <br />
                                            <?php endforeach ?>
                                        </td>
                                        <td>
                                            <?php foreach ($dataQuiz as $r => $v): ?>
                                                <?= $v->quiz_title ?>: <b><?= $v->quiz_kkm ?></b><br />
                                            <?php endforeach ?>
                                        </td>
                                        <td>
                                            <?php foreach ($dataQuiz as $r => $v): ?>
                                                <?php if ($totalScore >= $v->quiz_kkm): ?>
                                                    TARGET TERPENUHI
                                                <?php else: ?>
                                                    TIDAK TERPENUHI
                                                <?php endif ?>
                                            <?php endforeach ?>
                                        </td>
                                    </tr>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                    <br /><br />
                </div><!-- / BODY -->
            </div><!-- / BG -->
        </div>
    </div>
<?php endif ?>