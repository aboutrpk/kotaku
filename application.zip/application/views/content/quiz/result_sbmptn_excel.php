<?php
    header("Content-type: application/octet-stream");
    header("Content-disposition: attachement; filename=laporan-ujian-sbmptn.xls");
    header("Pragma: no-cache");
    header("Expires: 0");
?>
<!DOCTYPE html>
<html>
    <head>
        <title>Laporan Ujian SBMPTN <?= $dataCategory->category_quiz_name ?> - <?= $dataClass->class_name ?> </title>
    </head>
    <body>
        <style type="text/css">
            table.table {
                border-collapse: collapse;
                width: 100%;
            }
            table.table tr th { text-align: center; font-size: 12px; padding: 4px; }
            table.table tr td { padding: 4px; }
        </style>
        <h3>LAPORAN TRY OUT SBMPTN</h3>
        <table class="table" border="1">
            <thead>
                <tr>
                    <th style="vertical-align : middle;" rowspan="3">NO</th>
                    <th style="vertical-align : middle;" rowspan="3">NIS</th>
                    <th style="vertical-align : middle;" rowspan="3">NAMA <br /> PESERTA</th>
                    <?php foreach ($dataQuiz as $row => $value): ?>
                        <th rowspan="1" colspan="<?= count($value->quiz_lesson) * 4 ?>"><?= $value->quiz_title ?></th>
                    <?php endforeach ?>
                    <th style="vertical-align : middle;" rowspan="3">TOTAL PG</th>
                    <th style="vertical-align : middle;" rowspan="3">UNIVERSITAS</th>
                    <th style="vertical-align : middle;" rowspan="3">NILAI<br />UNIV.</th>
                    <th style="vertical-align : middle;" rowspan="3">KETERANGAN</th>
                    <th style="vertical-align : middle;" rowspan="3">TARGET <br /> MINIMAL</th>
                    <th style="vertical-align : middle;" rowspan="3">KETERANGAN</th>
                </tr>
                <tr>
                    <?php foreach ($dataQuiz as $row => $value): ?>
                        <?php foreach ($value->quiz_lesson as $r => $v): ?>
                            <th rowspan="1" colspan="4"><?= $v->lesson_name ?></th>
                        <?php endforeach ?>
                    <?php endforeach ?>
                </tr>
                <tr>
                    <?php foreach ($dataQuiz as $row => $value): ?>
                        <?php foreach ($value->quiz_lesson as $r => $v): ?>
                            <th>B</th>
                            <th>S</th>
                            <th>K</th>
                            <th>Score</th>
                        <?php endforeach ?>
                    <?php endforeach ?>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dataStudent as $row => $value): ?>
                    <?php
                        // INIT TEMP DATA //
                        $totalQuestion = 0;
                        $totalAnswered = 0;
                        $totalScore = 0;
                    ?>
                    <tr>
                        <td><?= $row + 1 ?></td>
                        <td><?= $value->student_nis ?></td>
                        <td><?= $value->student_name ?></td>
                        <?php foreach ($dataQuiz as $r => $v): ?>
                            <?php $totalQuestion += $v->totalQuestion; ?>
                            <?php foreach ($v->quiz_lesson as $rLesson => $vLesson): ?>
                                <!-- IF STUDENT IS EXIST -->
                                <?php if ($vLesson->students): ?>
                                    <?php
                                        $rQuiz_total_true = 0;
                                        $rQuiz_total_false = 0;
                                        $rQuiz_total_empty = 0;
                                        $rQuiz_last_score = 0;
                                        $valStudentShow = false;
                                        foreach ($vLesson->students as $rStudent => $vStudent):
                                            if ($value->id_student == $vStudent->id_student):
                                                $rQuiz_total_true = $vStudent->rQuiz_total_true;
                                                $rQuiz_total_false = $vStudent->rQuiz_total_false;
                                                $rQuiz_total_empty = $vStudent->rQuiz_total_empty;
                                                $rQuiz_last_score = $vStudent->rQuiz_last_score;
                                                $valStudentShow = true;
                                                $totalAnswered += $vStudent->totalAnswered;
                                                $totalScore += $vStudent->rQuiz_last_score;
                                            endif;
                                        endforeach;
                                    ?>
                                    <!-- ANOTHER POPS -->
                                    <?php if ($valStudentShow): ?>
                                        <td><?= $rQuiz_total_true ?></td>
                                        <td><?= $rQuiz_total_false ?></td>
                                        <td><?= $rQuiz_total_empty ?></td>
                                        <td><?= $rQuiz_last_score ?></td>
                                    <?php else: ?>
                                        <td>-</td>
                                        <td>-</td>
                                        <td>-</td>
                                        <td>-</td>
                                    <?php endif ?>
                                <?php else: ?>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                    <td>-</td>
                                <?php endif ?>
                                <!-- END STUDENT EXIST VALIDATIOn -->
                            <?php endforeach ?>
                        <?php endforeach ?>
                        <td><?= $totalScore ?></td>
                        <td>
                            <?php foreach ($value->university as $r => $v): ?>
                                <?= $v->university_name ?> (<b><?= $v->department_name ?></b>)
                                <br />
                            <?php endforeach ?>
                        </td>
                        <td>
                            <?php foreach ($value->university as $r => $v): ?>
                                <?= $v->department_pg ?>
                                <br />
                            <?php endforeach ?>
                        </td>
                        <td>
                            <?php foreach ($value->university as $r => $v): ?>
                                <b><?= ($totalScore >= $v->department_pg ? 'LULUS' : 'GAGAL'); ?></b>
                                <br />
                            <?php endforeach ?>
                        </td>
                        <td>
                            <?php foreach ($dataQuiz as $r => $v): ?>
                                <?= $v->quiz_title ?>: <b><?= $v->quiz_kkm ?></b><br />
                            <?php endforeach ?>
                        </td>
                        <td>
                            <?php foreach ($dataQuiz as $r => $v): ?>
                                <?php if ($totalScore >= $v->quiz_kkm): ?>
                                    TARGET TERPENUHI
                                <?php else: ?>
                                    TIDAK TERPENUHI
                                <?php endif ?>
                            <?php endforeach ?>
                        </td>
                    </tr>
                <?php endforeach ?>
            </tbody>
        </table>
    </body>
</html>