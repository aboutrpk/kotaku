<div class="widget-list row" style="margin-top:10px;margin-bottom:0px">
    <div class="widget-holder widget-full-height col-md-12">
        <div class="widget-bg">
            <div class="widget-body">
                <a href="<?= site_url('page/analytics_sbmptn_lesson/'.$id_quiz.'/'.$id_lQuiz.'/'.$id_class) ?>" style="float: right;" class="btn btn-sm btn-info"><i class="feather feather-arrow-left"></i> Kembali</a>
                <legend>Pertanyaan :</legend>
                <div class="row" style="margin-left: 20px;">
                    <?php if ($dataQuestion->question_image == ''): ?>
                        <div class="col-sm-12">
                            <i class="feather feather-arrow-right"></i> <?= $dataQuestion->question_ ?>
                        </div>
                    <?php else: ?>
                        <div class="col-sm-8">
                            <i class="feather feather-arrow-right"></i> <?= $dataQuestion->question_ ?>
                        </div>
                        <div class="col-sm-4">
                            <img src="<?= base_url('assets/images/questions/'.$dataQuestion->question_image) ?>" class="img-thumbnail">
                        </div>
                    <?php endif ?>
                </div><!-- / ROW -->
                <br />
                <legend>Jawaban Benar :</legend>
                <?php if ($dataQuestion->option_true): ?>
                    <div class="row" style="margin-left: 20px;">
                        <?php if ($dataQuestion->option_true->option_image == ''): ?>
                            <div class="col-sm-12">
                                <i class="feather feather-arrow-right"></i> <?= $dataQuestion->option_true->option_ ?>
                            </div>
                        <?php else: ?>
                            <div class="col-sm-8">
                                <i class="feather feather-arrow-right"></i> <?= $dataQuestion->option_true->option_ ?>
                            </div>
                            <div class="col-sm-4">
                                <img src="<?= base_url('assets/images/questions/'.$dataQuestion->option_true->option_image) ?>" class="img-thumbnail">
                            </div>
                        <?php endif ?>
                    </div><!-- / ROW -->
                <?php endif ?>
            </div>
        </div>
    </div>
</div>

<!-- DATA STUDENT -->
<style type="text/css">
    span.label {
        width: auto;
        padding: 5px 10px;
        border-radius: 3px;
        color: white;
        text-align: center;
    }
    span.label.label-success { background-color: #44bd32 }
    span.label.label-danger { background-color: #c23616 }
</style>
<div class="widget-list row" style="margin-top:10px;margin-bottom:0px">
    <div class="widget-holder widget-full-height col-md-12">
        <div class="widget-bg">
            <div class="widget-body">
                <!-- <legend>Rincian Laporan Ujian: <?= $dataQuiz->quiz_title ?> - <?= $quiz_lesson->lesson_name ?></legend> -->
                <div class="table-responsive">
                    <table class="table table-bordered" data-toggle="datatables">
                        <thead>
                            <th style="width:5%">#</th>
                            <th>Nama Siswa</th>
                            <th>Jawaban</th>
                            <th>Status</th>
                        </thead>
                        <tbody>
                            <?php foreach ($dataStudent as $row => $value): ?>
                                <?php
                                    $student_option = '<center>-- Belum Menjawab --</center>';
                                    $student_status = '<center>-- Belum Menjawab --</center>';
                                    foreach ($dataAnalytics as $r => $v) {
                                        if ($v->id_student == $value->id_student) {
                                            $student_option = $v->option_;
                                            if ($v->aQuiz_status == 'true') {
                                                $student_status = '<span class="label label-success">BENAR</span>';
                                            } elseif($v->aQuiz_status == 'false') {
                                                $student_status = '<span class="label label-danger">SALAH</span>';
                                            }
                                        }
                                    }
                                ?>
                                <tr>
                                    <td><?= $row + 1 ?></td>
                                    <td><?= $value->student_name ?></td>
                                    <td><?= $student_option ?></td>
                                    <td><center><?= $student_status ?></center></td>
                                </tr>
                            <?php endforeach ?>
                        </tbody>
                    </table>
                </div>
                <br /><br />
            </div><!-- / BODY -->
        </div><!-- / BG -->
    </div>
</div>