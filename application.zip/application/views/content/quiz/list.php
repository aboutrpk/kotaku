<?php
    $dataOrder = [
        ['value' => 'asc', 'name' => 'Terlama'],
        ['value' => 'desc', 'name' => 'Terbaru'],
        ['value' => 'random', 'name' => 'Acak'],
    ];
?>
<style type="text/css">
    .label { width: 100%; background-color: grey; color: white; padding: 5px; border-radius: 3px; }
    .label.label-success { background-color: #44bd32; }
    .label.label-danger { background-color: #c23616; }
    .label.label-primary { background-color: #0097e6; }
</style>
<!-- Page Title Area -->
<div class="row page-title clearfix" style="margin-top:-10px">
    <div class="page-title-left">
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
        <h6 class="page-title-heading mr-0 mr-r-5">
            Daftar List Ujian SBMPTN
            <a href="#add" data-toggle="modal" class="btn btn-info btn-circle btn-sm"><i class="feather feather-plus"></i></a>
        </h6>
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
    </div>
    <!-- /.page-title-left -->
    <div class="page-title-right d-inline-flex">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">List Ujian SBMPTN</li>
        </ol>
    </div>
</div><!-- /.page-title -->

<div class="widget-list row" style="margin-top:10px;margin-bottom:80px">
    <div class="widget-holder widget-full-height col-md-12">
        <div class="widget-bg">
            <div class="widget-body">
                <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                            <label>Pilih Kategori</label>
                            <select class="form-control" onchange="changeCategory(this.value)">
                                <option value="">-- Tampilkan Semua --</option>
                                <?php foreach ($dataCategory as $row => $value): ?>
                                    <option <?= ($id_category_quiz == $value->id_category_quiz ? 'selected' : '') ?> value="<?= $value->id_category_quiz ?>"><?= $value->category_quiz_name ?></option>
                                <?php endforeach ?>
                            </select>
                        </div>
                    </div>
                </div><!-- / ROW -->
                <table class="table table-striped table-responsive" data-toggle="datatables">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Judul Ujian</th>
                            <!-- <th>Pembuat</th> -->
                            <th>Total Soal</th>
                            <th>Tanggal Mulai</th>
                            <th>Tanggal Selesai</th>
                            <th>Lama Ujian</th>
                            <th>Kata Sandi</th>
                            <!-- <th>Status</th> -->
                            <th style="width:15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dataQuiz as $row => $value): ?>
                            <tr>
                                <td><?= $row + 1 ?></td>
                                <td>
                                    <?= $value->quiz_title ?><br />
                                    <span class="label label-primary"><?= $value->category_quiz_name ?></span>
                                </td>
                                <!-- <td><?= $value->quiz_author_name ?></td> -->
                                <td><?= $value->totalQuestion ?> Soal</td>
                                <td><?= substr($value->quiz_start, 0,16) ?></td>
                                <td><?= substr($value->quiz_end, 0,16) ?></td>
                                <td><?= $value->quiz_duration ?> Menit</td>
                                <td><?= $value->quiz_password ?></td>
                                <!-- <td>
                                    <?php if ($value->quiz_active == 1): ?>
                                        <span class="label label-success">AKTIF</span>
                                    <?php else: ?>
                                        <span class="label label-danger">TIDAK AKTIF</span>
                                    <?php endif ?>
                                </td> -->
                                <td>
                                    <a title="Detail Ujian" href="<?= site_url('page/quiz_lesson/'.$value->id_quiz) ?>" class="btn btn-success btn-sm"><i class="feather feather-layers"></i></a>
                                    <a title="Ubah Data Ujian" href="#edit<?= $row ?>" data-toggle="modal" class="btn btn-primary btn-sm"><i class="feather feather-edit"></i></a>
                                    <a title="Hapus Ujian" href="#delete<?= $row ?>" data-toggle="modal" class="btn btn-danger btn-sm"><i class="feather feather-trash"></i></a>
                                </td>
                            </tr>
                            <!-- MODAL DELETE -->
                            <div class="modal modal-danger fade" id="delete<?= $row ?>">
                                <div class="modal-dialog modal-md">
                                    <div class="modal-content">
                                        <div class="modal-header text-inverse">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title">Anda yakin ingin menghapus data ini?</h4>
                                        </div>
                                        <div class="modal-footer" style="padding:10px">
                                            <a href="<?= site_url('QuizCtrl/deleteQuiz/'.$value->id_quiz) ?>" class="btn btn-outline-danger btn-block"><i class="feather feather-check-square"></i> Ya, Hapus data ini!</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach ?>                   
                    </tbody>
                </table>
            </div><!-- /.widget-body -->
        </div><!-- /.widget-bg -->
    </div>
</div>

<!-- MODAL ADD -->
<div class="modal fade" id="add">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Tambah Ujian</h4>
            </div>
            <div class="modal-body">
                <form action="<?= site_url('QuizCtrl/add') ?>" method="POST">
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Judul Ujian *</label>
                                <!-- <input type="text" class="form-control" name="quiz_title" required placeholder="eg: SAINTEK"> -->
                                <select class="form-control" name="quiz_title" required>
                                    <?php foreach ($dataTitle as $r => $v): ?>
                                        <option value="<?= $v->qTitle_name ?>"><?= $v->qTitle_name ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Kategori Ujian *</label>
                                <select class="form-control" name="id_category_quiz">
                                    <?php foreach ($dataCategory as $r => $v): ?>
                                        <option value="<?= $v->id_category_quiz ?>"><?= $v->category_quiz_name ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Urutkan Soal *</label>
                                <select class="form-control" name="quiz_order">
                                    <?php foreach ($dataOrder as $r => $v): ?>
                                        <option value="<?= $v['value'] ?>"><?= $v['name'] ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Durasi *</label>
                                        <input type="number" class="form-control" name="quiz_duration" required placeholder="eg: 60">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Nilai Minimum *</label>
                                        <input type="text" class="form-control" name="quiz_kkm" required placeholder="eg: 55">
                                    </div>
                                </div>
                            </div><!-- / ROW -->
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Penulis *</label>
                                        <input type="text" class="form-control" name="quiz_author_name" required placeholder="eg: Sandi Ramadhan">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Kata Sandi Ujian</label>
                                        <input type="text" class="form-control" name="quiz_password" placeholder="Kata sandi..">
                                    </div>
                                </div>
                            </div><!-- / ROW -->
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Tampilkan Hasil Ujian *</label>
                                        <select class="form-control" name="quiz_show_report">
                                            <option value="0">Tidak Ditampilkan</option>
                                            <option value="1">Tampilkan</option>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Tampilkan Analisa Ujian *</label>
                                        <select class="form-control" name="quiz_show_analytic">
                                            <option value="0">Tidak Ditampilkan</option>
                                            <option value="1">Tampilkan</option>
                                        </select>
                                    </div>
                                </div>
                            </div><!-- / ROW -->
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Tanggal Mulai *</label>
                                        <input type="text" class="form-control dateTimePicker" id="" name="quiz_start" value="<?= date('Y/m/d H:i') ?>">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Tanggal Selesai *</label>
                                        <input type="text" class="form-control dateTimePicker" name="quiz_end" value="<?= date('Y/m/d H:i') ?>">
                                    </div>
                                </div>
                            </div><!-- / ROW -->
                        </div>
                        <div class="col-sm-6">
                            <legend>Pilih Kelas</legend>
                            <table class="table table-bordered table-hover">
                                <thead>
                                    <tr>
                                        <th style="width: 10%">#</th>
                                        <th>Nama Kelas</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($dataClass as $row => $value): ?>
                                        <tr>
                                            <td><input type="checkbox" name="id_class[]" value="<?= $value->id_class ?>" /></td>
                                            <td><?= $value->class_name ?></td>
                                        </tr>
                                    <?php endforeach ?>
                                </tbody>
                            </table>
                        </div>
                    </div><!-- / ROW -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batalkan</button>
                <button type="submit" onclick="return confirm('Apa anda yakin ??')" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
    </div>
</div>
<!-- MODAL EDIT -->
<?php foreach ($dataQuiz as $row => $value): ?>
    <?php $arr = ['Tidak Ditampilkan','Tampilkan'] ?>
    <div class="modal fade" id="edit<?= $row ?>">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                    <h4 class="modal-title">Ubah Ujian</h4>
                </div>
                <div class="modal-body">
                    <form action="<?= site_url('QuizCtrl/edit') ?>" method="POST">
                        <input type="hidden" name="id_quiz" value="<?= $value->id_quiz ?>">
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label>Judul Ujian *</label>
                                    <!-- <input type="text" class="form-control" name="quiz_title" required placeholder="eg: SAINTEK" value="<?= $value->quiz_title ?>"> -->
                                    <select class="form-control" name="quiz_title" required>
                                        <?php foreach ($dataTitle as $r => $v): ?>
                                            <option <?= ($v->qTitle_name == $value->quiz_title ? 'selected' : '') ?> value="<?= $v->qTitle_name ?>"><?= $v->qTitle_name ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Kategori Ujian *</label>
                                    <select class="form-control" name="id_category_quiz">
                                        <?php foreach ($dataCategory as $r => $v): ?>
                                            <option <?= ($v->id_category_quiz == $value->id_category_quiz ? 'selected' : '') ?> value="<?= $v->id_category_quiz ?>"><?= $v->category_quiz_name ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                                <div class="form-group">
                                    <label>Urutkan Soal *</label>
                                    <select class="form-control" name="quiz_order">
                                        <?php foreach ($dataOrder as $r => $v): ?>
                                            <option <?= ($v['value'] == $value->quiz_order ? 'selected' : '') ?> value="<?= $v['value'] ?>"><?= $v['name'] ?></option>
                                        <?php endforeach ?>
                                    </select>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Durasi *</label>
                                            <input type="number" class="form-control" name="quiz_duration" required placeholder="eg: 60" value="<?= $value->quiz_duration ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Nilai Minimum *</label>
                                            <input type="text" class="form-control" name="quiz_kkm" required placeholder="eg: 55" value="<?= $value->quiz_kkm ?>">
                                        </div>
                                    </div>
                                </div><!-- / ROW -->
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Penulis *</label>
                                            <input type="text" class="form-control" name="quiz_author_name" required placeholder="eg: Sandi Ramadhan" value="<?= $value->quiz_author_name ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Kata Sandi Ujian *</label>
                                            <input type="text" class="form-control" name="quiz_password" required value="<?= $value->quiz_password ?>">
                                        </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Tampilkan Hasil Ujian *</label>
                                            <select class="form-control" name="quiz_show_report">
                                                <?php foreach ($arr as $r => $v): ?>
                                                    <option <?= ($r == $value->quiz_show_report ? 'selected' : '') ?> value="<?= $r ?>"><?= $v ?></option>
                                                <?php endforeach ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Tampilkan Analisa Ujian *</label>
                                            <select class="form-control" name="quiz_show_analytic">
                                                <?php foreach ($arr as $r => $v): ?>
                                                    <option <?= ($r == $value->quiz_show_analytic ? 'selected' : '') ?> value="<?= $r ?>"><?= $v ?></option>
                                                <?php endforeach ?>
                                            </select>
                                        </div>
                                    </div>
                                </div><!-- / ROW -->
                                <div class="row">
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Tanggal Mulai *</label>
                                            <input type="text" class="form-control dateTimePicker" name="quiz_start" value="<?= substr(str_replace('-', '/', $value->quiz_start), 0,16) ?>">
                                        </div>
                                    </div>
                                    <div class="col-sm-6">
                                        <div class="form-group">
                                            <label>Tanggal Selesai *</label>
                                            <input type="text" class="form-control dateTimePicker" name="quiz_end" value="<?= substr(str_replace('-', '/', $value->quiz_end), 0,16) ?>">
                                        </div>
                                    </div>
                                </div><!-- / ROW -->
                            </div>
                            <div class="col-sm-6">
                                <legend>Pilih Kelas</legend>
                                <table class="table table-bordered table-hover">
                                    <thead>
                                        <tr>
                                            <th style="width: 10%">#</th>
                                            <th>Nama Kelas</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($dataClass as $r => $v): ?>
                                            <?php
                                                $checked = '';
                                                foreach ($value->classes as $rClass => $vClass) {
                                                    if ($v->id_class == $vClass->id_class) {
                                                        $checked = 'checked';
                                                    }
                                                }
                                            ?>
                                            <tr>
                                                <td><input <?= $checked ?> type="checkbox" name="id_class[]" value="<?= $v->id_class ?>" /></td>
                                                <td><?= $v->class_name ?></td>
                                            </tr>
                                        <?php endforeach ?>
                                    </tbody>
                                </table>
                            </div>
                        </div><!-- / ROW -->
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-danger" data-dismiss="modal">Batalkan</button>
                    <button type="submit" onclick="return confirm('Apa anda yakin ??')" class="btn btn-primary">Simpan</button>
                </div>
                </form>
            </div>
        </div>
    </div>
    <script type="text/javascript">
        $(function() {
            var count = '<?= $row ?>';
            $("#datapicker"+count).datepicker( { dateFormat : 'yy-mm-dd' } );
            $("#datapicker2"+count).datepicker( { dateFormat : 'yy-mm-dd' } );
        })
    </script>
<?php endforeach ?>
<script type="text/javascript">
    $(function() {
        $(".dateTimePicker").datetimepicker({
            dateFormat: 'yy-mm-dd',
            timeFormat: 'hh:mm',
            onShow: function () {
                this.setOptions({
                    maxDate:$('#tdate').val()?$('#tdate').val():false,
                    maxTime:$('#tdate').val()?$('#tdate').val():false
                });
            }
        });
    });
    function changeCategory(value) {
        window.location.href = '<?= site_url("page/quiz_sbmptn/'+value+'") ?>';
    }
</script>