<style type="text/css">
    .label { width: 100%; background-color: grey; color: white; padding: 10px; border-radius: 3px; }
    .label.label-success { background-color: green; }
    .label.label-danger { background-color: maroon; }
</style>
<!-- Page Title Area -->
<div class="row page-title clearfix" style="margin-top:-10px">
    <div class="page-title-left">
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
        <h6 class="page-title-heading mr-0 mr-r-5">
            List Pelajaran Pada Ujian : <?= $dataQuiz->quiz_title ?>
        </h6>
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
    </div>
    <!-- /.page-title-left -->
    <div class="page-title-right d-inline-flex">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('page/quiz_sbmptn') ?>">List Ujian</a></li>
            <li class="breadcrumb-item active">List Pelajaran</li>
        </ol>
    </div>
</div><!-- /.page-title -->

<div class="widget-list row" style="margin-top:10px;margin-bottom:80px">
    <div class="widget-holder widget-full-height col-md-12">
        <div class="widget-bg">
            <div class="widget-body">
                <a href="<?= site_url('page/quiz_sbmptn') ?>" class="btn btn-primary btn-sm"><i class="feather feather-arrow-left"></i>&nbsp; Kembali</a>
                <a href="#add" data-toggle="modal" class="btn btn-info btn-sm">Tambah Pelajaran</a><br />
                <table class="table table-striped table-responsive" data-toggle="datatables">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Pelajaran</th>
                            <th>Bobot</th>
                            <th>Total Pertanyaan</th>
                            <th>Nilai Jawaban Benar</th>
                            <th>Nilai Jawaban Salah</th>
                            <th>Dibuat</th>
                            <th style="width:15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dataQuiz->lessons as $row => $value): ?>
                            <tr>
                                <td><?= $row + 1 ?></td>
                                <td><?= $value->lesson_name ?></td>
                                <td><?= $value->lQuiz_weight ?> %</td>
                                <td><?= $value->lQuiz_total_question ?> Soal</td>
                                <td><?= $value->lQuiz_value_true_formatted ?> </td>
                                <td><?= $value->lQuiz_value_false_formatted ?> </td>
                                <td><?= $value->lQuiz_created ?></td>
                                <td>
                                    <a title="List Pertanyaan" href="<?= site_url('page/quiz_question/'.$value->id_quiz.'/'.$value->id_lQuiz) ?>" class="btn btn-success btn-sm"><i class="feather feather-layers"></i></a>
                                    <a title="Ubah Data Pelajaran" href="#edit<?= $row ?>" data-toggle="modal" class="btn btn-primary btn-sm"><i class="feather feather-edit"></i></a>
                                    <a title="Hapus Pelajaran" href="#delete<?= $row ?>" data-toggle="modal" class="btn btn-danger btn-sm"><i class="feather feather-trash"></i></a>
                                </td>
                            </tr>
                            <!-- MODAL DELETE -->
                            <div class="modal modal-danger fade" id="delete<?= $row ?>">
                                <div class="modal-dialog modal-md">
                                    <div class="modal-content">
                                        <div class="modal-header text-inverse">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title">Anda yakin ingin menghapus data ini?</h4>
                                        </div>
                                        <div class="modal-footer" style="padding:10px">
                                            <a href="<?= site_url('QuizCtrl/delete_lesson/'.$value->id_lQuiz) ?>" class="btn btn-outline-danger btn-block"><i class="feather feather-check-square"></i> Ya, Hapus data ini!</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <!-- MODAL EDIT -->
                            <div class="modal fade" id="edit<?= $row ?>">
                                <div class="modal-dialog modal-md">
                                    <div class="modal-content">
                                        <div class="modal-header">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title">Edit Pelajaran</h4>
                                        </div>
                                        <div class="modal-body">
                                            <form action="<?= site_url('QuizCtrl/edit_lesson') ?>" method="POST">
                                                <input type="hidden" name="id_quiz" value="<?= $value->id_quiz ?>">
                                                <input type="hidden" name="id_lQuiz" value="<?= $value->id_lQuiz ?>">
                                                <div class="form-group">
                                                    <label>Pelajaran *</label>
                                                    <select class="form-control" name="id_lesson" required>
                                                        <?php foreach ($dataLesson as $rLesson => $vLesson): ?>
                                                            <option <?= ($vLesson->id_lesson == $value->id_lesson ? 'selected' : '') ?> value="<?= $vLesson->id_lesson ?>"><?= $vLesson->lesson_name ?></option>
                                                        <?php endforeach ?>
                                                    </select>
                                                </div>
                                                <div class="row">
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label>Nilai Jawaban Benar *</label>
                                                            <input type="text" class="form-control" name="lQuiz_value_true" required value="<?= $value->lQuiz_value_true ?>">
                                                        </div>
                                                    </div>
                                                    <div class="col-sm-6">
                                                        <div class="form-group">
                                                            <label>Nilai Jawaban Salah *</label>
                                                            <input type="text" class="form-control" name="lQuiz_value_false" required value="<?= $value->lQuiz_value_false ?>">
                                                        </div>
                                                    </div>
                                                </div><!-- / ROW -->
                                                <div class="form-group">
                                                    <label>Bobot (%) *</label>
                                                    <input type="number" class="form-control" name="lQuiz_weight" required value="<?= $value->lQuiz_weight ?>">
                                                </div>
                                        </div>
                                        <div class="modal-footer">
                                            <button type="button" class="btn btn-danger" data-dismiss="modal">Batalkan</button>
                                            <button type="submit" onclick="return confirm('Apa anda yakin ??')" class="btn btn-primary">Simpan</button>
                                        </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach ?>                   
                    </tbody>
                </table>
            </div><!-- /.widget-body -->
        </div><!-- /.widget-bg -->
    </div>
</div>

<!-- MODAL ADD -->
<div class="modal fade" id="add">
    <div class="modal-dialog modal-md">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Tambah Pelajaran</h4>
            </div>
            <div class="modal-body">
                <form action="<?= site_url('QuizCtrl/add_lesson') ?>" method="POST">
                    <input type="hidden" name="id_quiz" value="<?= $dataQuiz->id_quiz ?>">
                    <div class="form-group">
                        <label>Pelajaran *</label>
                        <select class="form-control" name="id_lesson" required>
                            <?php foreach ($dataLesson as $row => $value): ?>
                                <?php
                                    $go = true;
                                    foreach ($dataQuiz->lessons as $r => $v) {
                                        if ($v->id_lesson == $value->id_lesson) {
                                            $go = false;
                                        }
                                    }
                                ?>
                                <?php if ($go): ?>
                                    <option value="<?= $value->id_lesson ?>"><?= $value->lesson_name ?></option>
                                <?php endif ?>
                            <?php endforeach ?>
                        </select>
                    </div>
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Nilai Jawaban Benar *</label>
                                <input type="text" class="form-control" name="lQuiz_value_true" required value="0">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Nilai Jawaban Salah *</label>
                                <input type="text" class="form-control" name="lQuiz_value_false" required value="0">
                            </div>
                        </div>
                    </div><!-- / ROW -->
                    <div class="form-group">
                        <label>Bobot (%) *</label>
                        <input type="number" class="form-control" name="lQuiz_weight" required value="0">
                    </div>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batalkan</button>
                <button type="submit" onclick="return confirm('Apa anda yakin ??')" class="btn btn-primary">Simpan</button>
            </div>
            </form>
        </div>
    </div>
</div>