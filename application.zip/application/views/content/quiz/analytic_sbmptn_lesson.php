<div class="widget-list row" style="margin-top:10px;margin-bottom:0px">
        <div class="widget-holder widget-full-height col-md-12">
            <div class="widget-bg">
                <div class="widget-body">
                    <a href="<?= site_url('page/analytics_sbmptn_lesson_export') ?>" style="float: right;" class="btn btn-success">Export Excel</a>
                    <legend>Rincian Laporan Ujian: <?= $dataQuiz->quiz_title ?></legend>
                </div>
            </div>
        </div>
</div>
<?php foreach ($quiz_lessons as $row_ => $value_): ?>
    <div class="widget-list row" style="margin-top:10px;margin-bottom:0px">
        <div class="widget-holder widget-full-height col-md-12">
            <div class="widget-bg">
                <div class="widget-body">
                    <legend>Pelajaran: <?= $value_->lesson_name ?></legend>
                    <div class="table-responsive">
                        <table class="table table-bordered" data-toggle="datatables">
                            <thead>
                                <th style="width:5%">#</th>
                                <th>Pertanyaan</th>
                                <th>Jawaban Benar</th>
                                <th>Jawaban Salah</th>
                                <th>Tidak Diisi / Belum Mengerjakan</th>
                                <th>Rincian</th>
                            </thead>
                            <tbody>
                                <?php foreach ($value_->questions as $row => $value): ?>
                                    <tr>
                                        <td><?= $row + 1 ?></td>
                                        <td><?= substr($value->question_, 0,100) ?>. <a style="color:blue" href="#detail<?= $row_.$row ?>" data-toggle="modal">Selengkapnya <i class="feather feather-arrow-right"></i></a></td>
                                        <td><?= $value->totalTrue ?> Siswa/i</td>
                                        <td><?= $value->totalFalse ?> Siswa/i</td>
                                        <td><?= $value->totalEmpty ?> Siswa/i</td>
                                        <td>
                                            <a href="<?= site_url('page/analytic_sbmptn_lesson_student/'.$value_->id_lQuiz.'-'.$dataQuiz->id_quiz.'-'.$value->id_qQuiz.'-'.$id_class) ?>" class="btn btn-info">
                                                <i class="feather feather-layers"></i>
                                            </a>
                                        </td>
                                    </tr>
                                    <!-- MODAL -->
                                    <div class="modal fade" id="detail<?= $row_.$row ?>">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                                    <h4 class="modal-title">Detail Pertanyaan</h4>
                                                </div>
                                                <div class="modal-body">
                                                    <?php if ($value->question_image != ''): ?>
                                                        <img src="<?= base_url('assets/images/questions/'.$value->question_image) ?>" class="img-thumbnail">
                                                    <?php endif ?>
                                                    <?= $value->question_ ?>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach ?>
                            </tbody>
                        </table>
                    </div>
                    <br />
                </div><!-- / BODY -->
            </div><!-- / BG -->
        </div>
    </div>
<?php endforeach ?>