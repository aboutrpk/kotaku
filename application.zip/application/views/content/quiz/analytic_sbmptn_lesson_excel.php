<?php
	header("Content-type: application/octet-stream");
    header("Content-disposition: attachement; filename=laporan_analisa_ujian_sbmptn.xls");
    header("Pragma: no-cache");
    header("Expires: 0");
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Laporan Analisa Berdasarkan Pelajaran</title>
		<style type="text/css">
			table.table {
				width: 100%;
				border-collapse: collapse;
			}
			table.table thead th,
			table.table tbody tr td {
				padding: 4px;
			}
		</style>
	</head>
	<body>
		<h3>Rincian Laporan Ujian: <?= $dataQuiz->quiz_title ?></h3>
        <?php foreach ($quiz_lessons as $row_ => $value_): ?>
            <p>Pelajaran : <?= $value_->lesson_name ?></p>
            <table class="table" border="1">
                <thead>
                    <th style="width:5%">#</th>
                    <th>Pertanyaan</th>
                    <th>Jawaban Benar</th>
                    <th>Jawaban Salah</th>
                    <th>Tidak Diisi / Belum Mengerjakan</th>
                </thead>
                <tbody>
                    <?php foreach ($value_->questions as $row => $value): ?>
                        <tr>
                            <td><?= $row + 1 ?></td>
                            <td><?= $value->question_ ?></td>
                            <td><?= $value->totalTrue ?> Siswa/i</td>
                            <td><?= $value->totalFalse ?> Siswa/i</td>
                            <td><?= $value->totalEmpty ?> Siswa/i</td>
                        </tr>
                    <?php endforeach ?>
                </tbody>
            </table>
        <?php endforeach ?>
	</body>
</html>