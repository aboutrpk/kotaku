<!-- Page Title Area -->
<div class="row page-title clearfix" style="margin-top:-10px">
    <div class="page-title-left">
        <h6 class="page-title-heading mr-0 mr-r-5">Bank Soal Pelajaran <?= $dataLessonQuiz->lesson_name ?> </h6>
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
    </div>
    <!-- /.page-title-left -->
    <div class="page-title-right d-inline-flex">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('page/quiz_question/'.$dataQuiz->id_quiz.'/'.$dataLessonQuiz->id_lQuiz) ?>">List Soal</a></li>
            <li class="breadcrumb-item active">Gunakan Soal Lain</li>
        </ol>
    </div>
</div><!-- /.page-title -->

<div class="widget-list row" style="margin-top:10px;margin-bottom:80px">
 <div class="widget-holder widget-full-height col-md-12">
    <div class="widget-bg">
        <div class="widget-body">
            <a href="<?= site_url('page/quiz_question/'.$dataQuiz->id_quiz.'/'.$dataLessonQuiz->id_lQuiz) ?>" class="btn btn-danger btn-sm"><i class="feather feather-arrow-left"></i>&nbsp; Kembali</a>
            <a href="#save" data-toggle="modal" class="btn btn-primary btn-sm"><i class="feather feather-check"></i>&nbsp; Simpan!</a>
            <form action="<?= site_url('QuizCtrl/useQuestionForQuiz') ?>" method="POST">
                <input type="hidden" name="id_quiz" value="<?= $dataQuiz->id_quiz ?>">
                <input type="hidden" name="id_lQuiz" value="<?= $dataLessonQuiz->id_lQuiz ?>">
                <table class="table table-striped table-responsive">
                    <thead>
                        <tr>
                            <th style="width:5%">#</th>
                            <th style="width:10%">Pelajaran</th>
                            <th>Pertanyaan</th>
                            <th style="width:10%">Total</th>
                            <th style="width:15%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dataQuestion as $row => $value): ?>
                            <?php
                                $show = true;
                                foreach ($usedQuestion as $r => $v) {
                                    if ($value->id_question == $v->id_question) {
                                        if ($v->qQuiz_hide == 1) {
                                            $show = false;
                                        }
                                    }
                                }
                            ?>
                            <?php if ($show): ?>
                                <tr>
                                    <td><input type="checkbox" name="id_question[]" value="<?= $value->id_question ?>" style="width:20px;height:20px"></td>
                                    <td><?= $value->lesson_name ?></td>
                                    <td><?= $value->question_ ?></td>
                                    <td><?= $value->totalOption ?> jawaban</td>
                                    <td>
                                        <a title="Detail Soal" target="_blank" href="<?= site_url('page/single_question/'.$value->id_question) ?>" class="btn btn-success btn-sm">Lihat Jawaban</a>
                                    </td>
                                </tr>
                            <?php endif ?>
                        <?php endforeach ?>           
                    </tbody>
                </table>
                <!-- MODAL -->
                <div class="modal fade" id="save">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title">Apa anda sudah yakin ingin menggunakan soal yang terpilih ??</h4>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Batalkan!</button>
                                <button type="submit" class="btn btn-primary">Ya, Simpan dan lanjutkan!</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <!-- /.widget-body -->
    </div>
    <!-- /.widget-bg -->
</div>
</div>