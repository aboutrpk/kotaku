<?php
	header("Content-type: application/octet-stream");
    header("Content-disposition: attachement; filename=laporan-analisa-sbmptn.xls");
    header("Pragma: no-cache");
    header("Expires: 0");
?>
<!DOCTYPE html>
<html>
	<head>
		<title>Laporan Analisa Ujian</title>
		<style type="text/css">
			table.table { border-collapse: collapse; width: 100%; }
		</style>
	</head>
	<body>
		<h3>
			Judul Ujian : <?= $dataQuiz->quiz_title ?><br />
			Penulis : <?= $dataQuiz->quiz_author_name ?><br />
			Tanggal : <?= $dataQuiz->quiz_start ?> - <?= $dataQuiz->quiz_end ?>
		</h3>
		<hr />
		<?php foreach ($dataQuiz->quiz_lesson as $row => $value): ?>
			<p>Pelajaran : <?= $value->lesson_name ?></p>
			<table class="table" border="1">
				<thead>
					<tr>
						<th rowspan="2">#</th>
						<th rowspan="2">Pertanyaan</th>
						<th rowspan="2">Jawaban Benar</th>
						<th colspan="<?= count($dataStudent) ?>">Siswa</th>
					</tr>
					<tr>
						<?php foreach ($dataStudent as $r => $v): ?>
							<th><?= $v->student_name ?></th>
						<?php endforeach ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ($value->questions as $row_ => $value_): ?>
						<tr>
							<td><?= $row_ + 1 ?></td>
							<td><?= $value_->question_ ?></td>
							<td>
								<?php if ($value_->optionTrue): ?>
									<?= $value_->optionTrue->option_ ?>
								<?php endif ?>
							</td>
							<?php foreach ($dataStudent as $rStudent => $vStudent): ?>
								<td>
									<?php foreach ($dataAnalytics as $_row => $_value): ?>
										<?php if ($vStudent->id_student == $_value->id_student && $value_->id_qQuiz == $_value->id_qQuiz): ?>
											<?= $_value->option_ ?>
											<hr />
											<?php if ($_value->aQuiz_status == 'true'): ?>
												<center style="color:green">BENAR!</center>
											<?php elseif ($_value->aQuiz_status == 'false'): ?>
												<center style="color:red">SALAH!</center>
											<?php else: ?>
												<center>TIDAK DIJAWAB!</center>
											<?php endif ?>
										<?php endif ?>
									<?php endforeach ?>
								</td>
							<?php endforeach ?>
						</tr>
					<?php endforeach ?>
				</tbody>
			</table>
			<br /><br />
		<?php endforeach ?>
	</body>
</html>