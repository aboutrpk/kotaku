<script type="text/javascript">
    var dataUniversity = $.parseJSON('<?= json_encode($dataUniversity) ?>');

    function cloneUniversity() {
        var count = $("#totalUniversity").val();
        count++;
        var _html = '<br />';
        _html += '<div class="row" id="boxUniversity' + count + '">';
        _html += '<div class="col-sm-6">';
        _html += '<div class="form-group">';
        _html += '<label>University *</label>';
        _html += '<select class="form-control" name="id_university' + count + '" id="id_university' + count + '" onchange="getDepartment(\'' + count + '\')">';
        _html += '<option value="null">-- Pilih Universitas --</option>';
        $.each(dataUniversity, function(i, v) {
            _html += '<option value="' + v.id_university + '">' + v.university_name + '</option>';
        });
        _html += '</select>';
        _html += '</div>';
        _html += '</div>';
        _html += '<div class="col-sm-6">';
        _html += '<div class="form-group">';
        _html += '<label id="labelDepartment' + count + '">Jurusan *</label>';
        _html += '<select class="form-control" name="id_department' + count + '" id="id_department' + count + '"></select>';
        _html += '</div>';
        _html += '</div>';
        _html += '</div>';
        $("#appendUniversity").append(_html);
        $("#totalUniversity").val(count);
        if (count > parseInt('<?= count($dataStudent->university) ?>')) {
            $("#btnRemove").show();
        }
    }

    function removeUniversity() {
        var count = $("#totalUniversity").val();
        $("#boxUniversity" + count).remove();
        count--;
        $("#totalUniversity").val(count);
        if (count <= parseInt('<?= count($dataStudent->university) ?>')) {
            $("#btnRemove").hide();
        }
    }

    function getDepartment(row, id_department = null) {
        var id_university = $("#id_university" + row).val();
        $("#labelDepartment" + row).html('Sedang mencari..');
        $.ajax({
            url: '<?= site_url("MasterCtrl/getDepartmentByUniversity/'+id_university+'") ?>',
            type: 'GET',
            success: function(res) {
                var _html = '';
                $.each($.parseJSON(res), function(i, v) {
                    var selected = '';
                    if (id_department) {
                        if (v.id_department == id_department) {
                            selected = 'selected'
                        }
                    }
                    _html += '<option ' + selected + ' value="' + v.id_department + '">' + v.department_name + '</option>';
                });
                $("#id_department" + row).html(_html);
                $("#labelDepartment" + row).html('Jurusan *');
            }
        })
    }

    function checkClass(value) {
        $.each($.parseJSON('<?= json_encode($dataClasses) ?>'), function(i, v) {
            if (value == v.id_class) {
                if (v.class_level == 'XII') {
                    $("#bigBoxUniversity").show();
                    $("#class_level").val('XII');
                } else {
                    $("#bigBoxUniversity").hide();
                    $("#class_level").val('');
                }
            }
        });
    }
</script>
<script type="text/javascript">
    $(function() {
        $("#student_photo").on("change", function() {
            var files = !!this.files ? this.files : [];
            if (!files.length || !window.FileReader) {
                $("#imagePreview").css("background", "transparent");
            }; // no file selected, or no FileReader support
            if (/^image/.test(files[0].type)) { // only image file
                var reader = new FileReader(); // instance of the FileReader
                reader.readAsDataURL(files[0]); // read the local file

                reader.onloadend = function() { // set image data as background of div
                    $("#imagePreview").css({
                        "background-image": "url(" + this.result + ")",
                        "background-size": "cover",
                        "background-position": "center center"
                    });
                }
            }
        });
    });

    function getkey(e) {
        if (window.event)
            return window.event.keyCode;
        else if (e)
            return e.which;
        else
            return null;
    }

    function goodchars(e, goods, field) {
        var key, keychar;
        key = getkey(e);
        if (key == null) return true;

        keychar = String.fromCharCode(key);
        keychar = keychar.toLowerCase();
        goods = goods.toLowerCase();

        // check goodkeys
        if (goods.indexOf(keychar) != -1)
            return true;
        // control keys
        if (key == null || key == 0 || key == 8 || key == 9 || key == 27)
            return true;

        if (key == 13) {
            var i;
            for (i = 0; i < field.form.elements.length; i++)
                if (field == field.form.elements[i])
                    break;
            i = (i + 1) % field.form.elements.length;
            field.form.elements[i].focus();
            return false;
        };
        // else return false
        return false;
    }
</script>
<!-- Page Title Area -->
<div class="row page-title clearfix" style="margin-top:-10px">
    <div class="page-title-left">
        <a href="#save" data-toggle="modal" class="btn btn-info btn-sm"><i class="feather feather-check-square"></i>&nbsp; Simpan</a>
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
        <label>Info : * Wajib Terisi</label>
    </div>
    <!-- /.page-title-left -->
    <div class="page-title-right d-inline-flex">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('page/students') ?>">Data Siswa</a></li>
            <li class="breadcrumb-item active">Ubah Siswa</li>
        </ol>
    </div>
</div><!-- /.page-title -->

<div class="widget-list row" style="margin-top:10px;margin-bottom:80px">
    <div class="widget-holder widget-full-height col-md-12">
        <div class="widget-bg">
            <div class="widget-body">
                <form action="<?= site_url('MasterCtrl/students') ?>" method="POST" enctype="multipart/form-data">
                    <input type="hidden" name="id_student" value="<?= $dataStudent->id_student ?>">
                    <div class="row">
                        <div class="col-md-6">
                            <div class="form-group">
                                <label>Nama Lengkap *</label>
                                <input type="text" class="form-control" name="student_name" placeholder="Nama Lengkap" required value="<?= $dataStudent->student_name ?>">
                            </div>
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Username *</label>
                                        <input type="text" class="form-control" name="student_username" placeholder="Username" maxlength="30" required value="<?= $dataStudent->student_username ?>">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Password</label>
                                        <input type="password" class="form-control" name="student_password" placeholder="Password">
                                    </div>
                                </div>
                            </div><!-- / ROW -->
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Tanggal Lahir *</label>
                                        <!-- <input type="number" class="form-control" name="student_age" placeholder="Umur anda" required value="<?= $dataStudent->student_age ?>"> -->
                                        <input type="text" class="form-control" name="student_age" required value="<?= $dataStudent->student_age ?>" id="datapicker">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Nomor Telepon</label>
                                        <input type="text" class="form-control" name="student_phone" placeholder="Nomor Telepon" maxlength="12" value="<?= $dataStudent->student_phone ?>">
                                    </div>
                                </div>
                            </div><!-- / Row -->
                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>NIS</label>
                                        <input type="text" class="form-control" name="student_nis" placeholder="NiS Siswa" value="<?= $dataStudent->student_nis ?>">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                        <label>Email</label>
                                        <input type="email" class="form-control" name="student_email" placeholder="info@youremail.com" required value="<?= $dataStudent->student_email ?>">
                                    </div>
                                </div>
                            </div><!-- / ROW -->
                            <div class="form-group">
                                <label>Alamat *</label>
                                <input type="text" class="form-control" name="student_address" placeholder="Alamat siswa.." required value="<?= $dataStudent->student_address ?>">
                            </div>
                            <div class="form-group">
                                <label>Kelas *</label>
                                <select required class="form-control" name="id_class" onchange="checkClass(this.value)">
                                    <option value="null">Pilihan Kelas</option>
                                    <?php foreach ($dataClasses as $row => $value) : ?>
                                    <option <?php if ($value->id_class == $dataStudent->id_class) : echo "selected";
                                            endif; ?> value="<?= $value->id_class ?>"><?= $value->class_level ?> - <?= $value->class_name ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <input type="hidden" name="class_level" id="class_level" value="<?= $dataStudent->class->class_level ?>">
                            <!-- UNIVERSITY -->
                            <?php if ($dataStudent->class->class_level == 'XII') : ?>
                            <div id="bigBoxUniversity">
                                <?php else : ?>
                                <div id="bigBoxUniversity" style="display: none;">
                                    <?php endif ?>
                                    <button type="button" onclick="removeUniversity()" id="btnRemove" class="btn btn-danger" style="float: right;margin-left: 10px;display: none;">Hapus</button>
                                    <button type="button" onclick="cloneUniversity()" class="btn btn-primary" style="float: right;margin-top: 0px;">Tambah</button>
                                    <legend>Universitas</legend>
                                    <input type="hidden" name="totalUniversity" id="totalUniversity" value="<?= count($dataStudent->university) ?>">
                                    <?php foreach ($dataStudent->university as $row => $value) : ?>
                                    <div class="row">
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label>University *</label>
                                                <select class="form-control" name="id_university<?= $row + 1 ?>" id="id_university<?= $row + 1 ?>" onchange="getDepartment('<?= $row + 1 ?>')">
                                                    <option value="null">-- Pilih Universitas --</option>
                                                    <?php foreach ($dataUniversity as $r => $v) : ?>
                                                    <option <?= ($v->id_university == $value->id_university) ? 'selected' : ''; ?> value="<?= $v->id_university ?>"><?= $v->university_name ?></option>
                                                    <?php endforeach ?>
                                                </select>
                                            </div>
                                        </div>
                                        <div class="col-sm-6">
                                            <div class="form-group">
                                                <label id="labelDepartment<?= $row + 1 ?>">Jurusan *</label>
                                                <select class="form-control" name="id_department<?= $row + 1 ?>" id="id_department<?= $row + 1 ?>"></select>
                                            </div>
                                            <!-- DELETE -->
                                            <a href="<?= site_url('MasterCtrl/deleteStudentUniversity/' . $value->id_sUniversity) ?>" onclick="return confirm('Apa anda yakin ingin menghapus data ini??')" style="float:right;" class="btn btn-danger btn-sm">Hapus</a>
                                        </div>
                                    </div><!-- / ROW -->
                                    <script type="text/javascript">
                                        getDepartment('<?= $row + 1 ?>', '<?= $value->id_department ?>');
                                    </script>
                                    <?php endforeach ?>
                                    <div id="appendUniversity"></div>
                                </div><!-- BIG BOX -->
                            </div>
                            <div class="col-md-6">
                                <div class="form-group">
                                    <label>Foto Siswa</label>
                                    <input type="file" name="student_photo" id="student_photo" class="form-control">
                                    <div class="imagePreview" id="imagePreview" style="background:url('<?= base_url('assets/images/students/' . $dataStudent->student_photo) ?>');background-size:cover;background-position:center center"></div>
                                </div>
                            </div>
                        </div><!-- / Row -->

                        <!-- MODAL SAVE -->
                        <div class="modal modal-info fade" id="save">
                            <div class="modal-dialog">
                                <div class="modal-content">
                                    <div class="modal-header text-inverse">
                                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                        <h4 class="modal-title">Apa anda sudah yakin dengan data ini ?</h4>
                                    </div>
                                    <div class="modal-footer">
                                        <button type="submit" class="btn btn-outline-info btn-block">Ya, Simpan dan lanjutkan!</button>
                                    </div>
                                </div>
                            </div>
                        </div><!-- / END MODAL SAVE -->

                </form>
            </div>
            <!-- /.widget-body -->
        </div>
        <!-- /.widget-bg -->
    </div>
</div> 