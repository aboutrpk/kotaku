<!-- Page Title Area -->
<div class="row page-title clearfix" style="margin-top:-10px">
    <div class="page-title-left">
        <h6 class="page-title-heading mr-0 mr-r-5">Data Jurusan <a href="<?= site_url('page/department_add') ?>" class="btn btn-info btn-circle btn-sm"><i class="feather feather-plus"></i></a></h6>
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
    </div>
    <!-- /.page-title-left -->
    <div class="page-title-right d-inline-flex">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Data Jurusan</li>
        </ol>
    </div>
</div><!-- /.page-title -->
<div class="widget-list row" style="margin-top:10px;margin-bottom:80px">
    <div class="widget-holder widget-full-height col-md-12">
        <div class="widget-bg">
            <div class="widget-body">
            <div class="row">
                   <div class="col-sm-4">
                        <div class="input-group">
        					<select id="iuniversity" class="form-control" onchange="chclass(this.value)">
        						<option value="null">-- Tampilkan Semua --</option>
        						    <?php
                                        foreach ($mclass as $c) {
                                        if ($c->id_university == $cls) {
                                            $s = 'selected';
                                        } else {
                                            $s = '';
                                        }
                                            echo "<option value='$c->id_university' $s>$c->university_name</option>";
                                        }
                                ?>
                            </select>
                        <div class="input-group-addon"><i class="feather feather-filter"></i></div>
                        </div>
                    </div>
                <div class="col-sm-6">
                        <div class="form-group">
                            <?php if ($dataDepartment) : ?>
                                <a href="<?= site_url('page/department_export') ?>" onclick="return confirm('Apa anda yakin ?')" class="btn btn-success"> Export Excel</a>
                            <?php endif ?>
                            <a href="#import" data-toggle="modal" class="btn btn-success">Import Excel</a>
                        </div>
                </div>
            </div>
                <table class="table table-stripped table-responsive" data-toggle="datatables">
                    <thead>
                        <tr>
                            <th style="width:5%">#</th>
                            <th>Nama Universitas</th>
                            <th>Kode Jurusan</th>
                            <th>Nama Jurusan</th> 
                            <th>Passing Grade</th>
                            <th>Dibuat</th>
                            <th style="width:10%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dataDepartment as $row => $value): ?>
                            <tr>
                                <td><?= $row + 1 ?></td>
                                <td><?= $value->university_name ?></td>
                                <td><?= $value->department_code ?></td>
                                <td><?= $value->department_name ?></td>
                                <td><?= $value->department_pg ?></td>
                                <td><?= $value->department_created ?></td>
                                <td>
                                    <a href="<?= site_url('page/department_edit/'.$value->id_department) ?>" class="btn btn-primary btn-sm"><i class="feather feather-edit"></i></a>
                                    <a href="#delete<?= $row ?>" data-toggle="modal" class="btn btn-danger btn-sm"><i class="feather feather-trash"></i></a>
                                </td>
                            </tr>
                            <!-- MODAL DELETE -->
                            <div class="modal modal-danger fade" id="delete<?= $row ?>">
                                <div class="modal-dialog modal-md">
                                    <div class="modal-content">
                                        <div class="modal-header text-inverse">
                                            <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                            <h4 class="modal-title">Anda yakin ingin menghapus data ini?</h4>
                                        </div>
                                        <div class="modal-footer" style="padding:10px">
                                            <a href="<?= site_url('MasterCtrl/department/'.$value->id_department) ?>" class="btn btn-outline-danger btn-block"><i class="feather feather-check-square"></i> Ya, Hapus data ini!</a>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach ?>
                                           
                    </tbody>
                </table>
            </div>
            <!-- /.widget-body -->
        </div>
        <!-- /.widget-bg -->
    </div>
</div>

<script>
	function chclass(id) {
		window.location = "<?= base_url('page/department') ?>/"+id;
	}
</script>
<!-- IMPORT -->
<div class="modal fade" id="import">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Import Jurusan!</h4>
            </div>
            <div class="modal-body">
                <form action="<?= site_url('MasterCtrl/importDepartment') ?>" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-sm-6">
                            <legend>Catatan Import Jurusan!</legend>
                            <ul>
                                <li>Gunakan format yang telah disediakan</li>
                                <li>Pastikan format file yang di import hanya .xls atau .xlsx</li>
                                <li>Pastikan kode universitas yang dimasukan sesuai dengan kode universitas yang telah disediakan dibawah!</li>
                            </ul>
                            <div class="form-group">
                                <label>List Universitas</label>
                                <select class="form-control">
                                    <?php foreach ($dataUniversity as $row => $value): ?>
                                        <option><?= $value->university_name ?> - (<?= $value->id_university ?>)</option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>File Import (xls/xlsx) *</label>
                                <input type="file" class="form-control" name="fileImport" required>
                            </div>
                        </div>
                    </div><!-- / ROW -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batalkan!</button>
                <button type="submit" onclick="return confirm('Apa anda yakin??')" class="btn btn-primary">Ya, Import Sekarang!</button>
            </div>
            </form>
        </div>
    </div>
</div>