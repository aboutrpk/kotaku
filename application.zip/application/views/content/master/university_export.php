<?php
    header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=List-University.xls");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Cache-Control: private",false);
?>
<h4>List University</h4>
<table class="table" border="1" cellpadding="0" cellspacing="0" style="width: 60%">
    <thead>
        <tr>
            <th style="width:7%">#</th>
            <th>ID Universitas</th>
            <th>Nama Universitas</th>
            <th>Akronim</th>
            <th>Dibuat</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($dataUniversity as $row => $value): ?>
            <tr>
                <td><?= $row + 1 ?></td>
                <td><?= $value->id_university ?></td>
                <td><?= $value->university_name ?></td>
                <td><?= $value->university_akronim ?></td>
                <td><?= $value->university_created ?></td>
            </tr>
        <?php endforeach ?>                
    </tbody>
</table>