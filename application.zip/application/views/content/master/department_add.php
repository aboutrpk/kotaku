<script language="javascript">
function getkey(e)
{
if (window.event)
   return window.event.keyCode;
else if (e)
   return e.which;
else
   return null;
}
function goodchars(e, goods, field)
{
var key, keychar;
key = getkey(e);
if (key == null) return true;
 
keychar = String.fromCharCode(key);
keychar = keychar.toLowerCase();
goods = goods.toLowerCase();
 
// check goodkeys
if (goods.indexOf(keychar) != -1)
    return true;
// control keys
if ( key==null || key==0 || key==8 || key==9 || key==27 )
   return true;
    
if (key == 13) {
    var i;
    for (i = 0; i < field.form.elements.length; i++)
        if (field == field.form.elements[i])
            break;
    i = (i + 1) % field.form.elements.length;
    field.form.elements[i].focus();
    return false;
    };
// else return false
return false;
}
</script>


<!-- Page Title Area -->
<div class="row page-title clearfix" style="margin-top:-10px">
    <div class="page-title-left">
        <a href="#save" data-toggle="modal" class="btn btn-info btn-sm"><i class="feather feather-check-square"></i>&nbsp; Simpan</a>
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
        <label>Info : * Wajib Terisi</label>
    </div>
    <!-- /.page-title-left -->
    <div class="page-title-right d-inline-flex">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('page/department') ?>">Data Jurusan</a></li>
            <li class="breadcrumb-item active">Tambah Jurusan</li>
        </ol>
    </div>
</div><!-- /.page-title -->

<div class="widget-list row" style="margin-top:10px;margin-bottom:80px">
    <div class="widget-holder widget-full-height col-md-12">
        <div class="widget-bg">
            <div class="widget-body">
              <form action="<?= site_url('MasterCtrl/department') ?>" method="POST" enctype="multipart/form-data">
                <div class="row">
                 <div class="col-md-6">
                        <div class="form-group">
                            <label>Universitas *</label>
                            <select required class="form-control" name="id_university">
                                <option value="">Pilihan Universitas</option>
                                    <?php foreach ($dataUniversity as $row => $value) : ?>
                                        <option value="<?= $value->id_university ?>"><?= $value->university_name ?></option>
                                    <?php endforeach ?>
                            </select>
                        </div>
                        <div class="form-group">
                            <label>Kode Jurusan *</label>
                            <input type="text" class="form-control" name="department_code" placeholder="Kode Jurusan" onKeyPress="return goodchars(event,'0123456789',this)" required>
                        </div>
                        <div class="form-group">
                            <label>Nama Jurusan *</label>
                            <input type="text" class="form-control" name="department_name" placeholder="Nama Jurusan"  required>
                        </div>
                        <div class="form-group">     
                            <label>Passing Grade *</label>
                            <input type="text" class="form-control" name="department_pg" placeholder="Passing Grade Contoh 0.06" maxlength="5" onKeyPress="return goodchars(event,'0123456789.',this)" required>
                        </div>
                    </div>
                </div><!-- / Row -->
                 <!-- MODAL SAVE -->
                 <div class="modal modal-info fade" id="save">
                     <div class="modal-dialog">
                         <div class="modal-content">
                             <div class="modal-header text-inverse">
                                 <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                 <h4 class="modal-title">Apa anda sudah yakin dengan data ini ?</h4>
                             </div>
                             <div class="modal-footer">
                                 <button type="submit" class="btn btn-outline-info btn-block">Ya, Simpan dan lanjutkan!</button>
                             </div>
                         </div>
                     </div>
                 </div><!-- / END MODAL SAVE -->
               </form>
            </div>
            <!-- /.widget-body -->
        </div>
        <!-- /.widget-bg -->
    </div>
</div>