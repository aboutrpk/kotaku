<?php
    header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=List-Users.xls");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Cache-Control: private",false);
?>
<h4>List Users</h4>
<table class="table" border="1" cellpadding="0" cellspacing="0" style="width: 60%">
    <thead>
        <tr>
            <th style="width:7%">#</th>
            <th>Username</th>
            <th>Nama Lengkap</th>
            <th>Level</th>
            <th>Dibuat</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($dataUsers as $row => $value): ?>
            <tr>
                <td><?= $row + 1 ?></td>
                <td><?= $value->username ?></td>
                <td><?= $value->full_name ?></td>
                <td><?= $value->level ?></td>
                <td><?= $value->admin_created ?></td>
            </tr>
        <?php endforeach ?>                
    </tbody>
</table>