<?php
    header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=List-Guru.xls");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Cache-Control: private",false);
?>
<h4>List Guru</h4>
<table class="table" border="1" cellpadding="0" cellspacing="0" style="width: 60%">
    <thead>
        <tr>
            <th style="width:7%">#</th>
            <th>Nama Guru</th>
            <th>Username</th> 
            <th>Telepon</th>
            <th>Email</th>
            <th>Dibuat</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($dataTeacher as $row => $value): ?>
            <tr>
                <td><?= $row + 1 ?></td>
                <td><?= $value->teacher_name ?></td>
                <td><?= $value->teacher_username ?></td>
                <td><?= $value->teacher_phone ?></td>
                <td><?= $value->teacher_email ?></td>
                <td><?= $value->teacher_created ?></td>
            </tr>
        <?php endforeach ?>                
    </tbody>
</table>