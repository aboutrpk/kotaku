<?php
    header("Content-Type:   application/vnd.ms-excel; charset=utf-8");
    header("Content-Disposition: attachment; filename=List-Jurusan.xls");
    header("Expires: 0");
    header("Cache-Control: must-revalidate, post-check=0, pre-check=0");
    header("Cache-Control: private",false);
?>
<h4>List Jurusan</h4>
<table class="table" border="1" cellpadding="0" cellspacing="0" style="width: 60%">
    <thead>
        <tr>
            <th style="width:7%">#</th>
            <th>Nama Universitas</th>
            <th>Kode Jurusan</th>
            <th>Nama Jurusan</th> 
            <th>Passing Grade</th>
            <th>Dibuat</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($dataDepartment as $row => $value): ?>
            <tr>
                <td><?= $row + 1 ?></td>
                <td><?= $value->university_name ?></td>
                <td><?= $value->department_code ?></td>
                <td><?= $value->department_name ?></td>
                <td><?= $value->department_pg*100 ?></td>
                <td><?= $value->department_created ?></td>
            </tr>
        <?php endforeach ?>                
    </tbody>
</table>