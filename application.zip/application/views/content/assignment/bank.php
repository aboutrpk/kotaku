<!-- Page Title Area -->
<div class="row page-title clearfix" style="margin-top:-10px">
    <div class="page-title-left">
        <h6 class="page-title-heading mr-0 mr-r-5">Bank Soal <a href="<?= site_url('page/createQuestion') ?>" class="btn btn-info btn-circle btn-sm"><i class="feather feather-plus"></i></a></h6>
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
    </div>
    <!-- /.page-title-left -->
    <div class="page-title-right d-inline-flex">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Dashboard</a></li>
            <li class="breadcrumb-item active">Bank Soal</li>
        </ol>
    </div>
</div><!-- /.page-title -->

<div class="widget-list row" style="margin-top:10px;margin-bottom:80px">
 <div class="widget-holder widget-full-height col-md-12">
    <div class="widget-bg">
        <div class="widget-body">
            <div class="row">
                <div class="col-sm-4">
                    <div class="input-group">
                        <select id="iclass" class="form-control" onchange="changeLesson(this.value)">
                            <?php if ($this->session->userdata('level') == 'admin'): ?>
                                <option value="null">-- Tampilkan Semua --</option>
                            <?php endif ?>
                            <?php foreach ($dataLessons as $row => $value): ?>
                                <option <?= ($value->id_lesson == $lessonId ? 'selected' : '') ?> value="<?= $value->id_lesson ?>"><?= $value->lesson_name ?></option>
                            <?php endforeach ?>
                        </select>
                        <div class="input-group-addon"><i class="feather feather-filter"></i></div>
                    </div>
                </div>
                <div class="col-sm-4">
                    <div class="form-group">
                        <a href="#import" data-toggle="modal" class="btn btn-success"> Import Excel</a>
                        <a href="<?= site_url('page/bank_excel') ?>" onclick="return confirm('Apa anda yakin ??')" class="btn btn-success"> Export Excel</a>
                    </div>
                </div>
            </div><!-- / ROW -->
            <table class="table table-striped table-responsive" data-toggle="datatables">
                <thead>
                    <tr>
                        <th style="width:5%">#</th>
                        <th style="width:10%">Pelajaran</th>
                        <th>Pertanyaan</th>
                        <th style="width:10%">Total</th>
                        <th style="width:13%">Dibuat</th>
                        <th style="width:15%">Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($dataQuestion as $row => $value): ?>
                        <tr>
                            <td><?= $row + 1 ?></td>
                            <td><?= $value->lesson_name ?></td>
                            <td><?= strip_tags($value->question_) ?></td>
                            <td><?= $value->totalAnswer ?> jawaban</td>
                            <td><?= substr($value->question_created, 0,10) ?></td>
                            <td>
                                <a title="Detail Soal" href="<?= site_url('page/detail_question_bank/'.$value->id_assignment.'/'.$value->id_question) ?>" class="btn btn-success btn-sm"><i class="feather feather-eye"></i></a>
                                <a title="Ubah Soal" href="<?= site_url('page/updateQuestion/'.$value->id_assignment.'/'.$value->id_question) ?>" class="btn btn-info btn-sm"><i class="feather feather-edit"></i></a>
                                <a title="Hapus Soal" onclick="return confirm('Apa anda yakin ??')" href="<?= site_url('page/deleteQuestion/'.$value->id_question) ?>" class="btn btn-danger btn-sm"><i class="feather feather-trash"></i></a>
                            </td>
                        </tr>
                    <?php endforeach ?>               
                </tbody>
            </table>
        </div>
        <!-- /.widget-body -->
    </div>
    <!-- /.widget-bg -->
</div>
</div>
<script type="text/javascript">
    function changeLesson(id_lesson) {
        window.location.href = '<?= site_url("page/bank/'+id_lesson+'") ?>';
    }
</script>
<div class="modal fade" id="import">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                <h4 class="modal-title">Import Soal!</h4>
            </div>
            <div class="modal-body">
                <form action="<?= site_url('MasterCtrl/importQuestion') ?>" method="POST" enctype="multipart/form-data">
                    <div class="row">
                        <div class="col-sm-6">
                            <legend>Catatan Import Soal!</legend>
                            <ul>
                                <li>Gunakan format yang telah disediakan</li>
                                <li>Pastikan anda memilih pelajaran yang disediakan</li>
                                <li>Pastikan anda memilih total jumlah jawaban untuk semua soal</li>
                                <li>Pastikan format file yang di import hanya .xls atau .xlsx</li>
                            </ul>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label>Pelajaran *</label>
                                <select class="form-control" name="id_lesson" required>
                                    <?php foreach ($dataLessons as $row => $value): ?>
                                        <option value="<?= $value->id_lesson ?>"><?= $value->lesson_name ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Total Jawaban *</label>
                                <select class="form-control" name="totalAnswer" required>
                                    <?php foreach (range(1,5) as $row => $value): ?>
                                        <option value="<?= $value ?>"><?= $value ?> Jawaban</option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>File Import (xls/xlsx) *</label>
                                <input type="file" class="form-control" name="fileImport" required>
                            </div>
                        </div>
                    </div><!-- / ROW -->
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-danger" data-dismiss="modal">Batalkan!</button>
                <button type="submit" onclick="return confirm('Apa anda yakin??')" class="btn btn-primary">Ya, Import Sekarang!</button>
            </div>
            </form>
        </div>
    </div>
</div>