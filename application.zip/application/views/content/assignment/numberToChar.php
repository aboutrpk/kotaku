<?php
	$callback = 'A';
	switch ($i) {
		case '0':
			$callback = "A";
			break;
		case '1':
			$callback = "B";
			break;
		case '2':
			$callback = "C";
			break;
		case '3':
			$callback = "D";
			break;
		case '4':
			$callback = "E";
			break;
		case '5':
			$callback = "F";
			break;
		case '6':
			$callback = "G";
			break;
		case '7':
			$callback = "H";
			break;
		case '8':
			$callback = "I";
			break;
		case '9':
			$callback = "J";
			break;
		case '10':
			$callback = "K";
			break;
		case '11':
			$callback = "L";
			break;
		case '12':
			$callback = "M";
			break;
		case '13':
			$callback = "N";
			break;
		case '14':
			$callback = "O";
			break;
		case '15':
			$callback = "P";
			break;
		case '16':
			$callback = "Q";
			break;
		case '17':
			$callback = "R";
			break;
		case '18':
			$callback = "S";
			break;
		case '19':
			$callback = "T";
			break;
		case '20':
			$callback = "U";
			break;
		case '21':
			$callback = "V";
			break;
		case '22':
			$callback = "W";
			break;
		case '23':
			$callback = "X";
			break;
		case '24':
			$callback = "Y";
			break;
		case '25':
			$callback = "Z";
			break;
		default:
			$callback = "A";
			break;
	}
	echo $callback;

?>