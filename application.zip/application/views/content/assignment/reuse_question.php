<!-- Page Title Area -->
<div class="row page-title clearfix" style="margin-top:-10px">
    <div class="page-title-left">
        <h6 class="page-title-heading mr-0 mr-r-5">Bank Soal Pelajaran <?= $dataAssignment->lesson_name ?> </h6>
        <p class="page-title-description mr-0 d-none d-md-inline-block"></p>
    </div>
    <!-- /.page-title-left -->
    <div class="page-title-right d-inline-flex">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?= site_url() ?>">Dashboard</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('page/assignments') ?>">List Ujian</a></li>
            <li class="breadcrumb-item"><a href="<?= site_url('page/list_question/'.$dataAssignment->id_assignment) ?>">List Soal</a></li>
            <li class="breadcrumb-item active">Gunakan Soal Lain</li>
        </ol>
    </div>
</div><!-- /.page-title -->

<div class="widget-list row" style="margin-top:10px;margin-bottom:80px">
 <div class="widget-holder widget-full-height col-md-12">
    <div class="widget-bg">
        <div class="widget-body">
            <form action="<?= site_url('AssignmentCtrl/reuseQuestionMultiple') ?>" method="POST">
                <a href="<?= site_url('page/list_question/' . $dataAssignment->id_assignment) ?>" class="btn btn-danger btn-sm"><i class="feather feather-arrow-left"></i>&nbsp; Kembali</a>
                <a href="#save" data-toggle="modal" class="btn btn-primary btn-sm"><i class="feather feather-check"></i> &nbsp; Simpan!</a>
                <input type="hidden" name="id_assignment" value="<?= $dataAssignment->id_assignment ?>">
                <table class="table table-striped table-responsive">
                    <thead>
                        <tr>
                            <th style="width:5%">#</th>
                            <th style="width:10%">Pelajaran</th>
                            <th>Pertanyaan</th>
                            <th style="width:10%">Total</th>
                            <th style="width:20%">Aksi</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($dataQuestion as $row => $value): ?>
                            <?php
                                $view = true; 
                                foreach ($dataAssignment->assignment_question as $r => $v) {
                                    if ($value->id_question == $v->id_question) {
                                        $view = false;
                                    }
                                }
                            ?>
                            <?php if ($view): ?>
                                <tr>
                                    <td style="text-align: center;"><input type="checkbox" style="width: 30px;height: 30px" name="id_question[]" value="<?= $value->id_question ?>"></td>
                                    <td><?= $value->lesson_name ?></td>
                                    <td><?= strip_tags($value->question_) ?></td>
                                    <td><?= $value->totalAnswer ?> jawaban</td>
                                    <td>
                                        <a title="Detail Soal" target="_blank" href="<?= site_url('page/detail_question/'.$value->id_assignment.'/'.$value->id_question.'/true') ?>" class="btn btn-success btn-sm">Lihat Jawaban</a>
                                        <!-- <a title="Gunakan Soal Ini" onclick="return confirm('Apa anda yakin ?')" href="<?= site_url('page/reusequestion/'.$dataAssignment->id_assignment.'/'.$value->id_question) ?>" class="btn btn-info btn-sm">Gunakan Soal Ini</a> -->
                                    </td>
                                </tr>
                            <?php endif ?>
                        <?php endforeach ?>                     
                    </tbody>
                </table>
                <!-- MODAL -->
                <div class="modal fade" id="save">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <button type="button" class="close" data-dismiss="modal" aria-hidden="true">&times;</button>
                                <h4 class="modal-title">Apa anda sudah yakin dengan data ini ?</h4>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Batalkan!</button>
                                <button type="submit" class="btn btn-primary">Ya, Simpan dan Lanjutkan!</button>
                            </div>
                        </div>
                    </div>
                </div>
            </form>
        </div>
        <!-- /.widget-body -->
    </div>
    <!-- /.widget-bg -->
</div>
</div>