<?php
    header("Content-type: application/octet-stream");
    header("Content-disposition: attachement; filename=bank-soal-".$lesson_name.".xls");
    header("Pragma: no-cache");
    header("Expires: 0");
?>
<h3>
    Pelajaran : <?= $lesson_name ?>
</h3>
<table class="table" border="1" style="width: 100%;border-collapse: collapse;">
    <thead>
        <tr>
            <th style="width:5%">#</th>
            <th style="width:10%">Pelajaran</th>
            <th>Pertanyaan</th>
            <th style="width:10%">Total Jawaban</th>
            <th style="width:20%">Dibuat</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($dataQuestion as $row => $value): ?>
            <tr>
                <td><?= $row + 1 ?></td>
                <td>
                    <?= $value->lesson_name ?>
                </td>
                <td>
                    <?= $value->question_ ?><br />
                    -- Jawaban --<br />
                    <?php foreach ($value->answers as $r => $v): ?>
                        <b>
                            <?= $r + 1 ?>. <?= $v->option_ ?>
                            <?php if ($v->option_true == 1): ?>
                                &nbsp; (BENAR)
                            <?php endif ?>
                        </b><br />
                    <?php endforeach ?>    
                </td>
                <td><?= $value->totalAnswer ?> jawaban</td>
                <td><?= $value->question_created ?></td>
            </tr>
        <?php endforeach ?>                   
    </tbody>
</table>