<!DOCTYPE html>
<html lang="en" class="body-full-height">

<head>
    <title>Pendaftaran Sahabat M-BRIO</title>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="shortcut icon" href="<?= base_url('assets/images/favicon.ico') ?>" type="image/x-icon">
    <!-- CSS INCLUDE -->
    <link rel="stylesheet" type="text/css" id="theme" href="<?= base_url('exam-assets/css/theme-default.css') ?>">
    <script src="<?= base_url('assets/downloaded/jquery.min.js') ?>"></script>
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/jquery-ui-1.12.1/jquery-ui.min.css') ?>">
    <!-- EOF CSS INCLUDE -->
</head>

<body>
    <script type="text/javascript">
        $(function() {
            setTimeout(function() {
                $("#messageTimeout").hide(200);
            }, 4000);
        });
    </script>
    <?php if ($this->session->flashdata('text')) : ?>
    <div class="alert alert-<?= $this->session->flashdata('type'); ?>" style="border-radius:0px" id="messageTimeout">
        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
        <center><strong><?= $this->session->flashdata('title'); ?></strong> <?= $this->session->flashdata('text'); ?></center>
    </div>
    <?php endif ?>
    <div class="login-container login-v2">
        <div class="login-box animated fadeInDown">
            <div class="login-body">
                <div class="login-title"><strong>Pendaftaran Sahabat</strong>, Ujian Online.</div>
                <form action="<?= site_url('Auth/exam_regist') ?>" class="form-horizontal" method="post">
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <span class="fa fa-user"></span>
                                </div>
                                <input type="text" class="form-control" placeholder="Username" name="student_username" required>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <span class="fa fa-lock"></span>
                                </div>
                                <input type="password" class="form-control" placeholder="Password" required name="student_password">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <span class="fa fa-user"></span>
                                </div>
                                <input type="text" class="form-control" placeholder="Nama Lengkap.." required name="student_name">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <span class="fa fa-calendar"></span>
                                </div>
                                <input type="text" class="form-control dateTimePicker" placeholder="Tanggal Lahir.." required name="student_age" id="datapicker3">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <span class="fa fa-envelope"></span>
                                </div>
                                <input type="email" class="form-control" placeholder="Email.." required name="student_email">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <span class="fa fa-phone"></span>
                                </div>
                                <input type="number" class="form-control" placeholder="Telepon.." required name="student_phone">
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <span class="fa fa-home"></span>
                                </div>
                                <select class="form-control" name="id_class" required onchange="checkClass(this.value)">
                                    <option value="null">-- Pilih Kelas --</option>
                                    <?php foreach ($dataClass as $row => $value) : ?>
                                    <option value="<?= $value->id_class ?>"><?= $value->class_level ?> - <?= $value->class_name ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <input type="hidden" name="class_level" id="class_level" value="">
                    <button id="btnClone" onclick="cloneUniversity()" style="float: right;margin-right: 18px;" type="button" class="btn btn-primary"><i class="fa fa-plus"></i></button>
                    <button id="btnRemove" onclick="removeUniversity()" style="float: right;margin-right: 8px;" type="button" class="btn btn-danger"><i class="fa fa-minus"></i></button>
                    <input type="hidden" name="totalClone" id="totalClone" value="1">
                    <div class="form-group hideClass">
                        <br /><br /><br />
                        <div class="col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <span class="fa fa-university"></span>
                                </div>
                                <select class="form-control" name="id_university1" id="id_university1" required onchange="getDepartment(1)">
                                    <option value="null">-- Pilih Universitas --</option>
                                    <?php foreach ($dataUniversity as $row => $value) : ?>
                                    <option value="<?= $value->id_university ?>"><?= $value->university_name ?></option>
                                    <?php endforeach ?>
                                </select>
                            </div>
                            <label id="findLabel1" style="margin-top: 5px;display: none;">Sedang mencari..</label>
                        </div>
                    </div>
                    <div class="form-group hideClass">
                        <div class="col-md-12">
                            <div class="input-group">
                                <div class="input-group-addon">
                                    <span class="fa fa-book"></span>
                                </div>
                                <select class="form-control" name="id_department1" id="id_department1" required>
                                    <option value="null">-- Pilih Jurusan --</option>
                                </select>
                            </div>
                        </div>
                    </div>
                    <div id="cloneUniversity"></div>
                    <div class="form-group">
                        <div class="col-md-12">
                            <button onclick="return confirm('Apa anda yakin dengan data ini?')" class="btn btn-primary btn-lg btn-block">Daftar</button>
                            <p style="font-size: 15px;margin-top: 10px;">
                                Sudah memiliki akun ? <a href="<?= site_url('Auth/exam') ?>" style="text-decoration: underline;">Login Disini</a>
                            </p>
                        </div>
                    </div>
                    <div class="form-group">
                        <div class="login-footer">
                            <div class="container">
                                Rumah Konsul M-BRIO &copy; <?= date('Y') ?> - All Right Reserved.
                            </div>
                        </div>
                </form>
            </div>
        </div>
    </div>
</body>

</html>
<script src="<?= base_url('assets/jquery-ui-1.12.1/jquery-ui.min.js') ?>"></script>
<script type="text/javascript">
    $("#datapicker3").datepicker({
        dateFormat: 'yy-mm-dd',
        changeMonth: true,
        changeYear: true
    });
</script>
<script type="text/javascript">
    $(function() {
        $(".hideClass").hide();
        $("#btnClone").hide();
        $("#btnRemove").hide();
    })

    function checkClass(value) {
        $.each($.parseJSON('<?= json_encode($dataClass) ?>'), function(i, v) {
            if (v.id_class == value) {
                if (v.class_level == 'XII') {
                    $(".hideClass").show();
                    $("#class_level").val('XII');
                    $("#btnClone").show();
                } else {
                    $(".hideClass").hide();
                    $("#class_level").val('');
                    $("#btnClone").hide();
                    $("#btnRemove").hide();
                }
            }
        });
    }

    function cloneUniversity() {
        var totalUniversity = $("#totalClone").val();
        totalUniversity++;
        var _html = '';
        _html += '<div class="form-group hideClass" id="boxUniversity' + totalUniversity + '">';
        _html += '<div class="col-md-12">';
        _html += '<div class="input-group">';
        _html += '<div class="input-group-addon">';
        _html += '<span class="fa fa-university"></span>';
        _html += '</div>';
        _html += '<select class="form-control" name="id_university' + totalUniversity + '" id="id_university' + totalUniversity + '" required onchange="getDepartment(\'' + totalUniversity + '\')">';
        _html += '<option value="null">-- Pilih Universitas --</option>';
        $.each($.parseJSON('<?= json_encode($dataUniversity) ?>'), function(i, v) {
            _html += '<option value="' + v.id_university + '">' + v.university_name + '</option>';
        });
        _html += '</select>';
        _html += '</div>';
        _html += '<label id="findLabel' + totalUniversity + '" style="margin-top: 5px;display: none;">Sedang mencari..</label>';
        _html += '</div>';
        _html += '</div>';
        _html += '<div class="form-group hideClass" id="boxDepartment' + totalUniversity + '">';
        _html += '<div class="col-md-12">';
        _html += '<div class="input-group">';
        _html += '<div class="input-group-addon">';
        _html += '<span class="fa fa-book"></span>';
        _html += '</div>';
        _html += '<select class="form-control" name="id_department' + totalUniversity + '" id="id_department' + totalUniversity + '" required>';
        _html += '<option value="null">-- Pilih Jurusan --</option>';
        _html += '</select>';
        _html += '</div>';
        _html += '</div>';
        _html += '</div>';
        $("#cloneUniversity").append(_html);
        $("#totalClone").val(totalUniversity);
        if (totalUniversity > 1) {
            $("#btnRemove").show();
        }
    }

    function removeUniversity() {
        var totalUniversity = $("#totalClone").val();
        $("#boxUniversity" + totalUniversity).remove();
        $("#boxDepartment" + totalUniversity).remove();
        totalUniversity--;
        $("#totalUniversity").val(totalUniversity);
        if (totalUniversity <= 1) {
            $("#btnRemove").hide();
        }
    }

    function getDepartment(row) {
        var id_university = $("#id_university" + row).val();
        $("#findLabel" + row).show();
        $.ajax({
            url: '<?= site_url("Auth/getDepartmentByUniversity/'+id_university+'") ?>',
            type: 'GET',
            success: function(res) {
                var _html = '';
                $.each($.parseJSON(res), function(i, v) {
                    _html += '<option value="' + v.id_department + '">' + v.department_name + '</option>';
                });
                $("#id_department" + row).html(_html);
                $("#findLabel" + row).hide();
            }
        })
    }
</script> 