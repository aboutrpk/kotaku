<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MY_Controller extends CI_Controller {

	public function __construct() {
		parent::__construct();
		date_default_timezone_set('Asia/Jakarta');
		$this->load->model('MasterModel','master',TRUE);
		$this->load->model('AuthModel','auth',TRUE);
		$this->load->model('AssignmentModel','assignment',TRUE);
    	$this->load->model('ClassModel','class',TRUE);
    	$this->load->model('PresenceModel','presence',TRUE);
    	$this->load->model('QuizModel','quiz',TRUE);
		$this->checkAuth();
	}

	public $parseData = [
		'navbar' => 'inc/navbar',
		'footer' => 'inc/footer',
		'title' => 'No Title',
		'content' => '',
		'sidebar' => 'inc/sidebar'
	];
	public function preg($value) {
		return str_replace(" ", "-", str_replace("/", "-", str_replace("\\", "-", str_replace("'", "-", str_replace(",", "-", str_replace(".", "-", str_replace('!', '', $value)))))));
	}
	public function checkAuth() {
		if (!$this->session->userdata('backToken')) {
			redirect('Auth');
		} else {
			if (!$this->auth->checkToken($this->session->userdata('backToken'))) {
				redirect('page/logout');
			}
		}
	}
	public function debug($data,$die = null) {
		echo "<pre>";
		print_r($data);
		if ($die) {
			die;
		}
	}
	public function imageConf($dirName = NULL) {
        $conf['upload_path']   = './assets/images/'.$dirName;
        $conf['allowed_types'] = 'gif|jpg|png|jpeg|mp3';
        $conf['max_size']      = 2000;
        $conf['overwrite']     = TRUE;
        $conf['encrypt_name'] = TRUE;
        $this->load->library('upload', $conf);
    }
    public function soundConf($dirName = NULL) {
        $conf['upload_path']   = './assets/images/'.$dirName;
        $conf['allowed_types'] = 'gif|jpg|png|jpeg|mp3';
        $conf['max_size']      = 2000;
        $conf['overwrite']     = TRUE;
        $conf['encrypt_name'] = TRUE;
        $this->load->library('upload', $conf);
    }
    public function compreesImage($dirName,$fileName,$resolution) {
        $this->load->library('image_lib');
        $config['image_library'] = 'gd2';
        $config['source_image'] = './assets/images/'.$dirName.'/'.$fileName;
        $config['create_thumb'] = FALSE;
        $config['maintain_ratio'] = TRUE;
        $config['width']     = $resolution['width'];
        $config['height']   = $resolution['height'];

        $this->image_lib->clear();
        $this->image_lib->initialize($config);
        $this->image_lib->resize();
    }
	public function message($title = NULL,$text = NULL,$type = NULL) {
		return $this->session->set_flashdata([
				'title' => $title,
				'text' => $text,
				'type' => $type
			]
		);
	}
	public function SetLog($Message = NULL) {
		$Data = [
			'log_author' => $this->session->userdata('level').' - '.$this->session->userdata('fullName'),
			'log_desc' => $Message,
			'log_created' => date('Y-m-d H:i:s'),
		];
		return $this->db->insert('ms_log',$Data);
	}
	public function genAlpha($count) {
		$callback = 'B';
		switch ($count) {
			case 2:
				$callback = 'C';
				break;
			case 3:
				$callback = 'D';
				break;
			case 4:
				$callback = 'E';
				break;
			case 5:
				$callback = 'F';
				break;
		}
		return $callback;
	}
	public function GEN_UNIVERSITY($id_class = null,$id_student = null) {
		$callback = [];
		if ($id_class AND $id_student) {
			$dataClass = $this->master->getClassById($id_class);
			if ($dataClass) {
				if ($dataClass->class_level == 'XII') {
					foreach ($this->master->getUniversityByStudent_FULLJOIN($id_student) as $row => $value) {
						$value->department_pg = $this->GEN_PASSING_GRADE($value->department_pg);
						array_push($callback, $value);
					}
				}
			}
		}
		return $callback;
	}
	public function GEN_PASSING_GRADE($value) {
		$callback = 0;
		$value = (int)$value;
		$pg = str_replace('.', '', $value*100);
		$first = substr($pg, 0,2);
        $second = substr($pg, 2,2);
        if (strlen($pg) > 2) {
            $callback = $first.'.'.$second;
        } else {
            $callback = $first;
        }
        return $callback;
	}

	public function index() {
		echo "System Running";
	}

}

/* End of file MY_Controller.php */
/* Location: ./application/core/MY_Controller.php */