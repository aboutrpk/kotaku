<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

	public function __construct()
	{
		parent::__construct();
		$this->load->model('AuthModel', 'auth', true);
		$this->load->model('MasterModel', 'master', true);
	}
	public function message($title = null, $text = null, $type = null)
	{
		return $this->session->set_flashdata(
			[
				'title' => $title,
				'text' => $text,
				'type' => $type
			]
		);
	}
	public function checkToken()
	{
		if ($this->session->userdata('backToken')) {
			if ($this->auth->checkToken($this->session->userdata('backToken'))) {
				redirect('page');
			} else {
				$this->session->unset_userdata('backToken');
				redirect('page/logout');
			}
		}
	}
	function debug($data, $die = null)
	{
		echo "<pre>";
		print_r($data);
		if ($die) {
			die;
		}
	}
	public function MAIL_CONFIG()
	{
		$config = array(
			'protocol' => 'smtp',
			'smtp_host' => 'mail.rumahmbrio.com',
			'smtp_port' => 587,
			'smtp_user' => 'noreply@rumahmbrio.com',
			'smtp_pass' => 'RumahMbrio@.,',
			'mailtype' => 'html',
			'charset' => 'iso-8859-1',
			'wordwrap' => true
		);
		return $config;
	}

	public function index()
	{
		$this->checkToken();
		$this->load->view('auth/login');
	}
	public function login()
	{
		$data = $this->input->post();
		if ($this->input->post()) {
			$dataAdmin = $this->auth->getAdminByUsername($data['username']);
			$dataTeacher = $this->auth->getTeacherByUsername($data['username']);
			if ($dataAdmin) {
				if (password_verify($data['password'], $dataAdmin->password)) {
					$sess_ = [
						'fullName' => $dataAdmin->full_name,
						'username' => $dataAdmin->username,
						'level' => $dataAdmin->level,
						'id_' => $dataAdmin->id_admin,
						'backToken' => crypt($dataAdmin->full_name, ''),
						'main_photo' => 'users/' . $dataAdmin->admin_photo
					];
					$this->session->set_userdata($sess_);
					$this->auth->registToken($forToken = ['access_token' => $sess_['backToken']]);
					$this->message('Selamat datang ' . $dataAdmin->full_name . '!', 'Semoga hari anda menyenangkan:)', 'success');
					redirect('page');
				} else {
					$this->message('Ooppsss', 'Username dan password tidak sesuai, silahkan coba lagi', 'error');
				}
			} elseif ($dataTeacher) {
				if (password_verify($data['password'], $dataTeacher->teacher_password)) {
					$sess_ = [
						'fullName' => $dataTeacher->teacher_name,
						'username' => $dataTeacher->teacher_username,
						'level' => 'guru',
						'id_' => $dataTeacher->id_teacher,
						'backToken' => crypt($dataTeacher->teacher_name, ''),
						'main_photo' => 'teachers/' . $dataTeacher->teacher_photo
					];
					$this->session->set_userdata($sess_);
					$this->auth->registToken($forToken = ['access_token' => $sess_['backToken']]);
					$this->message('Selamat datang ' . $dataTeacher->teacher_name . '!', 'Semoga hari anda menyenangkan:)', 'success');
					redirect('page');
				} else {
					$this->message('Ooppsss', 'Username dan password tidak sesuai, silahkan coba lagi', 'error');
				}
			} else {
				$this->message('Ooppsss', 'Username tidak terdaftar, silahkan coba username lain', 'error');
			}
		}
		redirect('Auth');
	}
	public function exam()
	{
		if ($this->input->post()) {
			$data = $this->input->post();
			$student = $this->auth->getStudentByUsername($data['student_username']);
			if ($student) {
				if (password_verify($data['student_password'], $student->student_password)) {
					$class = false;
					$dataClass = $this->master->getClassById($student->id_class);
					if ($dataClass) {
						$class = $dataClass->class_level;
					}
					$sess_ = [
						'globalStudent' => $student,
						'class' => $class,
						'examToken' => crypt($student->student_password, '')
					];
					$this->session->set_userdata($sess_);
					$this->message('Wohoooo!!', 'Login berhasil di verifikasi, selamat datang ' . $student->student_name, 'success');
					redirect('exam/lists');
				} else {
					$this->message('Oooppss', 'Username dan password tidak sesuai, silahkan coba lagi', 'danger');
					redirect('Auth/exam');
				}
			} else {
				$this->message('Oooppss', 'Username tidak terdaftar, silahkan coba lagi', 'danger');
				redirect('Auth/exam');
			}
		} else {
			if ($this->session->userdata('examToken') and $this->session->userdata('globalStudent')) {
				redirect('Auth/exam');
			}
			$this->load->view('auth/loginExam');
		}
	}
	public function exam_regist()
	{
		if ($this->input->post()) {
			$data = $this->input->post();
			if ($this->auth->getStudentByUsername($data['student_username'])) {
				$this->message('Oooppss', 'Username sudah terdaftar, silahkan coba username lain', 'danger');
			} else {
				if ($this->input->post('id_class') == 'null' or !$this->input->post('student_password')) {
					$this->message('Oooppss', 'Terjadi kesalahan validasi data, pastikan semua data terisi!', 'danger');
				} else {
					// CHECK EMAIL //
					if ($this->master->getStudentByEmail($this->input->post('student_email'))) {
						$this->message('Oooppss', 'Email yang anda masukan sudah terdaftar, silahkan coba email lain!', 'danger');
						redirect('Auth/exam_regist');
					}
					// INIT DATA //
					$data = [
						'student_username' => $this->input->post('student_username'),
						'student_password' => $this->input->post('student_password'),
						'student_name' => $this->input->post('student_name'),
						'student_age' => $this->input->post('student_age'),
						'student_email' => $this->input->post('student_email'),
						'student_phone' => $this->input->post('student_phone'),
						'id_class' => $this->input->post('id_class'),
					];
					// CHECK UNIVERSITY //
					$university = [];
					if ($this->input->post('class_level') == 'XII') {
						for ($i = 1; $i <= $this->input->post('totalClone'); $i++) {
							if ($this->input->post('id_university' . $i) and $this->input->post('id_department' . $i)) {
								if ($this->input->post('id_university' . $i) != 'null' and $this->input->post('id_department' . $i) != 'null') {
									$single = [
										'id_university' => $this->input->post('id_university' . $i),
										'id_department' => $this->input->post('id_department' . $i),
									];
									$push = true;
									if ($university) {
										foreach ($university as $row => $value) {
											if ($value['id_university'] == $this->input->post('id_university' . $i) and $value['id_department'] == $this->input->post('id_department' . $i)) {
												$push = false;
											}
										}
										if ($push) {
											array_push($university, $single);
										}
									} else {
										array_push($university, $single);
									}
								}
							}
						}
						if (!$university) {
							$this->message('Oooppss', 'Pastikan anda memilih nama universitas dan jurusan!', 'danger');
							redirect('Auth/exam_regist');
						}
					}
					// END //
					$data['student_password'] = crypt($this->input->post('student_password'), '');
					$data['student_hide'] = 1;
					$data['student_link'] = sha1(crypt(date('Ymdhis') . $data['student_username'], ''));
					$studentId = $this->master->insertStudent_WITHCALLBACK($data);
					// INSERT STUDENT UNIVERSITY //
					foreach ($university as $row => $value) {
						$university = [
							'id_student' => $studentId,
							'id_university' => $value['id_university'],
							'id_department' => $value['id_department'],
						];
						$this->master->insertStudentUniversity($university);
					}
					// SEND MAIL //
					$config = $this->MAIL_CONFIG();
					$forEmail = ['data' => $data];
					$mail_body = $this->load->view('email/confirmation', $forEmail, true);
					$this->load->library('email', $config);
					$this->email->set_newline("\r\n");
					$this->email->from('noreply@rumahmbrio.com', "Sahabat M-BRIO");
					$this->email->to($data['student_email']);
					$this->email->subject('Konfirmasi pendaftaran');
					$this->email->message($mail_body);
					if ($this->email->send()) {
						// NO ACTION HERE //
					} else {
						// show_error($this->email->print_debugger());
					}
					// REDIRECT //
					$this->message('Wohoooo!!', 'Pendaftaran berhasil, silahkan periksa email anda untuk konfirmasi :)', 'success');
					redirect('Auth/exam');
				}
			}
			redirect('Auth/exam_regist');
		} else {
			$data = [
				'dataClass' => $this->master->getAllClass(),
				'dataUniversity' => $this->master->getAllUniversity(),
			];
			$this->load->view('auth/registExam', $data);
		}
	}
	public function getDepartmentByUniversity($id_university)
	{
		echo json_encode($this->master->getDepartmentByUniversity_SIMPLE($id_university));
	}
	public function link_confirmation($link = null)
	{
		if ($link) {
			$dataStudent = $this->master->getStudentByLink($link);
			if ($dataStudent) {
				$data = [
					'id_student' => $dataStudent->id_student,
					'student_link' => '',
					'student_hide' => 0
				];
				$this->master->updateStudent($data);
				$this->message('Wohoooo!!', 'Konfirmasi berhasil, silahkan login untuk melanjutkan :)', 'success');
			}
		}
		redirect('Auth/exam');
	}

	public function not_found()
	{
		echo "Page not found";
	}
}

/* End of file Auth.php */
/* Location: ./application/controllers/Auth.php */
