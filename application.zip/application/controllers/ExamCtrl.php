<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class ExamCtrl extends CI_Controller {

	public function __construct() {
		parent::__construct();
		$this->load->model('AssignmentModel','assignment',TRUE);
		$this->load->model('MasterModel','master',TRUE);
		$this->load->model('QuizModel','quiz',TRUE);
		date_default_timezone_set('Asia/Jakarta');
		if (!$this->session->userdata('examToken')) {
			$this->session->sess_destroy();
			redirect('Auth/exam');
		}
	}
	public function message($title = NULL,$text = NULL,$type = NULL) {
		return $this->session->set_flashdata([
				'title' => $title,
				'text' => $text,
				'type' => $type
			]
		);
	}
	function debug($data, $die = null) {
		echo "<pre>";
		print_r($data);
		if ($die) {
			die;
		}
	}
	public function GEN_PASSING_GRADE($value) {
		$callback = 0;
		$pg = str_replace('.', '', $value*100);
		$first = substr($pg, 0,2);
        $second = substr($pg, 2,2);
        if (strlen($pg) > 2) {
            $callback = $first.'.'.$second;
        } else {
            $callback = $first;
        }
        return $callback;
	}
	public function GEN_CLASS($id_class = null) {
		$callback = [
			'class' => null,
			'university' => []
		];
		$dataClass = $this->master->getClassById($id_class);
		if ($dataClass) {
			if ($dataClass->class_level == 'XII') {
				$callback['class'] = $dataClass->class_level;
				foreach ($this->master->getUniversityByStudent_FULLJOIN($this->session->userdata('globalStudent')->id_student) as $row => $value) {
					$pg = str_replace('.', '', $value->department_pg*100);
					$first = substr($pg, 0,2);
                    $second = substr($pg, 2,2);
                    if (strlen($pg) > 2) {
                        $final_pg = $first.'.'.$second;
                    } else {
                        $final_pg = $first;
                    }
					$value->department_pg = $final_pg;
					array_push($callback['university'], $value);
				}
			}
		}
		return $callback;
	}

	public $dataParse = [
		'navbar' => 'exam/inc/navbar',
		'title' => 'No title',
		'content' => ''
	];

	public function index() {
		redirect('exam/lists');
		// $this->dataParse['title'] = 'Dashboard - Boy Science Club';
		// $this->dataParse['content'] = 'exam/content/dashboard';
		// $this->load->view('MainExam',$this->dataParse);
	}
	public function lists() {
		$dataAssignments = [];
		foreach ($this->assignment->getAllAssignmentStudent() as $row => $value) {
			$push = false;
			foreach ($this->assignment->getClassByAssignment($value->id_assignment) as $r => $v) {
				if ($v->id_class == $this->session->userdata('globalStudent')->id_class) {
					$push = true;
				}
			}
			if ($push) {
				// VALIDATION TIME //
				$today = strtotime(date('Y-m-d H:i:s'));
				if (strtotime($value->assignment_start) <= $today && strtotime($value->assignment_end) >= $today ) {
					if (!$this->assignment->checkDoneAssignment($value->id_assignment,$this->session->userdata('globalStudent')->id_student)) {
						array_push($dataAssignments, $value);
					}
				}
			}
		}
		foreach ($dataAssignments as $r => $v) {
			$dataAssignments[$r]->totalQuestion = count($this->assignment->getQuestionByAssignment($v->id_assignment));
		}
		$studentClass = $this->GEN_CLASS($this->session->userdata('globalStudent')->id_class);
		$this->dataParse['studentClass'] = $studentClass;
		$this->dataParse['dataAssignments'] = $dataAssignments;
		$this->dataParse['title'] = 'List Ujian - Selamat mengikuti ujian';
		$this->dataParse['content'] = 'exam/content/lists';
		$this->load->view('MainExam',$this->dataParse);
	}
	public function lists_sbmptn() {
		if ($this->session->userdata('class') != 'XII') {
			redirect('exam');
		}
		$dataQuiz = [];
		foreach ($this->quiz->getQuizByClass($this->session->userdata('globalStudent')->id_class) as $row => $value) {
			$single = $this->quiz->getQuizById($value->id_quiz,true);
			if ($single) {
				$push_quiz = true;
				$push_result = true;
				$push_time = false;
				// VALIDATION EXIST IN TEMP VARIABLE //
				foreach ($dataQuiz as $r => $v) {
					if ($v->id_quiz == $value->id_quiz) {
						$push_quiz = false;
					}
				}
				$push_result = ($this->quiz->getResultByQuizStudent($value->id_quiz,$this->session->userdata('globalStudent')->id_student) ? true : false); // VALIDATION IN RESULT
				// VALIDATION TIME //
				$today = strtotime(date('Y-m-d H:i:s'));
				if (strtotime($single->quiz_start) <= $today && strtotime($single->quiz_end) >= $today ) {
					$push_time = true;
				}
				// GET LESSON QUIZ //
				$single->lessons = $this->quiz->getQuizLessonByQuiz($single->id_quiz);
				if ($push_quiz AND $push_time) {
					$single->done = false;
					if (!$push_result) {
						// $single->done = true;
						array_push($dataQuiz, $single);
					}
				}
			}
		}
		$this->dataParse['dataQuiz'] = $dataQuiz;
		$this->dataParse['title'] = 'List Ujian Kelas XII - Selamat mengikuti ujian';
		$this->dataParse['content'] = 'exam/content/lists_sbmptn';
		$this->load->view('MainExam',$this->dataParse);
	}
	public function begin() {
		if (!$this->input->post()) {
			redirect('exam/lists');
		}
		$dataAssignment = $this->assignment->getAssignmentById_andPassword($this->input->post('id_assignment'),$this->input->post('assignment_password'));
		if (!$dataAssignment) {
			$this->message('Oooppss!','Kata sandi ujian yang anda masukan tidak sesuai, silahkan coba lagi!','error');
			redirect('exam/lists');
		}
		$id_assignment = $dataAssignment->id_assignment;
		$long = $dataAssignment->assignment_duration;
		$now = strtotime(date('H:i'));
		$begin = [
			'id_assignment' => $id_assignment,
			'id_student' => $this->session->userdata('globalStudent')->id_student,
			'time_begin' => date('H:i')
		];
		$lastBegin = $this->assignment->checkBegin($begin);
		if ($lastBegin) {
			$divide_time = strtotime(date('H:i', strtotime('+'.$dataAssignment->assignment_duration.' minutes',strtotime($lastBegin->time_begin))));
			if ($now > $divide_time) {
				$long = 0;
			} else {
				$long = round(abs($divide_time - $now) / 60);
			}
		} else {
			$this->assignment->insertBegin($begin);
		}
		// LAST VALIDITY OF RECENT TIME //
		$assignmentEnd = strtotime(substr($dataAssignment->assignment_end, 11,5));
		if ($now > $assignmentEnd) {
			$long = 0;
		} else {
			$now_divide = round(abs($assignmentEnd - $now) / 60);
			if ($now_divide <= $long) {
				$long = $now_divide;
			}
		}
		$dataAssignment->questions = $this->assignment->getQuestionByAssignment($id_assignment,$dataAssignment->assignment_order);
		foreach ($dataAssignment->questions as $row => $value) {
			$dataAssignment->questions[$row]->options = $this->assignment->getOptionByQuestion($value->id_question);
		}
		$this->dataParse['long'] = $long;
		$this->dataParse['dataAssignment'] = $dataAssignment;
		$this->dataParse['title'] = 'Selamat Mengerjakan - Selamat Mengerjakan';
		$this->dataParse['content'] = 'exam/content/begin';
		$this->load->view('MainExam',$this->dataParse);
	}
	public function calculate($ajax = null) {
		$dataAssignment = $this->assignment->getAssignmentById($this->input->post('id_assignment'));
		$resultTrue = 0;
		$resultFalse = 0;
		$resultEmpty = 0;
		$dataResult = [
			'id_assignment' => $this->input->post('id_assignment'),
			'id_student' => $this->session->userdata('globalStudent')->id_student,
			'result_created' => date('Y-m-d H:i:s')
		];
		foreach ($this->input->post('id_question') as $row => $value) {
			$option = $this->input->post('option'.$value);
			$option_char = $this->input->post('key_option'.$value.$this->input->post('option'.$value));
			if (!$option) {
				$option = '';
				$analytics_status = 'empty';
				$resultEmpty++;
			}
			if (!$option_char) {
				$option_char = '';
			}
			if ($option != '') {
				if ($this->assignment->checkTrueOption($option)) {
					$analytics_status = 'true';
					$resultTrue++;
				} else {
					$analytics_status = 'false';
					$resultFalse++;
				}
			}
			$forAnalytics = [
				'id_assignment' => $this->input->post('id_assignment'),
				'id_student' => $this->session->userdata('globalStudent')->id_student,
				'id_question' => $value,
				'id_option' => $option,
				'option_char' => $option_char,
				'analytics_status' => $analytics_status,
				'analytics_created' => date('Y-m-d H:i:s'),
			];
			$this->assignment->insertAssignmentAnalytics($forAnalytics);
		}
		// CONTINUE RESULT DATA //
		$dataResult['result_true'] = $resultTrue;
		$dataResult['result_false'] = $resultFalse;
		$dataResult['result_empty'] = $resultEmpty;
		$questionTotal = count($this->assignment->getQuestionByAssignment($this->input->post('id_assignment')));
		// (B x 4) – (S x 1) x 100 / JS x 4
		// $finalScore = ((($resultTrue * 4) - ($resultFalse * 1)) * 100) / ($questionTotal * 4);
		$finalScore = ((($resultTrue * $dataAssignment->assignment_true_value) - ($resultFalse * $dataAssignment->assignment_false_value)) * 100) / $questionTotal;
		$dataResult['result_score'] = $finalScore;
		// RESULT VALIDITY //
		$studentClass = $this->GEN_CLASS($this->session->userdata('globalStudent')->id_class);
		$resultStatus = 'lulus';
		$studentUniversity = [];
		if ($studentClass['class'] == 'XII') {
			$resultStatus = 'university';
			foreach ($studentClass['university'] as $row => $value) {
				$rUniv_status = 'gagal';
				if ($finalScore >= $value->department_pg) {
					$rUniv_status = 'lulus';
				}
				$single = [
					'id_sUniversity' => $value->id_sUniversity,
					'rUniv_status' => $rUniv_status
				];
				array_push($studentUniversity, $single);
			}
		} else {
			if ($finalScore < $dataAssignment->assignment_kkm) { $resultStatus = 'gagal'; }
		}
		// END //
		$dataResult['result_status'] = $resultStatus;
		$resultId = $this->assignment->insertAssignmentResult($dataResult);
		if ($dataResult['result_status'] == 'university') {
			foreach ($studentUniversity as $row => $value) {
				$value['id_aresult'] = $resultId;
				$this->assignment->insertAssignmentResultUniversity($value);
			}
		}
		// DELETE AND REDIRECT //
		$this->assignment->deleteAssignmentBegin($dataAssignment->id_assignment,$this->session->userdata('globalStudent')->id_student); // DELETE BEGIN
		if ($ajax) {
			echo "success";
		} else {
			if ($dataAssignment->show_report == 1) {
				$this->message('Yeeaay!','Ujian berhasil dikumpulkan, anda bisa melihat hasilnya disini :)','success');
				redirect('exam/report/'.$dataAssignment->id_assignment);
			} else {
				$this->message('Yeeaay!','Ujian berhasil dikumpulkan, semoga hasilnya memuaskan :)','success');
				redirect('exam/lists');
			}
		}
	}
	public function history() {
		$dataAssignments = [];
		$dataQuiz = [];
		foreach ($this->assignment->getResultByStudent($this->session->userdata('globalStudent')->id_student) as $row => $value) {
			$assignment = $this->assignment->getAssignmentById($value->id_assignment);
			if ($assignment) {
				$assignment->resultCreated = $value->result_created;
				array_push($dataAssignments,$assignment);
			}
		}
		foreach ($dataAssignments as $r => $v) {
			$dataAssignments[$r]->totalQuestion = count($this->assignment->getQuestionByAssignment($v->id_assignment));
		}
		// DATA QUIZ //
		foreach ($this->quiz->getQuizByClass($this->session->userdata('globalStudent')->id_class) as $row => $value) {
			$single = $this->quiz->getQuizById($value->id_quiz,true);
			if ($single) {
				$push_quiz = true;
				$push_result = true;
				$push_time = true;
				// VALIDATION EXIST IN TEMP VARIABLE //
				foreach ($dataQuiz as $r => $v) {
					if ($v->id_quiz == $value->id_quiz) {
						$push_quiz = false;
					}
				}
				$push_result = ($this->quiz->getResultByQuizStudent($value->id_quiz,$this->session->userdata('globalStudent')->id_student) ? true : false); // VALIDATION IN RESULT
				// GET LESSON QUIZ //
				$single->lessons = $this->quiz->getQuizLessonByQuiz($single->id_quiz);
				if ($push_quiz AND $push_time) {
					$single->done = false;
					if ($push_result) {
						$single->done = true;
						array_push($dataQuiz, $single);
					}
				}
			}
		}
		// PARSING //
		$this->dataParse['dataQuiz'] = $dataQuiz;
		$this->dataParse['studentUniversity'] = $this->GEN_CLASS($this->session->userdata('globalStudent')->id_class);
		$this->dataParse['dataAssignments'] = $dataAssignments;
		$this->dataParse['title'] = 'Riwayat Ujian - Riwayat Ujian';
		$this->dataParse['content'] = 'exam/content/history';
		$this->load->view('MainExam',$this->dataParse);
	}
	public function report($id_assignment = NULL) {
		if (!$id_assignment) {
			redirect('exam');
		}
		$dataAssignment = $this->assignment->getAssignmentById($id_assignment);
		if (!$id_assignment) {
			redirect('exam');
		} elseif($dataAssignment->show_report != 1) {
			redirect('exam');
		}
		$dataResult = $this->assignment->getResultStudentById($id_assignment,$this->session->userdata('globalStudent')->id_student);
		$dataAnalytics = $this->assignment->getAnalyticsStudentById($id_assignment,$this->session->userdata('globalStudent')->id_student);
		foreach ($dataAnalytics as $_row => $_value) {
			$dataAnalytics[$_row]->studentChoosed = $this->assignment->getOptionById($_value->id_option);
			$dataAnalytics[$_row]->trueAnswer = $this->assignment->getTrueAnswerByQuestion($_value->id_question);
		}
		$studentUniversity = [];
		if ($dataResult->result_status == 'university') {
			$studentUniversity = $this->GEN_CLASS($this->session->userdata('globalStudent')->id_class);
		}
		$this->dataParse['studentUniversity'] = $studentUniversity;
		$this->dataParse['dataAssignment'] = $dataAssignment;
		$this->dataParse['dataResult'] = $dataResult;
		$this->dataParse['dataAnalytics'] = $dataAnalytics;
		$this->dataParse['title'] = 'Hasil Ujian - Hasil Ujian';
		$this->dataParse['content'] = 'exam/content/report';
		$this->load->view('MainExam',$this->dataParse);
	}
	public function change_password() {
		if ($this->input->post()) {
			$data = $this->input->post();
			$data['student_password'] = crypt($this->input->post('student_password'),'');
			unset($data['old_password']);
			if (!password_verify($this->input->post('old_password'),$this->session->userdata('globalStudent')->student_password)) {
				$this->message('Wooopsss!','Password lama tidak sesuai dengan yang tersedia :(','error');
				redirect('exam/change_password');
			}
			$dataStudent = $this->master->getStudentById($data['id_student']);
			$this->master->updateStudent($data);
			$this->session->unset_userdata('globalStudent');
			$sess_ = [ 'globalStudent' => $dataStudent ];
			$this->session->set_userdata($sess_);
			$this->message('Yeeaay!','Password anda berhasil diubah :)','success');
			redirect('exam/lists');
		} else {
			$this->dataParse['title'] = 'Ubah Password - Ubah Password';
			$this->dataParse['content'] = 'exam/content/change_password';
			$this->load->view('MainExam',$this->dataParse);
		}
	}
	public function begin_sbmptn() {
		if ($this->input->post()) {
			// CHECK STUDENT RESULT //
			if ($this->quiz->getQuizResultByStudent($this->input->post('id_quiz'),$this->session->userdata('globalStudent')->id_student)) {
				$this->message('Oooppss!','Anda sudah mengerjakan soal ini!','error');
				redirect('exam/lists_sbmptn');
			}
			// END //
			$data = $this->input->post();
			$dataQuiz = $this->quiz->getQuizById($this->input->post('id_quiz'),true);
			if ($dataQuiz) {
				$lessons = $this->quiz->getQuizLessonByQuiz($this->input->post('id_quiz'),$dataQuiz->quiz_order);
				if (!$lessons) {
					$this->message('Oooppss!','Ujian terpilih belum siap untuk diujikan, silahkan hubungi pihak sekolah!','error');
					redirect('exam/lists_sbmptn');
				}
				if ($this->input->post('quiz_password') != $dataQuiz->quiz_password) {
					$this->message('Oooppss!','Kata sandi ujian yang anda masukan tidak sesuai!','error');
					redirect('exam/lists_sbmptn');
				}
				// QUERY DATA //
				$quiz_lesson = $this->quiz->getQuizLessonByQuiz($dataQuiz->id_quiz,$dataQuiz->quiz_order);
				if (!$quiz_lesson) {
					$this->message('Oooppss!','Tidak ada ujian tersedia!','error');
					redirect('exam/lists_sbmptn');
				}
				foreach ($quiz_lesson as $row => $value) {
					$questions = $this->quiz->getQuestionByQuizLesson($this->input->post('id_quiz'),$value->id_lQuiz,$dataQuiz->quiz_order);
					foreach ($questions as $r => $v) {
						$questions[$r]->options = $this->assignment->getOptionByQuestion($v->id_question);
					}
					$quiz_lesson[$row]->questions = $questions;
				}
				$dataQuiz->quiz_lesson = $quiz_lesson;
				// VALIDATE BEGIN TIME //
				$recent_time = $dataQuiz->quiz_duration;
				$now = strtotime(date('H:i'));
				$begin = [
					'id_quiz' => $this->input->post('id_quiz'),
					'id_student' => $this->session->userdata('globalStudent')->id_student,
					'qBegin_time' => date('H:i')
				];
				$lastBegin = $this->quiz->getQuizBegin($this->input->post('id_quiz'),$begin['id_student']);
				if ($lastBegin) {
					// $to_time = strtotime(date("H:i:s"));
					// $to_time = strtotime(substr($dataQuiz->quiz_end, 11,5));
					// $from_time = strtotime($lastBegin->qBegin_time);
					// NEW //
					$divide_time = strtotime(date('H:i', strtotime('+'.$dataQuiz->quiz_duration.' minutes',strtotime($lastBegin->qBegin_time))));
					if ($now > $divide_time) {
						$recent_time = 0;
					} else {
						$recent_time = round(abs($divide_time - $now) / 60);
					}
				} else {
					$this->quiz->insertQuizBegin($begin);
				}
				// LAST VALIDITY OF RECENT TIME //
				$quizEnd = strtotime(substr($dataQuiz->quiz_end, 11,5));
				if ($now > $quizEnd) {
					$recent_time = 0;
				} else {
					$now_divide = round(abs($quizEnd - $now) / 60);
					if ($now_divide <= $recent_time) {
						$recent_time = $now_divide;
					}
				}
				// PARSING //
				$this->dataParse['recent_time'] = $recent_time;
				$this->dataParse['dataQuiz'] = $dataQuiz;
				$this->dataParse['title'] = 'Selamat Mengerjakan - Selamat Mengerjakan';
				$this->dataParse['content'] = 'exam/content/begin_sbmptn';
				$this->load->view('MainExam',$this->dataParse);
			} else {
				$this->message('Oooppss!','Terjadi kesalahan ketika me-load data ujian :(','error');
				redirect('exam/lists_sbmptn');
			}
		} else {
			redirect('exam/lists_sbmptn');
		}
	}
	public function calculate_sbmptn($ajax = null) {
		// $this->debug($this->input->post(),true);
		if ($this->input->post()) {
			$dataQuiz = $this->quiz->getQuizById($this->input->post('id_quiz'));
			if (!$dataQuiz) {
				$this->message('Oooppss!','Terjadi kesalahan ketika menyimpan data :(','error');
				redirect('exam/lists_sbmptn');
			}
			foreach ($this->input->post('id_lQuiz') as $rQuiz => $vQuiz) {
				$quiz_result = [
					'id_quiz' => $this->input->post('id_quiz'),
					'id_lQuiz' => $vQuiz,
					'id_student' => $this->session->userdata('globalStudent')->id_student,
					'rQuiz_total_true' => 0,
					'rQuiz_total_false' => 0,
					'rQuiz_total_empty' => 0,
					'rQuiz_last_score' => 0,
					'rQuiz_created' => date('Y-m-d H:i:s')
				];
				$value_true = 0;
				$value_false = 0;
				$total_question = 0;
				$data_analytics = [];
				foreach ($this->input->post('id_question') as $row => $value) {
					$arr = explode('-', $value);
					$id_lQuiz = $arr[0];
					$value_true = $arr[1];
					$value_false = $arr[2];
					$id_qQuiz = $arr[3];
					$id_question = $arr[4];
					// VALIDATION //
					if ($vQuiz == $id_lQuiz) {
						$total_question++;
						$option_status = 'empty';
						// ANALYTICS //
						$single_analytic = [
							'id_quiz' => $this->input->post('id_quiz'),
							'id_lQuiz' => $id_lQuiz,
							'id_qQuiz' => $id_qQuiz,
							'id_student' => $this->session->userdata('globalStudent')->id_student,
							'aQuiz_option_id' => 0,
							'aQuiz_option_alphabet' => '',
							'aQuiz_status' => 'empty',
							'aQuiz_created' => date('Y-m-d H:i:s')
						];
						// VALIDATING.. //
						if ($this->input->post('option'.$id_question)) {
							if ($this->assignment->getTrueAnswerByOption($this->input->post('option'.$id_question))) {
								$single_analytic['aQuiz_status'] = 'true';
								$quiz_result['rQuiz_total_true'] += 1;
							} else {
								$single_analytic['aQuiz_status'] = 'false';
								$quiz_result['rQuiz_total_false'] += 1;
							}
							$single_analytic['aQuiz_option_id'] = $this->input->post('option'.$id_question);
							$single_analytic['aQuiz_option_alphabet'] = $this->input->post('key_option'.$id_question.$this->input->post('option'.$id_question));
						} else {
							$quiz_result['rQuiz_total_empty'] += 1;
						}
						array_push($data_analytics, $single_analytic);
					} // DATA IN LESSON QUIZ VALIDATION //
				} // END FOREACH QUESTION //
				// CALCUlATE FINAL SCORE => (B x 4) – (S x 1)
				$score_true = $quiz_result['rQuiz_total_true'] * $value_true;
				$score_false = $quiz_result['rQuiz_total_false'] * $value_false;
				$last_score = substr(($score_true - $score_false), 0,4);
				$last_score = ($last_score < 0 ? 0 : $last_score);
				$quiz_result['rQuiz_last_score'] = $last_score;
				// INSERTING TO DATABASE //
				$resultId = $this->quiz->insertQuizResult($quiz_result);
				foreach ($data_analytics as $r => $v) {
					$v['id_rQuiz'] = $resultId;
					$this->quiz->insertQuizAnalytic($v);
				}
				$this->quiz->deleteQuizBegin($this->input->post('id_quiz'),$this->session->userdata('globalStudent')->id_student); // DELETE QUIZ BEGIN //
			}
			// REDIRECTING //
			if ($ajax) {
				echo "success";
			} else {
				$this->message('Yeeaay','Ujian anda berhasil disimpan, semoga suksesss :)','success');
				if ($dataQuiz->quiz_show_report == 1 OR $dataQuiz->quiz_show_analytic == 1) {
					redirect('exam/report_sbmptn/'.$dataQuiz->id_quiz);
				} else {
					redirect('exam/lists_sbmptn');
				}
			}
		} else {
			redirect('exam/lists_sbmptn');
		}
	}
	public function report_sbmptn($id_quiz = null) {
		$dataQuiz = $this->quiz->getQuizById($id_quiz);
		if (!$dataQuiz) {
			redirect('exam/lists_sbmptn');
		}
		$dataResult = $this->quiz->getQuizResultByStudent_FULLJOIN($id_quiz,$this->session->userdata('globalStudent')->id_student);
		if (!$dataResult) {
			redirect('exam/lists_sbmptn');
		}
		if ($dataQuiz->quiz_show_report != 1) {
			$this->message('Oooppss','Anda tidak diperbolehkan untuk melihat hasil ujian ini :(','error');
			redirect('exam/lists_sbmptn');
		}
		foreach ($dataResult as $row => $value) {
			$analytics = $this->quiz->getQuizAnalyticByResult($value->id_rQuiz);
			foreach ($analytics as $r => $v) {
				$analytics[$r]->student_answer = false;
				$analytics[$r]->true_answer = false;
				if ($v->aQuiz_status != 'empty') {
					// STUDENT ANSWER //
					$student_answer = $this->quiz->getOptionById($v->aQuiz_option_id);
					if ($student_answer) {
						$analytics[$r]->student_answer = $student_answer;
					}
				}
				// TRUE ANSWER //
				$true_answer = $this->quiz->getTrueOptionByQuestion($v->id_question);
				if ($true_answer) {
					$analytics[$r]->true_answer = $true_answer;
				}
			}
			$dataResult[$row]->analytics = $analytics;
		}
		$this->dataParse['dataResult'] = $dataResult;
		$this->dataParse['dataQuiz'] = $dataQuiz;
		$this->dataParse['title'] = 'Hasil Ujian';
		$this->dataParse['content'] = 'exam/content/report_sbmptn';
		$this->load->view('MainExam',$this->dataParse);
	}
	public function report_achievement() {
		if ($this->session->userdata('class') != 'XII') {
			redirect('exam');
		}
		$categoryQuizId = '';
		if ($this->input->post()) {
			$categoryQuizId = $this->input->post('id_category_quiz');
			$dataQuiz = [];
			foreach ($this->quiz->getQuizByCategory($this->input->post('id_category_quiz')) as $row => $value) {
				$result = $this->quiz->getResultByQuizStudent_all($value->id_quiz,$this->session->userdata('globalStudent')->id_student);
				if ($result) {
					foreach ($result as $r => $v) {
						$result[$r]->lesson_quiz = $this->quiz->getQuizLessonById($v->id_lQuiz);
					}
					$value->result = $result;
					array_push($dataQuiz, $value);
				}
			}
			$student_university = $this->master->getUniversityByStudent_FULLJOIN($this->session->userdata('globalStudent')->id_student);
			foreach ($student_university as $row => $value) {
				$student_university[$row]->department_pg = $this->GEN_PASSING_GRADE($value->department_pg);
			}
			// PARSING //
			$this->dataParse['dataQuiz'] = $dataQuiz;
			$this->dataParse['student_university'] = $student_university;
			// SESS //
			$sess_ = [
				'EXPORT_ACHIEVEMENT_dataQuiz' => $dataQuiz,
				'EXPORT_ACHIEVEMENT_student_university' => $student_university
			];
			$this->session->set_userdata($sess_);
		}
		// GET CATEGORY BY STUDENT //
		$student_category_quiz = [];
		$temp_category = [];
		foreach ($this->master->getDistinctQuizByStudent($this->session->userdata('globalStudent')->id_student) as $row => $value) {
			foreach ($this->master->getDistinctCategoryByQuiz($value->id_quiz) as $r => $v) {
				array_push($temp_category, $v->id_category_quiz);
			}
		}
		foreach ($temp_category as $row => $value) {
			$push = true;
			foreach ($student_category_quiz as $r => $v) {
				if ($value == $v) {
					$push = false;
				}
			}
			if($push) {
				array_push($student_category_quiz, $value);
			}
		}
		// PARSING //
		$this->dataParse['student_category_quiz'] = $student_category_quiz;
		$this->dataParse['categoryQuizId'] = $categoryQuizId;
		$this->dataParse['dataCategory'] = $this->quiz->getQuizCategory();
		$this->dataParse['title'] = 'Rekap Ujian Kelas XII';
		$this->dataParse['content'] = 'exam/content/report_achievement';
		$this->load->view('MainExam',$this->dataParse);
	}
	public function export_report_achievement() {
		$dataQuiz = $this->session->userdata('EXPORT_ACHIEVEMENT_dataQuiz');
		$student_university = $this->session->userdata('EXPORT_ACHIEVEMENT_student_university');
		if ($dataQuiz && $student_university) {
			$data = [
				'dataQuiz' => $dataQuiz,
				'student_university' => $student_university,
			];
			$html = $this->load->view('exam/content/report_achievement_pdf', $data, TRUE);
	        $this->load->library('pdf');
	        $this->pdf->pdf->AddPage('L', // L - landscape, P - portrait
            '', '', '', '',
            30, // margin_left
            30, // margin right
            30, // margin top
            30, // margin bottom
            18, // margin header
            12); // margin footer
	        $this->pdf->pdf->WriteHTML($html);
	        $this->pdf->pdf->Output('Laporan-Rekap-Ujian.pdf','I');
		} else {
			redirect('exam/report_achievement');
		}
	}

	// HANDLER //
	public function logout() {
		$this->session->unset_userdata('globalStudent');
		$this->session->unset_userdata('examToken');
		$this->message('Yeeaay','Silahkan login kembali untuk melanjutkan','success');
		redirect('Auth/exam');
	}

}

/* End of file ExamCtrl.php */
/* Location: ./application/controllers/ExamCtrl.php */