<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class QuizCtrl extends MY_Controller {

	public function index() {
		redirect('page/quiz_sbmptn');
	}
	public function add() {
		if ($this->input->post()) {
			$data = $this->input->post();
			if (!$this->input->post('id_class')) {
				$this->message('Oooopsss!','Anda belum memilih kelas untuk ujian ini!','error');
			} else {
				$id_class = $this->input->post('id_class');
				unset($data['id_class']);
				$data['quiz_created'] = date('Y-m-d H:i:s');
				$data['quiz_author_id'] = $this->session->userdata('id_');
				$data['quiz_author'] = $this->session->userdata('level');
				$data['quiz_start'] = str_replace('/', '-', $data['quiz_start']);
				$data['quiz_end'] = str_replace('/', '-', $data['quiz_end']);
				$data['quiz_kkm'] = str_replace(',', '.', $data['quiz_kkm']);
				$quizId = $this->quiz->insertQuiz($data);
				foreach ($id_class as $row => $value) {
					$quiz_class = [
						'id_quiz' => $quizId,
						'id_class' => $value,
						'cQuiz_created' => date('Y-m-d H:i:s')
					];
					$this->quiz->insertQuizClass($quiz_class);
				}
				// UPDATE QUIZ //
				$quizPassword = substr(sha1(crypt(date('sishmys').$quizId,'')), 2,5);
				if ($this->input->post('quiz_password')) {
					$quizPassword = $this->input->post('quiz_password');
				}
				$new = [
					'id_quiz' => $quizId,
					'quiz_password' => $quizPassword
				];
				$this->quiz->updateQuiz($new);
				// END //
				$this->message('Yeeayyy!','Data ujian SBMPTN berhasil ditambahkan :)','success');
			}
		}
		redirect('page/quiz_sbmptn');
	}
	public function edit() {
		if ($this->input->post()) {
			$data = $this->input->post();
			if (!$this->input->post('id_class')) {
				$this->message('Oooopsss!','Anda belum memilih kelas untuk ujian ini!','error');
			} else {
				$id_class = $this->input->post('id_class');
				unset($data['id_class']);
				$data['quiz_start'] = str_replace('/', '-', $data['quiz_start']);
				$data['quiz_end'] = str_replace('/', '-', $data['quiz_end']);
				$data['quiz_kkm'] = str_replace(',', '.', $data['quiz_kkm']);
				$this->quiz->updateQuiz($data);
				// QUIZ CLASS //
				$this->quiz->deleteClassByQuiz($this->input->post('id_quiz'));
				foreach ($id_class as $row => $value) {
					$quiz_class = [
						'id_quiz' => $this->input->post('id_quiz'),
						'id_class' => $value,
						'cQuiz_created' => date('Y-m-d H:i:s')
					];
					$this->quiz->insertQuizClass($quiz_class);
				}
				$this->message('Yeeayyy!','Data ujian SBMPTN berhasil diubah :)','success');
			}
		}
		redirect('page/quiz_sbmptn');
	}
	public function deleteQuiz($id_quiz = null) {
		if ($id_quiz) {
			$data = [
				'id_quiz' => $id_quiz,
				'quiz_hide' => 1
			];
			$this->quiz->updateQuiz($data);
			$this->message('Yeeayyy!','Data ujian berhasil dihapus!','success');
		}
		redirect('page/quiz_sbmptn');
	}
	public function add_lesson() {
		if ($this->input->post()) {
			$data = $this->input->post();
			if ($this->quiz->getLessonByQuizAndLesson($this->input->post('id_quiz'),$this->input->post('id_lesson'))) {
				$this->message('Oooopsss!','Pelajaran sudah terdaftar pada ujian ini!','error');
			} else {
				$data['lQuiz_created'] = date('Y-m-d H:i:s');
				$this->quiz->insertQuizLesson($data);
				$this->message('Yeeayyy!','Data pelajaran berhasil ditambahkan!','success');
			}
		}
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function edit_lesson() {
		if ($this->input->post()) {
			$data = $this->input->post();
			if (!$this->quiz->getLessonByQuizAndLesson($this->input->post('id_quiz'),$this->input->post('id_lesson'),$this->input->post('id_lQuiz'))) {
				if ($this->quiz->getLessonByQuizAndLesson($this->input->post('id_quiz'),$this->input->post('id_lesson'))) {
					$this->message('Oooopsss!','Pelajaran sudah terdaftar pada ujian ini!','error');
					redirect($_SERVER['HTTP_REFERER']);
				}
			}
			$this->quiz->updateQuizLesson($data);
			$this->message('Yeeayyy!','Data pelajaran berhasil diubah!','success');
		}
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function delete_lesson($id_lQuiz = null) {
		if ($id_lQuiz) {
			$data = [
				'id_lQuiz' => $id_lQuiz,
				'lQuiz_hide' => 1
			];
			$this->quiz->updateQuizLesson($data);
			$this->message('Yeeayyy!','Data pelajaran berhasil dihapus!','success');
		}
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function create_question() {
		if ($this->input->post()) {
			$data = $this->input->post();
			// QUESTION //
			$question = [
				'id_lesson' => $this->input->post('id_lesson'),
				'question_' => $this->input->post('question_'),
				'question_type' => 'sbmptn',
				'question_created' => date('Y-m-d')
			];
			if ($_FILES['question_image']['name']) {
				$this->imageConf('questions');
				if (!$this->upload->do_upload('question_image')){
					$this->message('Oooopsss!',strip_tags($this->upload->display_errors()),'error');
					redirect($_SERVER['HTTP_REFERER']);
				} else {
					$uploaded = $this->upload->data();
					$question['question_image'] = $uploaded['file_name'];
				}
			}
			$questionId = $this->quiz->insertQuestion($question);
			// OPTION //
			for ($i=0; $i <= $this->input->post('totalAnswer'); $i++) { 
				if ($this->input->post('option_'.$i)) {
					$option_true = ($i == $this->input->post('choosedAnswer') ? 1 : 0);
					$option = [
						'id_question' => $questionId,
						'option_' => $this->input->post('option_'.$i),
						'option_true' => $option_true,
						'option_created' => date('Y-m-d H:i:s'),
					];
					// IMAGE //
					if ($_FILES['option_image'.$i]['name']) {
						$this->imageConf('questions');
						if ($this->upload->do_upload('option_image'.$i)){
							$uploaded = $this->upload->data();
							$option['option_image'] = $uploaded['file_name'];
						}
					}
					$this->quiz->insertOption($option);
				}
			}
			// QUIZ QUESTION //
			$quiz_question = [
				'id_quiz' => $this->input->post('id_quiz'),
				'id_lQuiz' => $this->input->post('id_lQuiz'),
				'id_question' => $questionId,
			];
			$this->quiz->insertQuizQuestion($quiz_question);
			// UPDATE QUIZ LESSON //
			$quiz_lesson = [ 'id_lQuiz' => $this->input->post('id_lQuiz'), 'lQuiz_total_question' => $this->input->post('lQuiz_total_question') + 1 ];
			$this->quiz->updateQuizLesson($quiz_lesson);
			$this->message('Yeeayyy!','Data pertanyaan berhasil disimpan!','success');
		}
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function delete_question($id_qQuiz = null) {
		if ($id_qQuiz) {
			$data = [
				'id_qQuiz' => $id_qQuiz,
				'qQuiz_hide' => 1
			];
			$this->quiz->updateQuizQuestion($data);
			$this->message('Yeeayyy!','Data pertanyaan berhasil diubah!','success');
		}
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function deleteOption($id_question = null, $id_option = null) {
		if ($id_question AND $id_option) {
			$data = [
				'id_option' => $id_option,
				'option_hide' => 1
			];
			$this->quiz->updateOption($data);
			$this->message('Yeeayyy!','Data jawaban berhasil dihapus!','success');
		}
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function updateQuestion() {
		if ($this->input->post()) {
			$data = $this->input->post();
			// QUESTION //
			$question = [
				'id_question' => $this->input->post('id_question'),
				'id_lesson' => $this->input->post('id_lesson'),
				'question_' => $this->input->post('question_'),
				'question_type' => 'sbmptn',
				'question_created' => date('Y-m-d')
			];
			if ($this->input->post('no_lesson')) {
				unset($question['id_lesson']);
			} else {
				$question['id_lesson'] = $this->input->post('id_lesson');
			}
			if ($_FILES['question_image']['name']) {
				$this->imageConf('questions');
				if (!$this->upload->do_upload('question_image')){
					$this->message('Oooopsss!',strip_tags($this->upload->display_errors()),'error');
					redirect($_SERVER['HTTP_REFERER']);
				} else {
					$uploaded = $this->upload->data();
					$question['question_image'] = $uploaded['file_name'];
				}
			}
			$this->quiz->updateQuestion($question);
			// OPTION //
			for ($i=0; $i <= $this->input->post('totalAnswer'); $i++) { 
				if ($this->input->post('option_'.$i)) {
					$option_true = ($i == $this->input->post('choosedAnswer') ? 1 : 0);
					$option = [
						'id_question' => $this->input->post('id_question'),
						'option_' => $this->input->post('option_'.$i),
						'option_true' => $option_true,
					];
					// IMAGE //
					if ($_FILES['option_image'.$i]['name']) {
						$this->imageConf('questions');
						if ($this->upload->do_upload('option_image'.$i)){
							$uploaded = $this->upload->data();
							$option['option_image'] = $uploaded['file_name'];
						}
					}
					if ($this->input->post('id_option'.$i)) {
						$option['id_option'] = $this->input->post('id_option'.$i);
						$this->quiz->updateOption($option);
					} else {
						$option['option_created'] = date('Y-m-d H:i:s');
						$this->quiz->insertOption($option);
					}
				}
			}
			$this->message('Yeeayyy!','Data pertanyaan berhasil diubah!','success');
		}
		redirect($_SERVER['HTTP_REFERER']);
	}
	public function category($id_category_quiz = null) {
		if ($this->input->post()) {
			$data = $this->input->post();
			if ($this->input->post('id_category_quiz')) {
				$this->quiz->updateQuizCategory($data);
				$this->message('Yeeayyy!','Data kategori berhasil diubah!','success');
			} else {
				$data['category_quiz_created'] = date('Y-m-d H:i:s');
				$this->quiz->insertQuizCategory($data);
				$this->message('Yeeayyy!','Data kategori berhasil ditambahkan!','success');
			}
		} elseif($id_category_quiz) {
			$data = [
				'id_category_quiz' => $id_category_quiz,
				'category_quiz_hide' => 1
			];
			$this->quiz->updateQuizCategory($data);
			$this->message('Yeeayyy!','Data kategori berhasil dihapus!','success');
		}
		redirect('page/quiz_category');
	}
	public function title($id_qTitle = null) {
		if ($this->input->post()) {
			$data = $this->input->post();
			if ($this->input->post('id_qTitle')) {
				$this->quiz->updateQuizTitle($data);
				$this->message('Yeeayyy!','Data judul ujian berhasil diubah!','success');
			} else {
				$data['qTitle_created'] = date('Y-m-d H:i:s');
				$this->quiz->insertQuizTitle($data);
				$this->message('Yeeayyy!','Data judul ujian berhasil ditambahkan!','success');
			}
		} elseif($id_qTitle) {
			$this->quiz->deleteQuizTitle($id_qTitle);
			$this->message('Yeeayyy!','Data judul ujian berhasil dihapus!','success');
		}
		redirect('page/quiz_title');
	}
	public function useQuestionForQuiz() {
		if ($this->input->post()) {
			$data = $this->input->post();
			if (!$this->input->post('id_question')) {
				$this->message('Oooopsss!','Anda belum memilih satupun soal untuk digunakan','error');
			} else {
				$count = 0;
				foreach ($this->input->post('id_question') as $row => $value) {
					$question = [
						'id_quiz' => $this->input->post('id_quiz'),
						'id_lQuiz' => $this->input->post('id_lQuiz'),
						'id_question' => $value,
					];
					if (!$this->quiz->getQuestionByQuizLessonQuestion($this->input->post('id_quiz'),$this->input->post('id_lQuiz'),$value)) {
						$this->quiz->insertQuizQuestion($question);
						$count++;
					}
				}
				// UPDATE QUIZ LESSON //
				$oldQuizLesson = $this->quiz->getQuizLessonById($this->input->post('id_lQuiz'));
				if ($oldQuizLesson) {
					$quiz_lesson = [
						'id_lQuiz' => $this->input->post('id_lQuiz'),
						'lQuiz_total_question' => $oldQuizLesson->lQuiz_total_question + $count
					];
					$this->quiz->updateQuizLesson($quiz_lesson);
				}
				$this->message('Yeeayyy!','Anda berhasil menambahkan '.$count.' soal pada ujian ini :)','success');
				redirect('page/quiz_question/'.$this->input->post('id_quiz').'/'.$this->input->post('id_lQuiz'));
			}
		}
		redirect($_SERVER['HTTP_REFERER']);
	}
}

/* End of file QuizCtrl.php */
/* Location: .//Users/admin/Webapp/ujian-online/controllers/QuizCtrl.php */