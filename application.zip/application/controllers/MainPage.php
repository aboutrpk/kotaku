<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class MainPage extends MY_Controller {

	public function index() {
		$totalStudent = 0;
		if ($this->session->userdata('level') != 'guru') {
			$totalStudent = $this->master->getCountStudent()->count;
			$totalResult = $this->assignment->getAllResult();
			$dataAssignment = $this->assignment->getAssignment_simple();
			$dataQuiz = $this->quiz->getQuiz_simple();
		} else {
			foreach ($this->master->getClassByTeacher($this->session->userdata('id_')) as $row => $value) {
				$totalStudent += $this->master->getCountStudentByClass($value->id_class)->count;
			}
			$totalResult = [];
			$dataAssignment = [];
			foreach ($this->assignment->getAssignmentByTeacher_simple($this->session->userdata('id_')) as $r_ => $v_) {
				foreach ($this->assignment->getResultByAssignment($v_->id_assignment) as $__r => $__v) {
					array_push($totalResult, $__v);
				}
				array_push($dataAssignment, $v_);
			}
			$dataQuiz = $this->quiz->getQuizByTeacher_simple($this->session->userdata('id_'));
		}
		// EACH ASSIGNMENT AND QUIZ //
		$totalAssignment = 0;
		$activeAssignment = 0;
		$now = strtotime(date('H:i'));
		foreach ($dataAssignment as $row => $value) {
			$totalAssignment++;
			if (date('Y-m-d') >= substr($value->assignment_start, 0,10) && date('Y-m-d') <= substr($value->assignment_end, 0,10)) {
				$assignmentEnd = strtotime(substr($value->assignment_end, 11,5));
				if ($now < $assignmentEnd) {
					$activeAssignment++;
				}
			}
		}
		foreach ($dataQuiz as $row => $value) {
			$totalAssignment++;
			if (date('Y-m-d') >= substr($value->quiz_start, 0,10) && date('Y-m-d') <= substr($value->quiz_end, 0,10)) {
				$quizEnd = strtotime(substr($value->quiz_end, 11,5));
				if ($now < $quizEnd) {
					$activeAssignment++;
				}
			}
		}
		// END //
		$totalGraduated = 0;
		foreach ($totalResult as $row => $value) {
			if ($value->result_status == 'lulus') {
				$totalGraduated++;
			}
		}
		$this->parseData['totalResult'] = count($totalResult);
		$this->parseData['totalGraduated'] = $totalGraduated;
		$this->parseData['activeAssignment'] = $activeAssignment;
		$this->parseData['totalAssignment'] = $totalAssignment;
		$this->parseData['totalStudent'] = $totalStudent;
		// END //
		if ($this->session->userdata('level') == 'guru') {
			$dataClass = $this->master->getClassByTeacher($this->session->userdata('id_'));
		} else {
			$dataClass = $this->master->getAllClass();
		}
		$this->parseData['dataClass'] = $dataClass;
		$this->parseData['content'] = 'content/dashboard';
		$this->parseData['title'] = 'Home ';
		$this->load->view('MainView',$this->parseData);
	}
	public function users() {
		$this->parseData['dataUsers'] = $this->master->getAllUser();
		$this->parseData['content'] = 'content/master/users';
		$this->parseData['title'] = 'Data Pengguna ';
		$this->load->view('MainView',$this->parseData);
	}
	public function lessons() {
		$this->parseData['dataLessons'] = $this->master->getAllLesson();
		$this->parseData['content'] = 'content/master/lessons';
		$this->parseData['title'] = 'Data Pelajaran ';
		$this->load->view('MainView',$this->parseData);
	}
	public function classes() {
		$this->parseData['dataClasses'] = $this->master->getAllClass();
		$this->parseData['content'] = 'content/master/classes';
		$this->parseData['title'] = 'Data Kelas ';
		$this->load->view('MainView',$this->parseData);
	}

	public function university() {
		$this->parseData['dataUniversity'] = $this->master->getAllUniversity();
		$this->parseData['content'] = 'content/master/university';
		$this->parseData['title'] = 'Data Universitas ';
		$this->load->view('MainView', $this->parseData);
	}

	public function department($university = null) {
		$university = ($university == 'null' ? null : $university);
		$dataDepartment = $this->master->getAllDepartment($university);
		foreach ($dataDepartment as $row => $value) {
			$dataDepartment[$row]->department_pg = $this->GEN_PASSING_GRADE($value->department_pg);
		}
		// SEND TO SESSION //
		if ($dataDepartment) {
			$SESS_ = [ 'DEPARTMENT_DATA_EXPORT' => $dataDepartment ];
			$this->session->set_userdata($SESS_);
		}
		// END //
		$this->parseData['dataUniversity'] = $this->master->getAllUniversity();
		$this->parseData['mclass'] = $this->master->getAllUniversity();
		$this->parseData['cls'] = $university;
		$this->parseData['dataDepartment'] = $dataDepartment; 
		$this->parseData['content'] = 'content/master/department';
		$this->parseData['title'] = 'Data Jurusan';
		$this->load->view('MainView', $this->parseData);
	}

	public function department_add()
	{
		$dataUniversity = $this->master->getAllUniversity();
		foreach ($dataUniversity as $row => $value) {
			if (count($this->master->getDepartmentByUniversity($value->id_university)) >= 20) {
				unset($dataUniversity[$row]);
			}
		}
		$this->parseData['dataUniversity'] = $dataUniversity;
		$this->parseData['content'] = 'content/master/department_add';
		$this->parseData['title'] = 'Tambah Jurusan ';
		$this->load->view('MainView', $this->parseData);
	}
	
	public function department_edit($id_department = null)
	{
		if (!$id_department) {
			redirect('page/department');
		}
		$dataDepartment = $this->master->getDepartmentById($id_department);
		if (!$dataDepartment) {
			redirect('page/department');
		}
		$dataUniversity = $this->master->getAllUniversity();
		foreach($dataUniversity as $row => $value) {
			if (count($this->master->getDepartmentByUniversity($value->id_university)) >= 20) {
				unset($dataUniversity[$row]);
			}
		}
		$this->parseData['dataUniversity'] = $dataUniversity;
		$this->parseData['dataDepartment'] = $dataDepartment;
		$this->parseData['content'] = 'content/master/department_edit';
		$this->parseData['title'] = 'Ubah Jurusan ';
		$this->load->view('MainView', $this->parseData);
	}

	public function teachers() {
		$dataTeachers = $this->master->getAllTeacher();
		foreach ($dataTeachers as $row => $value) {
			$dataTeachers[$row]->classes = $this->master->getClassByTeacher($value->id_teacher);
			$dataTeachers[$row]->lessons = $this->master->getLessonByTeacher($value->id_teacher);
		}
		$this->parseData['dataTeachers'] = $dataTeachers;
		$this->parseData['content'] = 'content/master/teachers';
		$this->parseData['title'] = 'Data Guru ';
		$this->load->view('MainView',$this->parseData);
	}
	public function teacher_add() {
		$this->parseData['dataClasses'] = $this->master->getAllClass();
		$this->parseData['dataLessons'] = $this->master->getAllLesson();
		$this->parseData['content'] = 'content/master/teacher_add';
		$this->parseData['title'] = 'Tambah Guru ';
		$this->load->view('MainView',$this->parseData);
	}
	public function teacher_edit($id_teacher = NULL) {
		if (!$id_teacher) {
			redirect('page/teachers');
		}
		$dataTeacher = $this->master->getTeacherById($id_teacher);
		if (!$dataTeacher) {
			redirect('page/teachers');
		}
		$dataTeacher->classes = $this->master->getClassByTeacher($id_teacher);
		$dataTeacher->lessons = $this->master->getLessonByTeacher($id_teacher);
		$this->parseData['dataTeacher'] = $dataTeacher;
		$this->parseData['dataClasses'] = $this->master->getAllClass();
		$this->parseData['dataLessons'] = $this->master->getAllLesson();
		$this->parseData['content'] = 'content/master/teacher_edit';
		$this->parseData['title'] = 'Ubah Guru ';
		$this->load->view('MainView',$this->parseData);
	}
	public function students($class = null) {
		if ($class == 'null') {
			$class = null;
		}
		if ($this->session->userdata('level') == 'admin' OR $this->session->userdata('level') == 'staff') {
			$dataStudent = [];
			foreach ($this->master->getAllStudent($class) as $row => $value) {
				if ($value->id_class != '') {
					array_push($dataStudent, $value);
				}
			}
		} else {
			$dataStudent = [];
			foreach ($this->master->getClassByTeacher($this->session->userdata('id_')) as $row => $value) {
				foreach ($this->master->getStudentByClass($value->id_class) as $r => $v) {
					array_push($dataStudent, $v);
				}
			}	
		}
		// UNIVERSITY //
		foreach ($dataStudent as $row => $value) {
			$dataStudent[$row]->university = $this->master->getUniversityByStudent_FULLJOIN($value->id_student);
		}
		// SEND TO SESSION //
		if ($dataStudent) {
			$SESS_ = [
				'STUDENT_DATA_EXPORT' => $dataStudent,
				'CLASS_DATA_EXPORT' => $class
			];
			$this->session->set_userdata($SESS_);
		}
		// END //
		$this->parseData['mclass'] = $this->master->getAllClass();
		$this->parseData['cls'] = $class;
		$this->parseData['dataStudents'] = $dataStudent;
		$this->parseData['content'] = 'content/master/students';
		$this->parseData['title'] = 'Data Siswa ';
		$this->load->view('MainView',$this->parseData);
	}
	public function ExportStudent() {
		$DataStudent = $this->session->userdata('STUDENT_DATA_EXPORT');
		$class = $this->session->userdata('CLASS_DATA_EXPORT');
		$DataClass = 'Semua Kelas';
		if ($class != null) {
			$class_tmp = $this->master->getClassById($class);
			if ($class_tmp) {
				$DataClass = $class_tmp->class_name;
			}
		}
		// UNIVERSITY //
		foreach ($DataStudent as $row => $value) {
			$DataStudent[$row]->university = $this->master->getUniversityByStudent_FULLJOIN($value->id_student);
		}
		// END //
		if ($DataStudent AND $DataClass) {
			$Data = [
				'DataStudent' => $DataStudent,
				'DataClass' => $DataClass
			];
			$this->load->view('content/report/export_student',$Data);
		} else {
			redirect('page/students');
		}
	}
	
	public function student_add() {
		if ($this->session->userdata('level') == 'guru') {
			$dataClasses = $this->master->getClassByTeacher($this->session->userdata('id_'));
		} else {
			$dataClasses = $this->master->getAllClass();
			$universitas=$this->master->get_cb_university();
			$jurusan=$this->master->get_cb_department();

			$data = array(
				'provinsi' => $this->master->get_cb_university(),
				'kota' => $this->master->get_cb_department(),
				'provinsi_selected' => '',
				'kota_selected' => '',
			);
			//$this->load->view('content/master/student_add', $data);
		
		}
		// foreach ($dataClasses as $row => $value) {
		// 	if (count($this->master->getStudentByClass($value->id_class)) >= 20) {
		// 		unset($dataClasses[$row]);
		// 	}
		// }
		$this->parseData['dataUniversity'] = $this->master->getAllUniversity();
		$this->parseData['dataClasses'] = $dataClasses;
		$this->parseData['propinsi'] = $universitas;
		$this->parseData['kota'] = $jurusan;
		$this->parseData['content'] = 'content/master/student_add';
		$this->parseData['title'] = 'Tambah Siswa ';
		$this->load->view('MainView',$this->parseData);
	}
	public function student_edit($id_student = NULL) {
		if (!$id_student) {
			redirect('page/students');
		}
		$dataStudent = $this->master->getStudentById($id_student);
		if (!$dataStudent) {
			redirect('page/students');
		}
		if ($this->session->userdata('level') == 'guru') {
			$dataClasses = $this->master->getClassByTeacher($this->session->userdata('id_'));
		} else {
			$dataClasses = $this->master->getAllClass();
		}
		// foreach ($dataClasses as $row => $value) {
		// 	if (count($this->master->getStudentByClass($value->id_class)) >= 20) {
		// 		unset($dataClasses[$row]);
		// 	}
		// }
		$dataStudent->class = $this->master->getClassById($dataStudent->id_class);
		$dataStudent->university = $this->master->getUniversityByStudent($id_student);
		$this->parseData['dataUniversity'] = $this->master->getAllUniversity();
		$this->parseData['dataDepartment'] = $this->master->getAllDepartment();
		$this->parseData['dataClasses'] = $dataClasses;
		$this->parseData['dataStudent'] = $dataStudent;
		$this->parseData['content'] = 'content/master/student_edit';
		$this->parseData['title'] = 'Ubah Siswa ';
		$this->load->view('MainView',$this->parseData);
	}
	public function create() {
		if ($this->session->userdata('level') == 'guru') {
			$dataClasses = $this->master->getClassByTeacher($this->session->userdata('id_'));
			$dataLessons = $this->master->getLessonByTeacher($this->session->userdata('id_'));
		} else {
			$dataClasses = $this->master->getAllClass();
			$dataLessons = $this->master->getAllLesson();
		}
		$this->parseData['dataLessons'] = $dataLessons;
		$this->parseData['dataClasses'] = $dataClasses;
		$this->parseData['content'] = 'content/assignment/create';
		$this->parseData['title'] = 'Buat Ujian ';
		$this->load->view('MainView',$this->parseData);
	}
	public function edit($id_assignment = NULL) {
		if (!$id_assignment) {
			redirect('page/assignments');
		}
		$dataAssignment = $this->assignment->getAssignmentById($id_assignment);
		if (!$dataAssignment) {
			redirect('page/assignments');
		}
		$dataAssignment->classes = $this->assignment->getClassByAssignment($id_assignment);
		if ($this->session->userdata('level') == 'guru') {
			$dataClasses = $this->master->getClassByTeacher($this->session->userdata('id_'));
			$dataLessons = $this->master->getLessonByTeacher($this->session->userdata('id_'));
		} else {
			$dataClasses = $this->master->getAllClass();
			$dataLessons = $this->master->getAllLesson();
		}
		$this->parseData['dataAssignment'] = $dataAssignment;
		$this->parseData['dataLessons'] = $dataLessons;
		$this->parseData['dataClasses'] = $dataClasses;
		$this->parseData['content'] = 'content/assignment/edit';
		$this->parseData['title'] = 'Ubah Ujian ';
		$this->load->view('MainView',$this->parseData);
	}
	public function list_question($id_assignment = NULL) {
		if (!$id_assignment) {
			redirect('page/assignments');
		}
		$dataAssignment = $this->assignment->getAssignmentById($id_assignment);
		if (!$dataAssignment) {
			redirect('page/assignments');
		}
		$dataAssignment->questions = $this->assignment->getQuestionByAssignment($id_assignment);
		foreach ($dataAssignment->questions as $row => $value) {
			$dataAssignment->questions[$row]->totalAnswer = count($this->assignment->getOptionByQuestion($value->id_question));
		}
		$this->parseData['dataAssignment'] = $dataAssignment;
		$this->parseData['content'] = 'content/assignment/list_question';
		$this->parseData['title'] = 'List Soal ';
		$this->load->view('MainView',$this->parseData);
	}
	public function reuse_question($id_assignment = NULL) {
		if (!$id_assignment) {
			redirect('page/assignments');
		}
		$dataAssignment = $this->assignment->getAssignmentById($id_assignment);
		if (!$dataAssignment) {
			redirect('page/assignments');
		}
		if ($dataAssignment->id_ == $this->session->userdata('id_')) {
			$dataQuestion = [];
			foreach ($this->assignment->getAllQuestion($dataAssignment->id_lesson) as $row => $value) {
				$assignmentQuestion = $this->assignment->getIdAssignmentByQuestion($value->id_question);
				$value->id_assignment = 'empty';
				if ($assignmentQuestion) {
					//sementaraoff $Assignment = $this->assignment->getAssignmentById($assignmentQuestion->id_assignment);
					//sementaraoff if ($Assignment) {
						//sementaraoff if ($Assignment->id_ == $this->session->userdata('id_')) {
							$value->id_assignment = $this->assignment->getIdAssignmentByQuestion($value->id_question)->id_assignment;
						//sementaraoff }
					//sementaraoff }
				}
				$value->totalAnswer = count($this->assignment->getAnswerByQuestion($value->id_question));
				array_push($dataQuestion, $value);

				// if ($value->id_lesson == $dataAssignment->id_lesson) {
				// 	$assignmentQuestion = $this->assignment->getIdAssignmentByQuestion($value->id_question);
				// 	if ($assignmentQuestion) {
				// 		$Assignment = $this->assignment->getAssignmentById($assignmentQuestion->id_assignment);
				// 		if ($Assignment) {
				// 			if ($Assignment->id_ == $this->session->userdata('id_')) {
				// 				$value->totalAnswer = count($this->assignment->getAnswerByQuestion($value->id_question));
				// 				$value->id_assignment = $this->assignment->getIdAssignmentByQuestion($value->id_question)->id_assignment;
				// 				array_push($dataQuestion, $value);
				// 			}
				// 		}
				// 	}
				// }
			}
			$dataAssignment->assignment_question = $this->assignment->getAssignmentQuestionByAssignment($id_assignment);
			// NOW WE GOT DATA QUESTION //
			$this->parseData['dataAssignment'] = $dataAssignment;
			$this->parseData['dataQuestion'] = $dataQuestion;
			$this->parseData['content'] = 'content/assignment/reuse_question';
			$this->parseData['title'] = 'Gunakan Soal Lain ';
			$this->load->view('MainView',$this->parseData);
		} else {
			redirect('page/assignments');
		}
	}
	public function update_question($id_assignment = NULL, $id_question = NULL) {
		if (!$id_question OR !$id_assignment) {
			redirect('page/assignments');
		}
		$dataQuestion = $this->assignment->getQuestionById($id_question);
		$dataAssignment = $this->assignment->getAssignmentById($id_assignment);
		if (!$dataQuestion OR !$dataAssignment) {
			redirect('page/assignments');
		}
		$dataQuestion->options = $this->assignment->getOptionByQuestion($id_question);
		// echo "<pre>";
		foreach ($dataQuestion->options as $row => $value) {
			if ($this->assignment->checkAnswerTrue($value->id_option,$id_question)) {
				$dataQuestion->trueAnswer = $row;
			}
		}
		// print_r($dataQuestion);
		// die;
		$this->parseData['dataQuestion'] = $dataQuestion;
		$this->parseData['dataAssignment'] = $dataAssignment;
		$this->parseData['content'] = 'content/assignment/update_question';
		$this->parseData['title'] = 'Detail Soal ';
		$this->load->view('MainView',$this->parseData);
	}
	public function delete_option($id_assignment = NULL, $id_question = NULL, $id_option = NULL) {
		if (!$id_question OR !$id_assignment OR !$id_option) {
			redirect('page/assignments');
		}
		$this->assignment->deleteOptionById($id_option);
		$this->message('Yeeay!','Jawaban berhasil dihapus','success');
		redirect('page/update_question/'.$id_assignment.'/'.$id_question);
	}
	public function create_question($id_assignment = NULL) {
		if (!$id_assignment) {
			redirect('page/assignments');
		}
		$dataAssignment = $this->assignment->getAssignmentById($id_assignment);
		if (!$dataAssignment) {
			redirect('page/assignments');
		}
		$this->parseData['dataAssignment'] = $dataAssignment;
		$this->parseData['content'] = 'content/assignment/create_question';
		$this->parseData['title'] = 'Buat Soal ';
		$this->load->view('MainView',$this->parseData);
	}
	public function detail_question($id_assignment = NULL, $id_question = NULL,$bank = NULL) {
		if (!$id_question OR !$id_assignment) {
			redirect('page/assignments');
		}
		$dataQuestion = $this->assignment->getQuestionById($id_question);
		if (!$dataQuestion) { redirect('page/assignments'); }
		$dataAssignment = [];
		if ($id_assignment != 'empty') {
			$dataAssignment = $this->assignment->getAssignmentById($id_assignment);
			if (!$dataAssignment) {
				redirect('page/assignments');
			}
		}
		$dataQuestion->options = $this->assignment->getOptionByQuestion($id_question);
		$this->parseData['dataQuestion'] = $dataQuestion;
		$this->parseData['dataAssignment'] = $dataAssignment;
		$this->parseData['assignmentId'] = $id_assignment;
		$this->parseData['bank'] = $bank;
		$this->parseData['content'] = 'content/assignment/detail_question';
		$this->parseData['title'] = 'Detail Soal ';
		$this->load->view('MainView',$this->parseData);
	}
	public function detail_question_bank($id_assignment = null, $id_question = null) {
		$dataQuestion = $this->assignment->getQuestionById($id_question);
		if (!$dataQuestion) { redirect('page/assignments'); }
		$mainPath = base_url('assets/images/questions/');
		$dataAssignment = null;
		if ($id_assignment != 'empty') {
			$dataAssignment = $this->assignment->getAssignmentById($id_assignment);
			if (!$dataAssignment) {
				redirect('page/assignments');
			}
			$mainPath = base_url('assets/images/assignmetns/'.$dataAssignment->assignment_path.'/');
		}
		$dataQuestion->options = $this->assignment->getOptionByQuestion($id_question);
		$this->parseData['mainPath'] = $mainPath;
		$this->parseData['dataQuestion'] = $dataQuestion;
		$this->parseData['dataAssignment'] = $dataAssignment;
		$this->parseData['assignmentId'] = $id_assignment;
		$this->parseData['content'] = 'content/assignment/detail_question_bank';
		$this->parseData['title'] = 'Detail Soal ';
		$this->load->view('MainView',$this->parseData);
	}
	public function assignments() {
		$dataAssignment = $this->assignment->getAllAssignment();
		foreach ($dataAssignment as $row => $value) {
			$dataAssignment[$row]->totalQuestion = count($this->assignment->getQuestionByAssignment($value->id_assignment));
		}
		$this->parseData['dataAssignment'] = $dataAssignment;
		$this->parseData['content'] = 'content/assignment/list';
		$this->parseData['title'] = 'List Ujian ';
		$this->load->view('MainView',$this->parseData);
	}
	public function bank($id_lesson = null) {
		$id_lesson = ($id_lesson == 'null' ? null : $id_lesson);
		$dataQuestion = [];
		$dataLessons = [];
		$tempAssignment = [];
		if ($this->session->userdata('level') == 'admin') {
			$dataLessons = $this->master->getAllLesson();
			$tempAssignment = $this->assignment->getAllQuestion($id_lesson);
		} elseif($this->session->userdata('level') == 'guru') {
			$dataLessons = $this->master->getLessonByTeacher($this->session->userdata('id_'));
			if ($id_lesson) {
				$goodToGo = false;
				foreach ($dataLessons as $row => $value) {
					if ($id_lesson == $value->id_lesson) {
						$goodToGo = true;
					}
				}
				if ($goodToGo) {
					$tempAssignment = $this->assignment->getAllQuestion($id_lesson);
				}
			} else {
				if (isset($dataLessons[0]->id_lesson)) {
					$tempAssignment = $this->assignment->getAllQuestion($dataLessons[0]->id_lesson);
				}
			}
		}
		// DATA ASSIGNMENT //
		foreach ($tempAssignment as $row => $value) {
			$assignmentQuestion = $this->assignment->getIdAssignmentByQuestion($value->id_question);
			$value->id_assignment = 'empty';
			if ($assignmentQuestion) {
				//sementaraoff $Assignment = $this->assignment->getAssignmentById($assignmentQuestion->id_assignment);
				//sementaraoff if ($Assignment) {
					//sementaraoff if ($Assignment->id_ == $this->session->userdata('id_')) {
						$value->id_assignment = $this->assignment->getIdAssignmentByQuestion($value->id_question)->id_assignment;
					//sementaraoff }
				//sementaraoff }
			}
			$value->totalAnswer = count($this->assignment->getAnswerByQuestion($value->id_question));
			array_push($dataQuestion, $value);
		}
		// SEND TO SESSION //
		$sess_ = [
			'LANCER_BANK_QUESTION' => $dataQuestion,
			'LABCER_BANK_LESSON' => $id_lesson,
		];
		$this->session->set_userdata($sess_);
		// PARSING //
		$this->parseData['lessonId'] = $id_lesson;
		$this->parseData['dataLessons'] = $dataLessons;
		$this->parseData['dataQuestion'] = $dataQuestion;
		$this->parseData['content'] = 'content/assignment/bank';
		$this->parseData['title'] = 'Bank Soal ';
		$this->load->view('MainView',$this->parseData);
	}
	public function bank_excel() {
		$LANCER_BANK_QUESTION = $this->session->userdata('LANCER_BANK_QUESTION');
		$LANCER_BANK_LESSON = $this->session->userdata('LABCER_BANK_LESSON');
		if ($LANCER_BANK_QUESTION) {
			foreach ($LANCER_BANK_QUESTION as $row => $value) {
				$LANCER_BANK_QUESTION[$row]->answers = $this->assignment->getAnswerByQuestion($value->id_question);
			}
			$lesson_name = '';
			$dataLesson = $this->assignment->getLessonById($LANCER_BANK_LESSON);
			if ($dataLesson) {
				$lesson_name = $dataLesson->lesson_name;
			}
			$data = [
				'dataQuestion' => $LANCER_BANK_QUESTION,
				'lesson_name' => $lesson_name
			];
			$this->load->view('content/assignment/bank_excel', $data);
		} else {
			redirect('page/bank');
		}
	}
	public function results() {
		if ($this->input->post()) {
			$dataAssignments = [];
			$forAssignment = [];
			foreach ($this->assignment->getAssignmentByClassNew($this->input->post('id_class')) as $row => $value) {
				if ($forAssignment) {
					$val = true;
					foreach ($forAssignment as $_rr => $_vv) {
						if ($_vv->id_assignment == $value->id_assignment) {
							$val = false;
						}
					}
					if ($val) {
						array_push($forAssignment, $value);
					}
				} else {
					array_push($forAssignment, $value);
				}
			}
			// NEW LOGIC //
			foreach ($forAssignment as $row => $value) {
				$assignment = $this->assignment->getAssignmentByTypeLessonAndId($this->input->post('assignment_type'),$this->input->post('id_lesson'),$value->id_assignment);
				if ($assignment) {
					array_push($dataAssignments,$assignment);
				}
			}
			// END //
			foreach ($dataAssignments as $r => $v) {
				$students = $this->master->getStudentByClass($this->input->post('id_class'));
				if ($students) {
					foreach ($students as $_r => $_v) {
						$students[$_r]->result = $this->assignment->getResultByStudentAndAssignment($_v->id_student,$v->id_assignment);
						$students[$_r]->university = $this->GEN_UNIVERSITY($_v->id_class,$_v->id_student);
					}
					$dataAssignments[$r]->students = $students;
				} else {
					unset($dataAssignments[$r]);
				}
			}
			// DATA FILTERING AUTH //
			$clearAssignment = [];
			foreach ($dataAssignments as $rAssignment => $vAssignment) {
				if ($this->session->userdata('level') != 'admin') {
					if ($vAssignment->id_ == $this->session->userdata('id_')) {
						array_push($clearAssignment, $vAssignment);
					}
				} else {
					array_push($clearAssignment, $vAssignment);
				}
			}
			// END //
			if ($dataAssignments) {
				$this->parseData['dataAssignments'] = $clearAssignment;
				$this->parseData['post'] = $this->input->post();
				$this->parseData['dataClass'] = $this->master->getClassById($this->input->post('id_class'));
				$this->parseData['dataLesson'] = $this->assignment->getLessonById($this->input->post('id_lesson'));
			} else {
				$this->message('Woopsss!','Tidak ditemukan laporan hasil ujian pada data ini','error');
				redirect('page/results');
			}
		}
		$dataLessons = $this->assignment->getLessonInAssignment();
		foreach ($dataLessons as $row => $value) {
			$dataLessons[$row]->lesson_name = $this->assignment->getLessonById($value->id_lesson)->lesson_name;
		}
		$this->parseData['dataLessons'] = $dataLessons;
		$this->parseData['content'] = 'content/report/result';
		$this->parseData['title'] = 'Laporan Hasil Ujian ';
		$this->load->view('MainView',$this->parseData);
	}
	public function result_pdf($id_assignment = NULL,$id_class = NULL) {
		if (!$id_assignment OR !$id_class) {
			redirect('page/results');
		}
		$dataAssignment = $this->assignment->getAssignmentById($id_assignment);
		$dataClass = $this->master->getClassById($id_class);
		if (!$dataAssignment OR !$dataClass) {
			redirect('page/results');
		}
		if ($this->session->userdata('level') == 'guru') {
			if ($dataAssignment->id_ != $this->session->userdata('id_')) {
				redirect('page/results');
			}
		}
		$students = $this->master->getStudentByClass($id_class);
		foreach ($students as $_r => $_v) {
			$students[$_r]->result = $this->assignment->getResultByStudentAndAssignment($_v->id_student,$id_assignment);
			$students[$_r]->university = $this->GEN_UNIVERSITY($_v->id_class,$_v->id_student);
		}
		$dataAssignment->students = $students;
		$dataAssignment->totalQuestion = count($this->assignment->getQuestionByAssignment($id_assignment));
		$this->result['dataAssignment'] = $dataAssignment;
		$this->result['dataClass'] = $dataClass;
		$this->result['dataLesson'] = $this->assignment->getLessonById($dataAssignment->id_lesson);
		$html = $this->load->view('content/report/result-pdf', $this->result, TRUE);
        $this->load->library('pdf');
        $this->pdf->pdf->WriteHTML($html);
        $this->pdf->pdf->Output('Hasil Ujian '.$dataAssignment->lesson_name.' - '.$dataAssignment->assignment_type.' || Kelas : '.$dataClass->class_name.'.pdf','I');
	}
	public function result_excel($id_assignment = NULL,$id_class = NULL) {
		if (!$id_assignment OR !$id_class) {
			redirect('page/results');
		}
		$dataAssignment = $this->assignment->getAssignmentById($id_assignment);
		$dataClass = $this->master->getClassById($id_class);
		if (!$dataAssignment OR !$dataClass) {
			redirect('page/results');
		}
		if ($this->session->userdata('level') == 'guru') {
			if ($dataAssignment->id_ != $this->session->userdata('id_')) {
				redirect('page/results');
			}
		}
		$students = $this->master->getStudentByClass($id_class);
		foreach ($students as $_r => $_v) {
			$students[$_r]->result = $this->assignment->getResultByStudentAndAssignment($_v->id_student,$id_assignment);
			$students[$_r]->university = $this->GEN_UNIVERSITY($_v->id_class,$_v->id_student);
		}
		$dataAssignment->students = $students;
		$dataAssignment->totalQuestion = count($this->assignment->getQuestionByAssignment($id_assignment));
		$this->result['dataAssignment'] = $dataAssignment;
		$this->result['dataClass'] = $dataClass;
		$this->result['dataLesson'] = $this->assignment->getLessonById($dataAssignment->id_lesson);
		$this->load->view('content/report/result-excel', $this->result);
	}
	public function analytics() {
		if ($this->input->post()) {
			$dataAssignments = [];
			foreach ($this->assignment->getAssignmentByClass($this->input->post('id_class')) as $row => $value) {
				$assignment = $this->assignment->getAssignmentByTypeLessonAndId($this->input->post('assignment_type'),$this->input->post('id_lesson'),$value->id_assignment);
				if ($assignment) {
					array_push($dataAssignments,$assignment);
				}
			}
			$students = $this->master->getStudentByClass($this->input->post('id_class'));
			foreach ($dataAssignments as $r => $v) {
				$questions = $this->assignment->getQuestionByAssignment($v->id_assignment);
				foreach ($questions as $rQuestion => $vQuestion) {
					$notYet = 0;
					$true = 0;
					$false = 0;
					$empty = 0;
					foreach ($students as $rStudent => $vStudent) {
						$analytics = $this->assignment->getAnalyticsByStudentAndAssignment($vStudent->id_student,$v->id_assignment);
						if ($analytics) {
							foreach($analytics as $rAnalytics => $vAnalytic) {
								if ($vAnalytic->id_question == $vQuestion->id_question) {
									if ($vAnalytic->analytics_status == 'true') {
										$true++;
									} elseif($vAnalytic->analytics_status == 'false') {
										$false++;
									} elseif($vAnalytic->analytics_status == 'empty') {
										$empty++;
									}
								}
							}
						} else {
							$notYet++;
						}
					}
					$questions[$rQuestion]->notYet = $notYet;
					$questions[$rQuestion]->true = $true;
					$questions[$rQuestion]->false = $false;
					$questions[$rQuestion]->empty = $empty;
				}
				$dataAssignments[$r]->questions = $questions;
			}
			// DATA FILTERING AUTH //
			$clearAssignment = [];
			foreach ($dataAssignments as $rAssignment => $vAssignment) {
				if ($this->session->userdata('level') != 'admin') {
					if ($vAssignment->id_ == $this->session->userdata('id_')) {
						array_push($clearAssignment, $vAssignment);
					}
				} else {
					array_push($clearAssignment, $vAssignment);
				}
			}
			// END //
			if ($dataAssignments) {
				$this->parseData['dataAssignments'] = $clearAssignment;
				$this->parseData['post'] = $this->input->post();
				$this->parseData['dataClass'] = $this->master->getClassById($this->input->post('id_class'));
				$this->parseData['dataLesson'] = $this->assignment->getLessonById($this->input->post('id_lesson'));
			} else {
				$this->message('Woopsss!','Tidak ditemukan laporan hasil ujian pada data ini','error');
				redirect('page/results');
			}
		}
		$dataLessons = $this->assignment->getLessonInAssignment();
		foreach ($dataLessons as $row => $value) {
			$dataLessons[$row]->lesson_name = $this->assignment->getLessonById($value->id_lesson)->lesson_name;
		}
		$this->parseData['dataLessons'] = $dataLessons;
		$this->parseData['content'] = 'content/report/analytics';
		$this->parseData['title'] = 'Laporan Analysis Ujian ';
		$this->load->view('MainView',$this->parseData);
	}
	public function analytics_pdf($id_assignment = NULL,$id_class = NULL) {
		if (!$id_assignment OR !$id_class) {
			redirect('page/results');
		}
		$dataAssignment = $this->assignment->getAssignmentById_nohide($id_assignment);
		$dataClass = $this->master->getClassById($id_class);
		if (!$dataAssignment OR !$dataClass) {
			redirect('page/results');
		}
		if ($this->session->userdata('level') == 'guru') {
			if ($dataAssignment->id_ != $this->session->userdata('id_')) {
				redirect('page/results');
			}
		}
		$students = $this->master->getStudentByClass($id_class);
		$questions = $this->assignment->getQuestionByAssignment($id_assignment);
		foreach ($questions as $rQuestion => $vQuestion) {
			$notYet = 0;
			$true = 0;
			$false = 0;
			$empty = 0;
			foreach ($students as $rStudent => $vStudent) {
				$analytics = $this->assignment->getAnalyticsByStudentAndAssignment($vStudent->id_student,$id_assignment);
				if ($analytics) {
					foreach($analytics as $rAnalytics => $vAnalytic) {
						if ($vAnalytic->id_question == $vQuestion->id_question) {
							if ($vAnalytic->analytics_status == 'true') {
								$true++;
							} elseif($vAnalytic->analytics_status == 'false') {
								$false++;
							} elseif($vAnalytic->analytics_status == 'empty') {
								$empty++;
							}
						}
					}
				} else {
					$notYet++;
				}
			}
			$questions[$rQuestion]->notYet = $notYet;
			$questions[$rQuestion]->true = $true;
			$questions[$rQuestion]->false = $false;
			$questions[$rQuestion]->empty = $empty;
		}
		$dataAssignment->questions = $questions;
		$dataAssignment->totalQuestion = count($this->assignment->getQuestionByAssignment($id_assignment));
		$this->result['dataAssignment'] = $dataAssignment;
		$this->result['dataClass'] = $dataClass;
		$this->result['dataLesson'] = $this->assignment->getLessonById($dataAssignment->id_lesson);
		// echo "<pre>";
		// print_r($dataAssignment);
		// die;
		$html = $this->load->view('content/report/analytics-pdf', $this->result, TRUE);
        $this->load->library('pdf');
        $this->pdf->pdf->WriteHTML($html);
        $this->pdf->pdf->Output('Analisa Ujian '.$dataAssignment->lesson_name.' - '.$dataAssignment->assignment_type.' || Kelas : '.$dataClass->class_name.'.pdf','I');
	}
	public function analytics_excel($id_assignment = NULL,$id_class = NULL) {
		if (!$id_assignment OR !$id_class) {
			redirect('page/results');
		}
		$dataAssignment = $this->assignment->getAssignmentById_nohide($id_assignment);
		$dataClass = $this->master->getClassById($id_class);
		if (!$dataAssignment OR !$dataClass) {
			redirect('page/results');
		}
		if ($this->session->userdata('level') == 'guru') {
			if ($dataAssignment->id_ != $this->session->userdata('id_')) {
				redirect('page/results');
			}
		}
		$students = $this->master->getStudentByClass($id_class);
		$questions = $this->assignment->getQuestionByAssignment($id_assignment);
		foreach ($questions as $rQuestion => $vQuestion) {
			$notYet = 0;
			$true = 0;
			$false = 0;
			$empty = 0;
			foreach ($students as $rStudent => $vStudent) {
				$analytics = $this->assignment->getAnalyticsByStudentAndAssignment($vStudent->id_student,$id_assignment);
				if ($analytics) {
					foreach($analytics as $rAnalytics => $vAnalytic) {
						if ($vAnalytic->id_question == $vQuestion->id_question) {
							if ($vAnalytic->analytics_status == 'true') {
								$true++;
							} elseif($vAnalytic->analytics_status == 'false') {
								$false++;
							} elseif($vAnalytic->analytics_status == 'empty') {
								$empty++;
							}
						}
					}
				} else {
					$notYet++;
				}
			}
			$questions[$rQuestion]->notYet = $notYet;
			$questions[$rQuestion]->true = $true;
			$questions[$rQuestion]->false = $false;
			$questions[$rQuestion]->empty = $empty;
		}
		$dataAssignment->questions = $questions;
		$dataAssignment->totalQuestion = count($this->assignment->getQuestionByAssignment($id_assignment));
		$this->result['dataAssignment'] = $dataAssignment;
		$this->result['dataClass'] = $dataClass;
		$this->result['dataLesson'] = $this->assignment->getLessonById($dataAssignment->id_lesson);
		$this->load->view('content/report/analytics-excel', $this->result);
	}

	// ERROR HANDLER //
	public function not_found() {
		echo "Page not found";
	}
	public function logout() {
		$this->auth->deleteToken($this->session->userdata('backToken'));
		$this->session->unset_userdata('backToken');
		$this->message('Logout berhasil!','Silahkan login kembali untuk melanjutkan :)','success');
		redirect('Auth');
	}

	public function coba_pdf() {
		$admin = [
			[
				"nama" => "Sandi Ramadhan",
				"umur" =>  22,
			], [
				"nama" => "Uchiha Sasuke",
				"umur" => 22
			]
		];
		$data = [
			'dataAdmin' => $admin
		];
		$html = $this->load->view('content/contoh_pdf', $data, TRUE);
	    $this->load->library('pdf');
	    $this->pdf->pdf->WriteHTML($html);
	    $this->pdf->pdf->Output();
	}
	public function coba_excel() {
		$admin = [
			[
				"nama" => "Sandi Ramadhan",
				"umur" =>  22,
			], [
				"nama" => "Uchiha Sasuke",
				"umur" => 22
			]
		];
		$data = [
			'dataAdmin' => $admin
		];
		$this->load->view('content/contoh_excel', $data);
	}
	public function reusequestion($id_assignment = NULL,$id_question = NULL) {
		if ($id_assignment AND $id_question) {
			$Data = [
				'id_assignment' => $id_assignment,
				'id_question' => $id_question
			];
			if ($this->assignment->CheckAssignmentQuestionByAssignmentAndQuestion($id_assignment,$id_question)) {
				$this->message('Oopsss!','Soal yang anda pilih sudah berada pada ujian ini','error');
			} else {
				$this->assignment->insertAssignmentQuestion($Data);
				$this->message('Yeeay!','Soal berhasil digunakan kembali','success');
			}
			redirect('page/reuse_question/'.$id_assignment);
		} else {
			redirect('page/assignments');
		}
	}
	public function logs() {
		$this->parseData['dataLog'] = $this->master->getAllLog();
		$this->parseData['content'] = 'content/master/logs';
		$this->parseData['title'] = 'Data Log Aktifitas ';
		$this->load->view('MainView',$this->parseData);
	}


	// EXPORTS //
	public function lessons_export() {
		$data = [ 'dataLessons' => $this->master->getAllLesson() ];
		$this->load->view('content/master/lessons_export', $data);
	}
	public function classes_export() {
		$data = [ 'dataClasses' => $this->master->getAllClass() ];
		$this->load->view('content/master/classes_export', $data);
	}
	public function university_export() {
		$data = [ 'dataUniversity' => $this->master->getAllUniversity() ];
		$this->load->view('content/master/university_export', $data);
	}
	public function department_export() {
		$dataDepartment = $this->session->userdata('DEPARTMENT_DATA_EXPORT');
		if ($dataDepartment) {
			$data = [ 'dataDepartment' => $dataDepartment ];
			$this->load->view('content/master/department_export', $data);
		} else {
			redirect('page/department');
		}
	}
	public function teachers_export() {
		$data = [ 'dataTeacher' => $this->master->getAllTeacher() ];
		$this->load->view('content/master/teachers_export', $data);
	}
	public function users_export() {
		$data = [ 'dataUsers' => $this->master->getAllUser() ];
		$this->load->view('content/master/users_export', $data);
	}
	public function logs_export() {
		$data = [ 'dataLogs' => $this->master->getAllLog() ];
		$this->load->view('content/master/logs_export', $data);
	}

	// NEW //
	public function single_question($id_question = null) {
		$dataQuestion = $this->assignment->getQuestionById($id_question);
		if (!$dataQuestion) { redirect('page'); }
		$dataQuestion->options = $this->assignment->getOptionByQuestion($id_question);
		$dataAssignment = $this->quiz->getIdAssignmentByQuestion($id_question);
		$dataQuestion->imagePath = false;
		if ($dataQuestion->question_type == 'sbmptn') {
			if ($dataQuestion->question_image) {
				$dataQuestion->imagePath = base_url('assets/images/questions');
			}
		} else {
			if ($dataAssignment) {
				$dataQuestion->imagePath = base_url('assets/images/assignments/'.$dataAssignment->assignment_path);
			}
		}
		$this->parseData['dataQuestion'] = $dataQuestion;
		$this->parseData['dataAssignment'] = $dataAssignment;
		$this->parseData['content'] = 'content/quiz/detail_question';
		$this->parseData['title'] = 'Detail Soal ';
		$this->load->view('MainView',$this->parseData);
	}
	public function quiz_category() {
		$this->parseData['dataCategory'] = $this->quiz->getQuizCategory();
		$this->parseData['content'] = 'content/quiz/category';
		$this->parseData['title'] = 'Kategori Ujian ';
		$this->load->view('MainView',$this->parseData);
	}
	public function quiz_title() {
		$this->parseData['dataTitle'] = $this->quiz->getQuizTitle();
		$this->parseData['content'] = 'content/quiz/title';
		$this->parseData['title'] = 'Judul Ujian ';
		$this->load->view('MainView',$this->parseData);
	}
	public function quiz_sbmptn($id_category_quiz = null) {
		$dataQuiz = [];
		if ($this->session->userdata('level') == 'guru') {
			$dataQuiz = $this->quiz->getQuiz($id_category_quiz);
		} else {
			$dataQuiz = $this->quiz->getQuiz($id_category_quiz);
		}
		// VALIDITY //
		foreach ($dataQuiz as $row => $value) {
			$total = $this->quiz->getCountQuestionByQuiz($value->id_quiz)->total;
			$dataQuiz[$row]->totalQuestion = 0;
			if ($total) {
				$dataQuiz[$row]->totalQuestion = $total;
			}
			$dataQuiz[$row]->classes = $this->quiz->getClassByQuiz($value->id_quiz);
		}
		// PARSING //
		$this->parseData['id_category_quiz'] = $id_category_quiz;
		$this->parseData['dataCategory'] = $this->quiz->getQuizCategory();
		$this->parseData['dataTitle'] = $this->quiz->getQuizTitle();
		$this->parseData['dataQuiz'] = $dataQuiz;
		$this->parseData['dataClass'] = $this->quiz->getClassXII();
		$this->parseData['content'] = 'content/quiz/list';
		$this->parseData['title'] = 'List Ujian SBMPTN ';
		$this->load->view('MainView',$this->parseData);
	}
	public function quiz_lesson($id_quiz = null) {
		$dataQuiz = $this->quiz->getQuizById($id_quiz);
		if (!$dataQuiz) {
			redirect('page/quiz_sbmptn');
		}
		$lessons = $this->quiz->getLessonByQuiz($id_quiz);
		foreach ($lessons as $row => $value) {
			$lessons[$row]->lQuiz_value_true_formatted = $this->GEN_PASSING_GRADE($value->lQuiz_value_true);
			$lessons[$row]->lQuiz_value_false_formatted = $this->GEN_PASSING_GRADE($value->lQuiz_value_false);
		}
		$dataQuiz->lessons = $lessons;
		$this->parseData['dataQuiz'] = $dataQuiz;
		$this->parseData['dataLesson'] = $this->master->getAllLesson();
		$this->parseData['content'] = 'content/quiz/lesson';
		$this->parseData['title'] = 'Tambah Pelajaran Ujian ';
		$this->load->view('MainView',$this->parseData);
	}
	public function quiz_question($id_quiz = null, $id_lQuiz = null) {
		$dataQuiz = $this->quiz->getQuizById($id_quiz);
		$dataLessonQuiz = $this->quiz->getQuizLessonById($id_lQuiz);
		if (!$dataQuiz OR !$dataLessonQuiz) {
			redirect('page/quiz_sbmptn');
		}
		$dataQuestion = $this->quiz->getQuestionByQuizLesson($id_quiz,$id_lQuiz);
		foreach ($dataQuestion as $row => $value) {
			$dataQuestion[$row]->totalOption = count($this->assignment->getOptionByQuestion($value->id_question));
		}
		$this->parseData['dataQuiz'] = $dataQuiz;
		$this->parseData['dataLessonQuiz'] = $dataLessonQuiz;
		$this->parseData['dataQuestion'] = $dataQuestion;
		$this->parseData['content'] = 'content/quiz/question';
		$this->parseData['title'] = 'Tambah Pertanyaan Ujian ';
		$this->load->view('MainView',$this->parseData);
	}
	public function quiz_question_add($id_quiz = null, $id_lQuiz = null) {
		$dataQuiz = $this->quiz->getQuizById($id_quiz);
		$dataLessonQuiz = $this->quiz->getQuizLessonById($id_lQuiz);
		if (!$dataQuiz OR !$dataLessonQuiz) {
			redirect('page/quiz_sbmptn');
		}
		$this->parseData['dataQuiz'] = $dataQuiz;
		$this->parseData['dataLessonQuiz'] = $dataLessonQuiz;
		$this->parseData['content'] = 'content/quiz/question_create';
		$this->parseData['title'] = 'Buat Pertanyaan ';
		$this->load->view('MainView',$this->parseData);
	}
	public function use_question_quiz($id_quiz = null, $id_lQuiz = null) {
		$dataQuiz = $this->quiz->getQuizById($id_quiz);
		$dataLessonQuiz = $this->quiz->getQuizLessonById($id_lQuiz);
		if (!$dataQuiz OR !$dataLessonQuiz) {
			redirect('page/quiz_sbmptn');
		}
		$dataQuestion = $this->quiz->getQuestionByLesson($dataLessonQuiz->id_lesson);
		foreach ($dataQuestion as $row => $value) {
			$dataQuestion[$row]->totalOption = count($this->assignment->getOptionByQuestion($value->id_question));
		}
		$this->parseData['dataQuestion'] = $dataQuestion;
		$this->parseData['usedQuestion'] = $this->quiz->getQuestionByQuizLesson($id_quiz,$id_lQuiz);
		$this->parseData['dataQuiz'] = $dataQuiz;
		$this->parseData['dataLessonQuiz'] = $dataLessonQuiz;
		$this->parseData['content'] = 'content/quiz/question_list';
		$this->parseData['title'] = 'Gunakan Soal Lain ';
		$this->load->view('MainView',$this->parseData);
	}
	public function quiz_question_edit($id_quiz = null, $id_lQuiz = null, $id_qQuiz = null) {
		$dataQuiz = $this->quiz->getQuizById($id_quiz);
		$dataLessonQuiz = $this->quiz->getQuizLessonById($id_lQuiz);
		$dataQuestion = $this->quiz->getQuizQuestionById($id_qQuiz);
		if (!$dataQuiz OR !$dataLessonQuiz OR !$dataQuestion) {
			redirect('page/quiz_sbmptn');
		}
		$options = $this->assignment->getOptionByQuestion($dataQuestion->id_question);
		$dataQuestion->trueAnswer = null;
		foreach ($options as $row => $value) {
			if ($value->option_true == 1) {
				$dataQuestion->trueAnswer = $row;
			}
		}
		$dataQuestion->options = $options;
		// $this->debug($dataQuiz);
		// $this->debug($dataLessonQuiz);
		// $this->debug($dataQuestion,true);
		$this->parseData['dataQuiz'] = $dataQuiz;
		$this->parseData['dataLessonQuiz'] = $dataLessonQuiz;
		$this->parseData['dataQuestion'] = $dataQuestion;
		$this->parseData['content'] = 'content/quiz/question_edit';
		$this->parseData['title'] = 'Ubah Pertanyaan ';
		$this->load->view('MainView',$this->parseData);
	}
	public function results_sbmptn() {
		$class_selected = ($this->input->post('id_class') ? $this->input->post('id_class') : null);
		$category_selected = ($this->input->post('id_category_quiz') ? $this->input->post('id_category_quiz') : null);
		if ($this->input->post()) {
			// STUDENTS //
			$dataStudent = $this->master->getStudentByClass_SIMPLE($this->input->post('id_class'));
			foreach ($dataStudent as $row => $value) {
				$university = $this->master->getUniversityByStudent_FULLJOIN($value->id_student);
				foreach ($university as $r => $v) {
					$university[$r]->department_pg = $this->GEN_PASSING_GRADE($v->department_pg);
				}
				$dataStudent[$row]->university = $university;
			}
			// QUIZ //
			$dataQuiz = $this->quiz->getQuizByCategory($this->input->post('id_category_quiz'));
			foreach ($dataQuiz as $row => $value) {
				$quiz_lesson = $this->quiz->getQuizLessonByQuiz($value->id_quiz);
				$totalQuestion = 0;
				foreach ($quiz_lesson as $r => $v) {
					$quiz_lesson[$r]->students = [];
					foreach ($dataStudent as $rStudent => $vStudent) {
						$dataResult = $this->quiz->getQuizResultByQuizLessonStudent($value->id_quiz,$v->id_lQuiz,$vStudent->id_student);
						if ($dataResult) {
							$dataResult->totalAnswered = $dataResult->rQuiz_total_true + $dataResult->rQuiz_total_false;
							$dataResult->university = $vStudent->university;
							array_push($quiz_lesson[$r]->students, $dataResult);
						}
					}
					$totalQuestion += $v->lQuiz_total_question;
				}
				$dataQuiz[$row]->quiz_lesson = $quiz_lesson;
				$dataQuiz[$row]->totalQuestion = $totalQuestion;
			}
			// CLEANING QUIZ //
			$cleanQuiz = [];
			foreach ($dataQuiz as $row => $value) {
				if($this->quiz->getQuizClassByQuizClass($value->id_quiz,$this->input->post('id_class'))) {
					array_push($cleanQuiz, $value);
				};
			}
			$dataQuiz = $cleanQuiz;
			// VALIDATING DESC STUDENT //
			$cleanStudent = [];
			foreach ($dataStudent as $row => $value) {
				$single = [
					'id_student' => $value->id_student,
		            'student_nis' => $value->student_nis,
		            'student_name' => $value->student_name,
		            'university' => $value->university,
		            'final_score' => 0
				];
				foreach ($dataQuiz as $r => $v) {
					foreach ($v->quiz_lesson as $r_ => $v_) {
						foreach ($v_->students as $_row => $_value) {
							if ($value->id_student == $_value->id_student) {
								$single['final_score'] += $_value->rQuiz_last_score;
							}
						}
					}
				}
				array_push($cleanStudent, $single);
			}
			usort($cleanStudent, function($a, $b) {
			    return $b['final_score'] - $a['final_score'];
			});
			// PARSING POST //
			$dataStudent = json_decode(json_encode($cleanStudent));
			// $this->debug($dataStudent,true);
			$this->parseData['dataQuiz'] = $dataQuiz;
			$this->parseData['dataStudent'] = $dataStudent;
			// SEND TO SESSION //
			$sess_ = [
				'SBMPTN_RESULT_SABER_LANCER_REPORT_dataQuiz' => $dataQuiz,
				'SBMPTN_RESULT_SABER_LANCER_REPORT_dataStudent' => $dataStudent,
				'SBMPTN_RESULT_SABER_LANCER_REPORT_classSelected' => $class_selected,
				'SBMPTN_RESULT_SABER_LANCER_REPORT_categorySelected' => $category_selected
			];
			$this->session->set_userdata($sess_);
		}
		// PARSING //
		$this->parseData['category_selected'] = $category_selected;
		$this->parseData['class_selected'] = $class_selected;
		$this->parseData['dataCategory'] = $this->quiz->getQuizCategory();
		$this->parseData['dataClass'] = $this->master->getAllClass();
		$this->parseData['content'] = 'content/quiz/result_sbmptn';
		$this->parseData['title'] = 'Laporan Ujian SBMPTN ';
		$this->load->view('MainView',$this->parseData);
	}
	public function analytics_sbmptn() {
		$class_selected = ($this->input->post('id_class') ? $this->input->post('id_class') : null);
		$category_selected = ($this->input->post('id_category_quiz') ? $this->input->post('id_category_quiz') : null);
		if ($this->input->post()) {
			// QUIZ //
			$dataQuiz = $this->quiz->getQuizByCategory($this->input->post('id_category_quiz'));
			foreach ($dataQuiz as $row => $value) {
				$quiz_lesson = $this->quiz->getQuizLessonByQuiz($value->id_quiz);
				$totalQuestion = 0;
				foreach ($quiz_lesson as $r => $v) {
					$totalQuestion += $v->lQuiz_total_question;
				}
				$dataQuiz[$row]->quiz_lesson = $quiz_lesson;
				$dataQuiz[$row]->totalQuestion = $totalQuestion;
			}
			$this->parseData['dataQuiz'] = $dataQuiz;
			// SEND TO SESSION //
			$sess_ = [
				'SBMPTN_ANALYTIC_BARBATOS_REPORT_dataQuiz' => $dataQuiz,
				'SBMPTN_ANALYTIC_BARBATOS_REPORT_categorySelected' => $category_selected,
				'SBMPTN_ANALYTIC_BARBATOS_REPORT_classSelected' => $class_selected
			];
			$this->session->set_userdata($sess_);
		}
		$this->parseData['category_selected'] = $category_selected;
		$this->parseData['class_selected'] = $class_selected;
		$this->parseData['dataCategory'] = $this->quiz->getQuizCategory();
		$this->parseData['dataClass'] = $this->master->getAllClass();
		$this->parseData['content'] = 'content/quiz/analytic_sbmptn';
		$this->parseData['title'] = 'Laporan Analisa Ujian SBMPTN ';
		$this->load->view('MainView',$this->parseData);
	}
	public function analytics_sbmptn_lesson($id_quiz = null, $id_lQuiz = null,$id_class = null) {
		$dataQuiz = $this->quiz->getQuizById($id_quiz);
		$dataClass = $this->class->getClassById($id_class);
		$quiz_lessons = [];
		if ($dataQuiz && $dataClass) {
			$dataStudent = $this->master->getStudentByClass_SIMPLE($id_class);
			$lesson_list = [];
			if ($id_lQuiz == 'all') {
				foreach ($this->quiz->getLessonByQuiz($id_quiz) as $rLesson => $vLesson) {
					array_push($lesson_list, $vLesson->id_lQuiz);
				}
			} else {
				array_push($lesson_list, $id_lQuiz);
			}
			// EACH BY LQUIZ //
			foreach ($lesson_list as $row_ => $value_) {
				$quiz_lesson = $this->quiz->getQuizLessonById($value_);
				if ($quiz_lesson) {
					$dataQuestion = $this->quiz->getQuizQuestionByLesson($value_);
					foreach ($dataQuestion as $row => $value) {
						$dataQuestion[$row]->totalTrue = 0;
						$dataQuestion[$row]->totalFalse = 0;
						$dataQuestion[$row]->totalEmpty = 0;
						foreach ($dataStudent as $rStudent => $vStudent) {
							$status = 'empty';
							foreach ($this->quiz->getQuizAnalyticByCondition($id_quiz,$value_,$value->id_qQuiz) as $r => $v) {	
								if ($v->id_student == $vStudent->id_student) {
									if ($v->aQuiz_status == 'true') {
										$status = 'true';
									} elseif($v->aQuiz_status == 'false') {
										$status = 'false';
									}
								}
							}
							if ($status == 'true') {
								$dataQuestion[$row]->totalTrue += 1;
							} elseif($status == 'false') {
								$dataQuestion[$row]->totalFalse += 1;
							} else {
								$dataQuestion[$row]->totalEmpty += 1;
							}
						}
					}
					$quiz_lesson->questions = $dataQuestion;
					array_push($quiz_lessons, $quiz_lesson);
				} // QUIZ LESSON VALIDITY //
			}
			// SEND TO SESSION //
			$sess_ = [
				'SBMPTN_RESULT_LESSON_BARBATOS_dataQuiz' => $dataQuiz,
				'SBMPTN_RESULT_LESSON_BARBATOS_quiz_lessons' => $quiz_lessons,
			];
			$this->session->set_userdata($sess_);
			// PARSING //
			$this->parseData['id_class'] = $id_class;
			$this->parseData['quiz_lessons'] = $quiz_lessons;
			$this->parseData['dataQuiz'] = $dataQuiz;
			$this->parseData['content'] = 'content/quiz/analytic_sbmptn_lesson';
			$this->parseData['title'] = 'Laporan Analisa Ujian SBMPTN ';
			$this->load->view('MainView',$this->parseData);
		} else {
			redirect('page/analytics_sbmptn');
		}
	}
	public function analytic_sbmptn_lesson_student($id_ = null) {
		if (!$id_) { redirect('page/analytics_sbmptn'); }
		$arr = explode('-', $id_);
		$id_lQuiz = (isset($arr[0]) ? $arr[0] : 0);
		$id_quiz = (isset($arr[1]) ? $arr[1] : 0);
		$id_qQuiz = (isset($arr[2]) ? $arr[2] : 0);
		$id_class = (isset($arr[3]) ? $arr[3] : 0);
		if ($id_lQuiz == 0 OR $id_quiz == 0 OR $id_qQuiz == 0 OR $id_class == 0) {
			redirect('page/analytics_sbmptn');
		}
		// ACTION //
		$dataQuestion = $this->quiz->getQuestionByQuizQuestion($id_qQuiz);
		$dataAnalytics = $this->quiz->getQuizAnalyticByCondition_4($id_quiz,$id_lQuiz,$id_qQuiz);
		$dataStudent = $this->master->getStudentByClass($id_class);
		// if (!$dataQuestion OR !$dataAnalytics OR !$dataStudent) { redirect('page/analytics_sbmptn'); }
		// PARSING //
		$dataQuestion->option_true = $this->quiz->getOptionTrueByQuestion($dataQuestion->id_question);
		$this->parseData['arr'] = $arr;
		$this->parseData['id_quiz'] = $id_quiz;
		$this->parseData['id_lQuiz'] = $id_lQuiz;
		$this->parseData['id_class'] = $id_class;
		$this->parseData['dataQuestion'] = $dataQuestion;
		$this->parseData['dataAnalytics'] = $dataAnalytics;
		$this->parseData['dataStudent'] = $dataStudent;
		$this->parseData['content'] = 'content/quiz/analytic_sbmptn_lesson_student';
		$this->parseData['title'] = 'Laporan Analisa Ujian SBMPTN ';
		$this->load->view('MainView',$this->parseData);
	}
	public function sbmptn_export_excel() {
		$dataQuiz = $this->session->userdata('SBMPTN_RESULT_SABER_LANCER_REPORT_dataQuiz');
		$dataStudent = $this->session->userdata('SBMPTN_RESULT_SABER_LANCER_REPORT_dataStudent');
		$class_selected = $this->session->userdata('SBMPTN_RESULT_SABER_LANCER_REPORT_classSelected');
		$category_selected = $this->session->userdata('SBMPTN_RESULT_SABER_LANCER_REPORT_categorySelected');
		$dataClass = $this->class->getClassById($class_selected);
		$dataCategory = $this->quiz->getQuizCategoryById($category_selected);
		if ($dataQuiz && $dataStudent && $dataClass && $dataCategory) {
			$data_parse = [
				'dataQuiz' => $dataQuiz,
				'dataStudent' => $dataStudent,
				'dataClass' => $dataClass,
				'dataCategory' => $dataCategory
			];
			$this->load->view('content/quiz/result_sbmptn_excel',$data_parse);
		} else {
			redirect('page/results_sbmptn');
		}
	}
	public function analytics_sbmptn_export($id_quiz = null) {
		$dataQuiz = $this->session->userdata('SBMPTN_ANALYTIC_BARBATOS_REPORT_dataQuiz');
		$dataCategory = $this->quiz->getQuizCategoryById($this->session->userdata('SBMPTN_ANALYTIC_BARBATOS_REPORT_categorySelected'));
		$dataClass = $this->class->getClassById($this->session->userdata('SBMPTN_ANALYTIC_BARBATOS_REPORT_classSelected'));
		if ($dataQuiz && $dataCategory && $dataClass) {
			$cleanQuiz = [];
			$dataStudent = $this->master->getStudentByClass($dataClass->id_class);
			foreach ($dataQuiz as $row => $value) {
				if ($value->id_quiz == $id_quiz) {
					$cleanQuiz = $value;
				}
			}
			if (!$cleanQuiz) {
				redirect('page/analytics_sbmptn');
			}
			// QUERY //
			$dataAnalytics = $this->quiz->getQuizAnalyticByQuiz($cleanQuiz->id_quiz);
			foreach ($cleanQuiz->quiz_lesson as $row => $value) {
				$questions = $this->quiz->getQuestionByQuizLesson($cleanQuiz->id_quiz,$value->id_lQuiz);
				foreach ($questions as $r => $v) {
					$questions[$r]->optionTrue = $this->quiz->getOptionTrueByQuestion($v->id_question);
				}
				$cleanQuiz->quiz_lesson[$row]->questions = $questions;
			}
			// PARSING //
			$data_parse = [
				'dataQuiz' => $cleanQuiz,
				'dataStudent' => $dataStudent,
				'dataClass' => $dataClass,
				'dataCategory' => $dataCategory,
				'dataAnalytics' => $dataAnalytics
			];
			$this->load->view('content/quiz/analytic_sbmptn_excel',$data_parse);
		} else {
			redirect('page/analytics_sbmptn');
		}
	}
	public function analytics_sbmptn_lesson_export() {
		$dataQuiz = $this->session->userdata('SBMPTN_RESULT_LESSON_BARBATOS_dataQuiz');
		$quiz_lessons = $this->session->userdata('SBMPTN_RESULT_LESSON_BARBATOS_quiz_lessons');
		if ($dataQuiz && $quiz_lessons) {
			$data_parse = [
				'dataQuiz' => $dataQuiz,
				'quiz_lessons' => $quiz_lessons,
			];
			$this->load->view('content/quiz/analytic_sbmptn_lesson_excel',$data_parse);
		} else {
			redirect('page/analytics_sbmptn');
		}
	}
	// NEWEST //
	public function createQuestion() {
		$dataLessons = [];
		if ($this->session->userdata('level') == 'admin') {
			$dataLessons = $this->master->getAllLesson();
		} elseif($this->session->userdata('level') == 'guru') {
			$dataLessons = $this->master->getLessonByTeacher($this->session->userdata('id_'));
		}
		$this->parseData['dataLessons'] = $dataLessons;
		$this->parseData['content'] = 'content/assignment/create_question_standAlone';
		$this->parseData['title'] = 'Buat Soal ';
		$this->load->view('MainView',$this->parseData);
	}
	 function updateQuestion($id_assignment = null, $id_question = NULL) {
		$dataQuestion = $this->assignment->getQuestionById($id_question);
		if (!$dataQuestion) {
			redirect($_SERVER['HTTP_REFERER']);
		}
		$mainPath = base_url('assets/images/questions/');
		$dataAssignment = null;
		if ($id_assignment != 'empty') {
			$dataAssignment = $this->assignment->getAssignmentById($id_assignment);
			if (!$dataAssignment) {
				redirect('page/assignments');
			}
			$mainPath = base_url('assets/images/assignmetns/'.$dataAssignment->assignment_path.'/');
		}
		$dataQuestion->options = $this->assignment->getOptionByQuestion($id_question);
		foreach ($dataQuestion->options as $row => $value) {
			if ($this->assignment->checkAnswerTrue($value->id_option,$id_question)) {
				$dataQuestion->trueAnswer = $row;
			}
		}
		// DATA LESSONS //
		$dataLessons = [];
		if ($this->session->userdata('level') == 'admin') {
			$dataLessons = $this->master->getAllLesson();
		} elseif($this->session->userdata('level') == 'guru') {
			$dataLessons = $this->master->getLessonByTeacher($this->session->userdata('id_'));
		}
		// PARSING //
		$this->parseData['dataAssignment'] = $dataAssignment;
		$this->parseData['dataLessons'] = $dataLessons;
		$this->parseData['mainPath'] = $mainPath;
		$this->parseData['dataQuestion'] = $dataQuestion;
		$this->parseData['content'] = 'content/assignment/update_question_standAlone';
		$this->parseData['title'] = 'Detail Soal ';
		$this->load->view('MainView',$this->parseData);
	}
	public function deleteQuestion($id_question = null) {
		if ($id_question) {
			$data = [
				'id_question' => $id_question,
				'question_hide' => 1
			];
			$this->assignment->updateQuestion($data);
			$this->message('Yeeayyy!','Data pertanyaan berhasil dihapus!','success');
		}
		redirect('page/bank');
	}
}

/* End of file MainPage.php */
/* Location: ./application/controllers/MainPage.php */ 